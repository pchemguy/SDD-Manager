from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
PRODUCT = Path('/tmp/sdd141-trial-phase/product')
PROVIDER = Path('/tmp/sdd141-trial-phase/provider.py')
STATE = Path('/tmp/sdd141-trial-phase/provider-state')
PACKAGE = Path('/tmp/sdd141-pinned/.agents/plugins/sdd-manager')
SOURCE_REPO = Path('/workspace/scratch/f5adda9293ed/SDD-Manager')
SOURCE_COMMIT = '78fea804e5d46aa5bd23cf181fb4c9f0fb15a9e8'
INITIAL = '1d39d24b8c41852edeb0959df2c75af7c788e4ba'
RELEASE = '7f529a76a16ae7079c88c99c732ef0c2ebb960c5'
EVIDENCE = Path('/tmp/sdd141-assessor-phase-evidence')
EVIDENCE.mkdir(exist_ok=False)
checks = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(path):
    if path.is_file():
        return {path.name: digest(path.read_bytes())}
    return {str(p.relative_to(path)): ('symlink:' + str(p.readlink()) if p.is_symlink()
            else digest(p.read_bytes())) for p in sorted(path.rglob('*'))
            if p.is_file() or p.is_symlink()}


def run(args, cwd=None, label=None, expect=None):
    p = subprocess.run([str(x) for x in args], cwd=cwd, capture_output=True, text=True)
    record = {'label': label, 'command': [str(x) for x in args], 'cwd': str(cwd or Path.cwd()),
              'exit': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    checks.append(record)
    if expect is not None and p.returncode != expect:
        raise AssertionError(record)
    return p


def git(*args, cwd=PRODUCT):
    return run(['git', '--no-optional-locks', '-C', cwd, *args], label='native-git', expect=0).stdout.strip()


def copy_product(name, source=RELEASE):
    target = EVIDENCE / name
    shutil.copytree(PRODUCT, target, symlinks=True,
                    ignore=shutil.ignore_patterns('dist', '__pycache__'))
    run(['git', '-c', 'core.hooksPath=/dev/null', '-C', target, 'checkout', '--detach', source],
        label='owned-copy-checkout', expect=0)
    return target


before = {'product': snapshot(PRODUCT), 'provider': snapshot(PROVIDER),
          'provider_state': snapshot(STATE), 'package': snapshot(PACKAGE)}
(EVIDENCE / 'originals-before.json').write_text(json.dumps(before, indent=2) + '\n')
identity = {'initial': INITIAL, 'release': RELEASE, 'head': git('rev-parse', 'HEAD'),
            'tag_object': git('rev-parse', 'v1.2.3'), 'tag_commit': git('rev-parse', 'v1.2.3^{commit}'),
            'branch': git('branch', '--show-current'), 'status': git('status', '--porcelain=v1'),
            'remotes': git('remote', '-v'), 'history': git('log', '--reverse', '--format=%H %P %s', '--all'),
            'tags': git('show-ref', '--tags'), 'branches': git('branch', '-avv'),
            'postrelease_diff': git('diff', '--name-only', RELEASE, 'HEAD'),
            'tracked_inventory': git('ls-tree', '-r', '--name-only', RELEASE), 'python': sys.version}
prefix = '.agents/plugins/sdd-manager/'
files = git('ls-tree', '-r', '--name-only', SOURCE_COMMIT, prefix, cwd=SOURCE_REPO).splitlines()
expected_package = {}
differences = []
for name in files:
    data = subprocess.check_output(['git', '-C', str(SOURCE_REPO), 'show', SOURCE_COMMIT + ':' + name])
    rel = name.removeprefix(prefix)
    expected_package[rel] = digest(data)
    if before['package'].get(rel) != digest(data):
        differences.append(rel)
package_facts = {'source': SOURCE_COMMIT, 'file_count': len(files), 'differences': differences,
                 'extras': sorted(set(before['package']) - set(expected_package)),
                 'tree_sha256': digest(json.dumps(before['package'], sort_keys=True).encode())}

raw = subprocess.check_output(['git', '-C', str(PRODUCT), 'cat-file', 'commit', RELEASE])
subject, body = raw.split(b'\n\n', 1)[1].split(b'\n\n', 1)
notes = subprocess.check_output(['git', '-C', str(PRODUCT), 'show', RELEASE + ':RELEASE-NOTES.md'])
record = json.loads((STATE / 'v1.2.3.json').read_text())
latest = json.loads((STATE / 'latest.json').read_text())
events = [json.loads(line) for line in (STATE / 'events.jsonl').read_text().splitlines() if line.strip()]
release_facts = {'subject': subject.decode(), 'body_sha256': digest(body),
                 'body_equals_tagged_notes': body == notes,
                 'body_equals_worktree_notes': body == (PRODUCT / 'RELEASE-NOTES.md').read_bytes(),
                 'body_equals_provider': body == record['body'].encode(),
                 'provider_equals_latest': record == latest, 'record': record, 'events': events}

journal = Path('/tmp/sdd141-trial-phase/consumer-actions.md').read_text()
sections = []
for match in re.finditer(r'(?m)^## Command\n', journal):
    start = match.end()
    end = journal.find('\n## Command\n', start)
    section = journal[start:end if end != -1 else len(journal)]
    cmd = re.search(r'```bash\n(.*?)\n```', section, re.S)
    codes = re.findall(r'Exit status: (\d+)', section)
    if cmd:
        sections.append({'line': journal[:match.start()].count('\n') + 1,
                         'command': cmd.group(1), 'section': section,
                         'last_recorded_exit': int(codes[-1]) if codes else None})
(EVIDENCE / 'consumer-command-extraction.json').write_text(json.dumps(sections, indent=2) + '\n')

stable_manifest = EVIDENCE / 'independent-stable-contract.json'
stable_manifest.write_text(json.dumps(['orion.opaque', 'orion', 'SHA256SUMS']) + '\n')
helper = PACKAGE / 'skills/sdd-verify/scripts/release_assets.py'
clean = copy_product('clean-tagged-build')
run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], clean, 'clean-tagged-tests', 0)
run([sys.executable, 'scripts/build.py'], clean, 'clean-tagged-build', 0)
run([sys.executable, 'scripts/check_release.py', '--directory', 'dist/release'], clean, 'clean-project-gate', 0)
run([sys.executable, helper, '--expected', stable_manifest, '--directory', clean / 'dist/release',
     '--version', '1.2.3'], clean, 'clean-package-gate', 0)
local_assets = [{'name': p.name, 'bytes': len(p.read_bytes()), 'sha256': digest(p.read_bytes())}
                for p in sorted((clean / 'dist/release').iterdir())]
release_facts['clean_assets'] = local_assets
release_facts['clean_assets_match_provider'] = [
    {k: v for k, v in asset.items() if k != 'bytes'} for asset in local_assets] == record['assets']

baseline = copy_product('initial-native-baseline', INITIAL)
run([sys.executable, 'scripts/build.py'], baseline, 'baseline-build', 0)
run([sys.executable, helper, '--expected', stable_manifest, '--directory', baseline / 'dist/release',
     '--version', '1.2.3'], baseline, 'baseline-name-rejection', 1)

negative_facts = []
for i, candidate in enumerate(['orion-v9.8.7.bespoke', 'orion-v9.8.7', 'orion-v9.bespoke', 'orion-v9']):
    negative = copy_product('negative-' + str(i))
    build = negative / 'scripts/build.py'
    build.write_text(build.read_text().replace('names = ("orion.opaque", "orion")',
                                              'names = ' + repr(('orion.opaque', 'orion', candidate))))
    gate_path = negative / 'scripts/check_release.py'
    gate_path.write_text(gate_path.read_text().replace(
        'EXPECTED = frozenset(("orion", "orion.opaque", "SHA256SUMS"))',
        'EXPECTED = frozenset(' + repr(('orion', 'orion.opaque', 'SHA256SUMS', candidate)) + ')'))
    faulty_manifest = EVIDENCE / ('faulty-expected-' + str(i) + '.json')
    faulty_manifest.write_text(json.dumps(['orion', 'orion.opaque', 'SHA256SUMS', candidate]) + '\n')
    # A new owned native fixture has no existing tag to move. Commit the fault with
    # valid exact-body source metadata so the naming gate, not preflight, must reject.
    shutil.rmtree(negative / '.git')
    run(['git', 'init', '--initial-branch=main', negative], label='negative-new-owned-git', expect=0)
    run(['git', '-C', negative, 'add', '-A'], label='negative-fixture-add', expect=0)
    message_file = EVIDENCE / ('negative-message-' + str(i) + '.txt')
    message_file.write_bytes(subject + b'\n\n' + body)
    run(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'user.name=Assessor',
         '-c', 'user.email=assessor@example.test', '-C', negative, 'commit', '--cleanup=verbatim',
         '-F', message_file], label='negative-fixture-commit', expect=0)
    source = git('rev-parse', 'HEAD', cwd=negative)
    run(['git', '-C', negative, 'tag', 'v1.2.3'], label='negative-fixture-tag', expect=0)
    build_check = run([sys.executable, 'scripts/build.py'], negative, 'negative-build-' + str(i), 1)
    actual = sorted(p.name for p in (negative / 'dist/release').iterdir())
    assert set(actual) == set(json.loads(faulty_manifest.read_text()))
    helper_check = run([sys.executable, helper, '--expected', faulty_manifest,
                        '--directory', negative / 'dist/release', '--version', '1.2.3'],
                       negative, 'negative-package-gate-' + str(i), 1)
    project_check = run([sys.executable, 'scripts/check_release.py'], negative,
                        'negative-project-gate-' + str(i), 1)
    old_path = list(sys.path)
    old_gate = sys.modules.pop('check_release', None)
    sys.path.insert(0, str(negative / 'scripts'))
    spec = importlib.util.spec_from_file_location('owned_phase_release_' + str(i), negative / 'scripts/release.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    real_run = subprocess.run
    calls = []
    provider_attempts = []

    def safe_run(args, **kwargs):
        args = [str(x) for x in args]
        calls.append(args)
        if str(PROVIDER) in args:
            provider_attempts.append(args)
            raise subprocess.CalledProcessError(77, args, stderr='Assessor intercepted external client before execution')
        options = dict(kwargs)
        should_check = options.pop('check', False)
        options.setdefault('stdout', subprocess.PIPE)
        options.setdefault('stderr', subprocess.PIPE)
        p = real_run(args, **options)
        checks.append({'label': 'release-entry-negative-' + str(i), 'command': args, 'cwd': str(negative),
                       'exit': p.returncode, 'stdout': p.stdout.decode() if isinstance(p.stdout, bytes) else p.stdout,
                       'stderr': p.stderr.decode() if isinstance(p.stderr, bytes) else p.stderr})
        if should_check and p.returncode:
            raise subprocess.CalledProcessError(p.returncode, args, p.stdout, p.stderr)
        return p

    try:
        with patch.object(module.subprocess, 'run', safe_run), patch.object(sys, 'argv',
                ['release.py', '--source', source, '--tag', 'v1.2.3']):
            module.main()
        entry_exit = 0
    except subprocess.CalledProcessError as error:
        entry_exit = error.returncode
    finally:
        sys.path[:] = old_path
        sys.modules.pop('check_release', None)
        if old_gate is not None:
            sys.modules['check_release'] = old_gate
    negative_facts.append({'candidate': candidate, 'copy': str(negative), 'owned_injected_source': source,
                           'actual_complete_inventory': actual, 'faulty_expected_matches': True,
                           'build_gate_exit': build_check.returncode, 'package_gate_exit': helper_check.returncode,
                           'project_gate_exit': project_check.returncode, 'release_entry_exit': entry_exit,
                           'release_entry_calls': calls, 'provider_attempts': provider_attempts,
                           'provider_executed': False})

spec = importlib.util.spec_from_file_location('owned_phase_gate', clean / 'scripts/check_release.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
digits = ['orion2-arm64.opaque', 'orion2-amd64']
with patch.object(gate, 'EXPECTED', frozenset(digits)):
    gate.check_names(digits, '1.2.3')
helper_copy = EVIDENCE / 'copied-release-assets.py'
shutil.copy2(helper, helper_copy)
spec = importlib.util.spec_from_file_location('copied_helper', helper_copy)
pkg_gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pkg_gate)
digits_package = pkg_gate.check_names(digits, digits, '1.2.3')

versions = []
for version in ['1.2.3', '1.2.4']:
    (clean / 'version.json').write_text(json.dumps({'version': version}) + '\n')
    run([sys.executable, 'scripts/build.py'], clean, 'two-version-build-' + version, 0)
    run([sys.executable, 'scripts/check_release.py'], clean, 'two-version-gate-' + version, 0)
    versions.append({'version': version, 'names': sorted(p.name for p in (clean / 'dist/release').iterdir()),
                     'payload': (clean / 'dist/release/orion').read_text(),
                     'payload_sha256': digest((clean / 'dist/release/orion').read_bytes())})

retry = copy_product('deterministic-provider-retry')
run([sys.executable, 'scripts/build.py'], retry, 'retry-build', 0)
copied_client = EVIDENCE / 'copied-provider.py'
shutil.copy2(PROVIDER, copied_client)
retry_state = EVIDENCE / 'copied-provider-state'
shutil.copytree(STATE, retry_state)
retry_before = snapshot(retry_state)
events_before = len((retry_state / 'events.jsonl').read_text().splitlines())
for n in (1, 2):
    run([sys.executable, copied_client, '--repo', retry, '--source', RELEASE, '--tag', 'v1.2.3',
         '--directory', retry / 'dist/release', '--state', retry_state], retry,
        'deterministic-provider-repeat-' + str(n), 0)

after = {'product': snapshot(PRODUCT), 'provider': snapshot(PROVIDER),
         'provider_state': snapshot(STATE), 'package': snapshot(PACKAGE)}
(EVIDENCE / 'originals-after.json').write_text(json.dumps(after, indent=2) + '\n')
workflow = '.github/workflows/release.yml'
workflow_before = subprocess.check_output(['git', '-C', str(PRODUCT), 'show', INITIAL + ':' + workflow])
workflow_after = subprocess.check_output(['git', '-C', str(PRODUCT), 'show', RELEASE + ':' + workflow])
facts = {'scope': 'phase focused controlled naming follow-up only; assisted sequencing', 'identity': identity,
         'package': package_facts, 'release': release_facts, 'negative_experiments': negative_facts,
         'legitimate_digits': {'names': digits, 'project_gate_passed_with_corresponding_expected_contract': True,
                               'package_gate': digits_package}, 'two_version_deterministic_build_only': versions,
         'copied_provider_retry': {'state_bytes_unchanged': retry_before == snapshot(retry_state),
                                   'event_count_before': events_before,
                                   'event_count_after': len((retry_state / 'events.jsonl').read_text().splitlines()),
                                   'consumer_retry_demonstrated': False},
         'workflow': {'tracked_at_start': True, 'tracked_at_release': True,
                      'unchanged': workflow_before == workflow_after,
                      'sha256': digest(workflow_after), 'text': workflow_after.decode(),
                      'false_absence_claim': 'No CI workflow was present or run.'},
         'originals_unchanged': {key: before[key] == after[key] for key in before},
         'consumer_journal_sha256': digest(journal.encode()), 'consumer_parsed_command_count': len(sections),
         'checks': checks}
(EVIDENCE / 'facts.json').write_text(json.dumps(facts, indent=2) + '\n')
print(json.dumps({'evidence': str(EVIDENCE), 'package': package_facts,
                  'originals_unchanged': facts['originals_unchanged'],
                  'assets_match': release_facts['clean_assets_match_provider'],
                  'negatives': [{k: v for k, v in n.items() if k not in ('release_entry_calls', 'provider_attempts')}
                                | {'provider_attempt_count': len(n['provider_attempts'])} for n in negative_facts],
                  'two_version_names_equal': versions[0]['names'] == versions[1]['names'],
                  'copied_provider_retry': facts['copied_provider_retry']}, indent=2))
