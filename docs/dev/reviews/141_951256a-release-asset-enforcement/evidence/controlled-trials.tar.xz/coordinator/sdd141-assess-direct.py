from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from unittest.mock import patch

PRODUCT = Path('/tmp/sdd141-trial-direct/product')
PROVIDER = Path('/tmp/sdd141-trial-direct/provider.py')
STATE = Path('/tmp/sdd141-trial-direct/provider-state')
PACKAGE = Path('/tmp/sdd141-pinned/.agents/plugins/sdd-manager')
SOURCE_REPO = Path('/workspace/scratch/f5adda9293ed/SDD-Manager')
SOURCE_COMMIT = '78fea804e5d46aa5bd23cf181fb4c9f0fb15a9e8'
INITIAL = '7ec357c3bc8f91b47fd1be21aa57900f6184c44c'
RELEASE = '66bd066659538369acd5115d38cc263823349294'
EVIDENCE = Path('/tmp/sdd141-assessor-direct-evidence')
EVIDENCE.mkdir(exist_ok=False)
checks = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(path):
    if path.is_file():
        return {path.name: digest(path.read_bytes())}
    return {str(p.relative_to(path)): ('symlink:' + str(p.readlink()) if p.is_symlink()
            else digest(p.read_bytes())) for p in sorted(path.rglob('*'))
            if p.is_file() or p.is_symlink()}


def run(args, cwd=None, label=None, expect=None):
    p = subprocess.run([str(x) for x in args], cwd=cwd, capture_output=True, text=True)
    record = {'label': label, 'command': [str(x) for x in args],
              'cwd': str(cwd or Path.cwd()), 'exit': p.returncode,
              'stdout': p.stdout, 'stderr': p.stderr}
    checks.append(record)
    if expect is not None and p.returncode != expect:
        raise AssertionError(record)
    return p


def git(*args, cwd=PRODUCT):
    return run(['git', '--no-optional-locks', '-C', cwd, *args], label='native-git', expect=0).stdout.strip()


def copy_product(name, source=RELEASE):
    target = EVIDENCE / name
    shutil.copytree(PRODUCT, target, symlinks=True,
                    ignore=shutil.ignore_patterns('dist', '__pycache__'))
    run(['git', '-c', 'core.hooksPath=/dev/null', '-C', target,
         'checkout', '--detach', source], label='owned-copy-checkout', expect=0)
    return target


before = {'product': snapshot(PRODUCT), 'provider': snapshot(PROVIDER),
          'provider_state': snapshot(STATE), 'package': snapshot(PACKAGE)}
(EVIDENCE / 'originals-before.json').write_text(json.dumps(before, indent=2) + '\n')
identity = {'initial': INITIAL, 'release': RELEASE, 'head': git('rev-parse', 'HEAD'),
            'tag_object': git('rev-parse', 'v1.2.3'), 'tag_commit': git('rev-parse', 'v1.2.3^{commit}'),
            'branch': git('branch', '--show-current'), 'status': git('status', '--porcelain=v1'),
            'remotes': git('remote', '-v'), 'history': git('log', '--reverse', '--format=%H %P %s', '--all'),
            'tags': git('show-ref', '--tags'),
            'postrelease_diff': git('diff', '--name-only', RELEASE, 'HEAD'),
            'python': sys.version}

# Independently compare every pinned file with its declared native source tree.
prefix = '.agents/plugins/sdd-manager/'
files = git('ls-tree', '-r', '--name-only', SOURCE_COMMIT, prefix, cwd=SOURCE_REPO).splitlines()
package_differences = []
expected_package = {}
for name in files:
    data = subprocess.check_output(['git', '-C', str(SOURCE_REPO), 'show', SOURCE_COMMIT + ':' + name])
    relative = name.removeprefix(prefix)
    expected_package[relative] = digest(data)
    if not (PACKAGE / relative).is_file() or digest((PACKAGE / relative).read_bytes()) != digest(data):
        package_differences.append(relative)
package_extras = sorted(set(before['package']) - set(expected_package))
package_facts = {'source': SOURCE_COMMIT, 'file_count': len(files),
                 'differences': package_differences, 'extras': package_extras,
                 'tree_sha256': digest(json.dumps(before['package'], sort_keys=True).encode())}

raw_commit = subprocess.check_output(['git', '-C', str(PRODUCT), 'cat-file', 'commit', RELEASE])
message = raw_commit.split(b'\n\n', 1)[1]
subject, body = message.split(b'\n\n', 1)
notes = subprocess.check_output(['git', '-C', str(PRODUCT), 'show', RELEASE + ':RELEASE-NOTES.md'])
release_record = json.loads((STATE / 'v1.2.3.json').read_text())
latest_record = json.loads((STATE / 'latest.json').read_text())
events = [json.loads(line) for line in (STATE / 'events.jsonl').read_text().splitlines() if line.strip()]
release_facts = {'subject': subject.decode(), 'body_sha256': digest(body),
                 'body_equals_tagged_notes': body == notes,
                 'body_equals_worktree_notes': body == (PRODUCT / 'RELEASE-NOTES.md').read_bytes(),
                 'body_equals_provider': body == release_record['body'].encode(),
                 'provider_equals_latest': release_record == latest_record,
                 'record': release_record, 'events': events}

journal = Path('/tmp/sdd141-trial-direct/consumer-actions.md').read_text()
journal_blocks = []
for m in re.finditer(r'```bash\n(.*?)\n```\n\n```text\n(.*?)\n```\nExit status: (\d+)', journal, re.S):
    cmd, output, code = m.groups()
    journal_blocks.append({'line': journal[:m.start()].count('\n') + 1,
                           'command': cmd, 'output': output, 'exit': int(code)})
(EVIDENCE / 'consumer-command-extraction.json').write_text(json.dumps(journal_blocks, indent=2) + '\n')

clean = copy_product('clean-tagged-build')
run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], clean, 'clean-tagged-tests', 0)
run([sys.executable, 'scripts/build.py'], clean, 'clean-tagged-build', 0)
run([sys.executable, 'scripts/check_release.py', '--directory', 'dist/release'], clean, 'clean-project-gate', 0)
helper = PACKAGE / 'skills/sdd-verify/scripts/release_assets.py'
run([sys.executable, helper, '--expected', clean / 'release-artifacts.json',
     '--directory', clean / 'dist/release', '--version', '1.2.3'], clean, 'clean-package-gate', 0)
local_assets = [{'name': p.name, 'bytes': len(p.read_bytes()), 'sha256': digest(p.read_bytes())}
                for p in sorted((clean / 'dist/release').iterdir())]
release_facts['clean_assets'] = local_assets
release_facts['clean_assets_match_provider'] = [
    {k: v for k, v in asset.items() if k != 'bytes'} for asset in local_assets] == release_record['assets']
release_facts['local_original_inventory'] = sorted(p.name for p in (PRODUCT / 'dist/release').iterdir())

baseline = copy_product('initial-native-baseline', INITIAL)
expected = baseline / 'assessor-stable-contract.json'
expected.write_text(json.dumps(['orion.opaque', 'orion', 'SHA256SUMS']))
run([sys.executable, 'scripts/build.py'], baseline, 'baseline-build', 0)
run([sys.executable, helper, '--expected', expected, '--directory', baseline / 'dist/release',
     '--version', '1.2.3'], baseline, 'baseline-name-rejection', 1)

negative_facts = []
for i, candidate in enumerate(['orion-v9.8.7.bespoke', 'orion-v9.8.7',
                                'orion-v9.bespoke', 'orion-v9']):
    negative = copy_product('negative-' + str(i))
    build = negative / 'scripts/build.py'
    text = build.read_text()
    text = text.replace("names = ('orion.opaque', 'orion')",
                        'names = ' + repr(('orion.opaque', 'orion', candidate)))
    build.write_text(text)
    manifest = negative / 'release-artifacts.json'
    manifest.write_text(json.dumps(['orion.opaque', 'orion', candidate, 'SHA256SUMS']) + '\n')
    run([sys.executable, 'scripts/build.py'], negative, 'negative-build-' + str(i), 0)
    actual = sorted(p.name for p in (negative / 'dist/release').iterdir())
    assert set(actual) == set(json.loads(manifest.read_text()))
    helper_check = run([sys.executable, helper, '--expected', manifest,
                        '--directory', negative / 'dist/release', '--version', '1.2.3'],
                       negative, 'negative-package-gate-' + str(i), 1)
    project_check = run([sys.executable, 'scripts/check_release.py', '--directory', 'dist/release'],
                        negative, 'negative-project-gate-' + str(i))
    spec = importlib.util.spec_from_file_location('owned_release_' + str(i), negative / 'scripts/release.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    real_run = subprocess.run
    calls = []
    provider_attempts = []

    def safe_run(args, **kwargs):
        args = [str(x) for x in args]
        calls.append(args)
        if str(PROVIDER) in args:
            provider_attempts.append(args)
            raise subprocess.CalledProcessError(77, args, stderr='Assessor intercepted external client before execution')
        p = real_run(args, capture_output=True, text=True)
        checks.append({'label': 'release-entry-negative-' + str(i), 'command': args,
                       'cwd': str(negative), 'exit': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
        if kwargs.get('check') and p.returncode:
            raise subprocess.CalledProcessError(p.returncode, args, p.stdout, p.stderr)
        return p

    try:
        with patch.object(module.subprocess, 'run', safe_run):
            module.publish(RELEASE, 'v1.2.3')
        entry_exit = 0
    except subprocess.CalledProcessError as error:
        entry_exit = error.returncode
    negative_facts.append({'candidate': candidate, 'copy': str(negative),
                           'actual_complete_inventory': actual, 'faulty_expected_matches': True,
                           'package_gate_exit': helper_check.returncode, 'project_gate_exit': project_check.returncode,
                           'release_entry_exit': entry_exit, 'release_entry_calls': calls,
                           'provider_attempts': provider_attempts, 'provider_executed': False})

# Validate legitimate product/architecture digits independently of the unit test.
spec = importlib.util.spec_from_file_location('owned_gate', clean / 'scripts/check_release.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
digits = ['orion2-arm64.opaque', 'orion2-amd64']
gate.check_names(digits, digits, '1.2.3')
spec = importlib.util.spec_from_file_location('pinned_helper', helper)
package_gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package_gate)
digits_package = package_gate.check_names(digits, digits, '1.2.3')

# Isolated deterministic two-version build. This is not a consumer second release.
versions = []
for version in ['1.2.3', '1.2.4']:
    (clean / 'version.json').write_text(json.dumps({'version': version}) + '\n')
    run([sys.executable, 'scripts/build.py'], clean, 'two-version-build-' + version, 0)
    run([sys.executable, 'scripts/check_release.py', '--directory', 'dist/release'],
        clean, 'two-version-gate-' + version, 0)
    versions.append({'version': version, 'names': sorted(p.name for p in (clean / 'dist/release').iterdir()),
                     'payload': (clean / 'dist/release/orion').read_text(),
                     'payload_sha256': digest((clean / 'dist/release/orion').read_bytes())})

# Native copied provider replay uses only owned repo/state paths, never the original client.
retry = copy_product('deterministic-provider-retry')
run([sys.executable, 'scripts/build.py'], retry, 'retry-build', 0)
copied_client = EVIDENCE / 'copied-provider.py'
shutil.copy2(PROVIDER, copied_client)
retry_state = EVIDENCE / 'copied-provider-state'
shutil.copytree(STATE, retry_state)
retry_before = snapshot(retry_state)
retry_cmd = [sys.executable, copied_client, '--repo', retry, '--source', RELEASE,
             '--tag', 'v1.2.3', '--directory', retry / 'dist/release', '--state', retry_state]
run(retry_cmd, retry, 'deterministic-provider-repeat-one', 0)
run(retry_cmd, retry, 'deterministic-provider-repeat-two', 0)
retry_after = snapshot(retry_state)

after = {'product': snapshot(PRODUCT), 'provider': snapshot(PROVIDER),
         'provider_state': snapshot(STATE), 'package': snapshot(PACKAGE)}
(EVIDENCE / 'originals-after.json').write_text(json.dumps(after, indent=2) + '\n')
facts = {'scope': 'direct focused controlled naming follow-up only', 'identity': identity,
         'package': package_facts, 'release': release_facts, 'negative_experiments': negative_facts,
         'legitimate_digits': {'names': digits, 'project_gate_passed': True, 'package_gate': digits_package},
         'two_version_deterministic_build_only': versions,
         'copied_provider_retry': {'state_unchanged': retry_before == retry_after,
                                   'event_count_before': len((retry_state / 'events.jsonl').read_text().splitlines()),
                                   'event_count_after': len((retry_state / 'events.jsonl').read_text().splitlines()),
                                   'consumer_retry_demonstrated': False},
         'originals_unchanged': {key: before[key] == after[key] for key in before},
         'consumer_journal_sha256': digest(journal.encode()), 'consumer_parsed_command_count': len(journal_blocks),
         'checks': checks}
(EVIDENCE / 'facts.json').write_text(json.dumps(facts, indent=2) + '\n')
print(json.dumps({'evidence': str(EVIDENCE), 'package': package_facts,
                  'originals_unchanged': facts['originals_unchanged'],
                  'assets_match': release_facts['clean_assets_match_provider'],
                  'negatives': [{k: v for k, v in n.items() if k not in ('release_entry_calls', 'provider_attempts')}
                                | {'provider_attempt_count': len(n['provider_attempts'])} for n in negative_facts],
                  'two_version_names_equal': versions[0]['names'] == versions[1]['names'],
                  'copied_provider_retry': facts['copied_provider_retry']}, indent=2))
