import os
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
E=Path('/tmp/sdd141-assessor-retry-evidence')
P=E/'clean-product'
records=json.loads((E/'commands.json').read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def save(n,x): (E/n).write_text(json.dumps(x,indent=2)+'\n')
def run(label,argv,cwd,env=None):
    r=subprocess.run(argv,cwd=cwd,env={**os.environ,**(env or {})},capture_output=True)
    records.append({'label':label,'argv':argv,'cwd':str(cwd),'non_secret_environment':{'PYTHONDONTWRITEBYTECODE':'1',**(env or {})},'returncode':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
    save('commands.json',records)
    (E/(label+'.stdout.txt')).write_bytes(r.stdout)
    (E/(label+'.stderr.txt')).write_bytes(r.stderr)
    print(label,r.returncode,flush=True)
    return r

intercept=E/'intercept'
intercept.mkdir()
(intercept/'sitecustomize.py').write_text('''import os,subprocess,json
from pathlib import Path
_Popen=subprocess.Popen
def guarded_popen(args,*a,**kw):
    if isinstance(args,(list,tuple)) and '/tmp/sdd141-trial-retry/provider.py' in args:
        Path(os.environ['ASSESSOR_PROVIDER_LOG']).write_text(json.dumps({'intercepted':True,'argv':list(args)})+'\\n')
        raise PermissionError('ASSESSOR: original provider execution intercepted')
    return _Popen(args,*a,**kw)
subprocess.Popen=guarded_popen
''')

names_cases={
    'current-dotted-extensionless':['orion-1.2.3','orion.opaque','SHA256SUMS'],
    'current-dotted-opaque':['orion','orion-1.2.3.opaque','SHA256SUMS'],
    'historical-dotted-extensionless':['orion-0.9.7','orion.opaque','SHA256SUMS'],
    'historical-dotted-arbitrary':['orion','orion-0.9.7.unfamiliar','SHA256SUMS'],
    'historical-v9-extensionless':['orion-v9','orion.opaque','SHA256SUMS'],
    'historical-v9-opaque':['orion','orion-v9.opaque','SHA256SUMS'],
    'historical-v9-arbitrary':['orion','orion-v9.unfamiliar','SHA256SUMS'],
    'historical-separated-arbitrary':['orion','orion-9_8_7.zorb','SHA256SUMS'],
    'legitimate-product-architecture-digits':['orion2-linux-x86_64.opaque','orion2-linux-aarch64','SHA256SUMS'],
}
results=[]
builder='''import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'dist/release'
if out.exists(): shutil.rmtree(out)
out.mkdir(parents=True)
names=NAMES
version=json.loads((root/'version.json').read_text())['version']
content=('Hello World; embedded version '+version+'\\n').encode()
for name in sorted(set(names)-{'SHA256SUMS'}): (out/name).write_bytes(content)
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  '+n+'\\n' for n in sorted(set(names)-{'SHA256SUMS'})))
print(json.dumps({'assessor_injected_build':True,'names':sorted(names)}))
'''
for label,names in names_cases.items():
    cp=E/('case-'+label)
    shutil.copytree(P,cp)
    # Only faulty producer and matching manifest are injected; release.py,
    # check_release.py, and release_assets.py remain exact committed bytes.
    (cp/'release-assets.json').write_text(json.dumps(names)+'\n')
    (cp/'scripts/build.py').write_text(builder.replace('NAMES',repr(names)))
    marker=cp/'provider-intercept.json'
    env={'PYTHONPATH':str(intercept),'ASSESSOR_PROVIDER_LOG':str(marker)}
    r=run(label,[sys.executable,'scripts/release.py','--source','60afbb03fae8b59e95082de1cbb5e488f6a04a8f','--tag','v1.2.3'],cp,env)
    results.append({'case':label,'names':names,'matching_faulty_manifest':not label.startswith('legitimate'),'direct_publisher_script_unchanged':(cp/'scripts/release.py').read_bytes()==(P/'scripts/release.py').read_bytes(),'gate_source_unchanged':all((cp/rel).read_bytes()==(P/rel).read_bytes() for rel in ('scripts/check_release.py','scripts/release_assets.py')),'returncode':r.returncode,'provider_attempt_intercepted':marker.exists(),'expected_disposition':'accept-to-provider' if label.startswith('legitimate') else 'reject-before-provider','name_rejection_observed':b'Version numbers in ANY release artifact name' in r.stdout,'passed':(marker.exists() and b'"ok": true' in r.stdout) if label.startswith('legitimate') else (r.returncode==1 and not marker.exists() and b'Version numbers in ANY release artifact name' in r.stdout)})

# Unknown artifacts are inventoried even when the legitimate contract stays intact.
for label,extra in [('extra-extensionless','rogue-v9'),('extra-arbitrary','rogue-9.8.7.zorb')]:
    cp=E/('case-'+label)
    shutil.copytree(P,cp)
    with (cp/'scripts/build.py').open('a') as f:
        f.write('\n(Path(__file__).resolve().parents[1]/"dist/release"/'+repr(extra)+').write_text("injected")\n')
    marker=cp/'provider-intercept.json'
    r=run(label,[sys.executable,'scripts/release.py','--source','60afbb03fae8b59e95082de1cbb5e488f6a04a8f','--tag','v1.2.3'],cp,{'PYTHONPATH':str(intercept),'ASSESSOR_PROVIDER_LOG':str(marker)})
    results.append({'case':label,'extra_artifact':extra,'manifest_unchanged':True,'returncode':r.returncode,'provider_attempt_intercepted':marker.exists(),'passed':r.returncode==1 and not marker.exists() and b'Version numbers in ANY release artifact name' in r.stdout})
save('direct-publisher-negative-and-digit-matrix.json',results)

# Stability over versions uses the unchanged real producer and gate.
stability=[]
cp=E/'two-version-product'
shutil.copytree(P,cp)
for version in ['1.2.3','1.2.4']:
    (cp/'version.json').write_text(json.dumps({'version':version})+'\n')
    label='two-version-'+version
    b=run(label+'-build',[sys.executable,'scripts/build.py'],cp)
    g=run(label+'-gate',[sys.executable,'scripts/check_release.py'],cp)
    inv=[{'name':p.name,'sha256':sha(p.read_bytes()),'content':p.read_text()} for p in sorted((cp/'dist/release').iterdir())]
    stability.append({'version':version,'build_exit':b.returncode,'gate_exit':g.returncode,'inventory':inv})
save('two-version-producer-stability.json',{'observations':stability,'names_equal':[x['name'] for x in stability[0]['inventory']]==[x['name'] for x in stability[1]['inventory']],'payload_hashes_changed':stability[0]['inventory']!=stability[1]['inventory']})

# Repeated entry with a byte-identical provider copy and owned state. The only
# release entry edits redirect provider program/state, and are retained as diff.
cp=E/'repeat-product'
shutil.copytree(P,cp)
client=E/'owned-provider.py'
shutil.copy2('/tmp/sdd141-trial-retry/provider.py',client)
state=E/'owned-provider-state'
release=cp/'scripts/release.py'
original=release.read_text()
release.write_text(original.replace('/tmp/sdd141-trial-retry/provider.py',str(client)).replace('/tmp/sdd141-trial-retry/provider-state',str(state)))
run('repeat-provider-redirection-diff',['git','diff','--','scripts/release.py'],cp)
repeated=[]
for i in [1,2]:
    r=run('repeat-entry-'+str(i),[sys.executable,'scripts/release.py','--source','60afbb03fae8b59e95082de1cbb5e488f6a04a8f','--tag','v1.2.3'],cp)
    repeated.append({'iteration':i,'returncode':r.returncode,'events':(state/'events.jsonl').read_text(),'record':json.loads((state/'v1.2.3.json').read_text()),'latest':json.loads((state/'latest.json').read_text())})
save('repeated-entry-owned-provider.json',{'provider_copy_byte_identical':client.read_bytes()==Path('/tmp/sdd141-trial-retry/provider.py').read_bytes(),'observations':repeated,'events_unchanged':repeated[0]['events']==repeated[1]['events'],'event_count_after_second':len(repeated[1]['events'].splitlines()),'record_unchanged':repeated[0]['record']==repeated[1]['record'],'latest_equal_record':repeated[1]['latest']==repeated[1]['record'],'evidence_class':'independent deterministic controlled-provider test; not observed consumer re-entry'})

# Final preservation check includes all original files and native Git data.
def snap(path):
    path=Path(path)
    if path.is_file(): return {'file':sha(path.read_bytes())}
    return {str(p.relative_to(path)):({'symlink':os.readlink(p)} if p.is_symlink() else sha(p.read_bytes())) for p in sorted(path.rglob('*')) if p.is_file() or p.is_symlink()}
before=json.loads((E/'preservation-before.json').read_text())
originals={'trial':Path('/tmp/sdd141-trial-retry'),'package':Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager'),'input':Path('/tmp/sdd141-retry-input.json')}
after={k:snap(p) for k,p in originals.items()}
save('preservation-after.json',after)
save('preservation-result.json',{'unchanged':{k:before[k]==after[k] for k in before},'added':{k:sorted(set(after[k])-set(before[k])) for k in before},'removed':{k:sorted(set(before[k])-set(after[k])) for k in before},'changed':{k:[p for p in before[k] if p in after[k] and before[k][p]!=after[k][p]] for k in before},'bytecode_after':{k:[p for p in after[k] if '__pycache__' in p or p.endswith('.pyc')] for k in before}})
