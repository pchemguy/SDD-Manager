# Orion 1.2.3 controlled release consumer actions

Scope: `/tmp/sdd141-trial-retry/product`; pinned SDD Manager `/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager` at supplied source `d76ffbfc8d8aab91dcfd7d1efc6eb5a2bc13a879`; controlled provider interface only. User preapproved in-scope repairs and checkpoints. Commits/tags remain local. No real GitHub release or network/hosting is authorized.

## Initial inspection

Command (working directory `/tmp/sdd141-trial-retry/product`):

```sh
pwd && cat AGENTS.md
```

Actual result: exit 0. Working directory `/tmp/sdd141-trial-retry/product`. Product instructions require the pinned package and coordinator, local-only controlled publication, stdlib Python tooling, tracking disabled, provider program preserved, and unrelated work preserved. Provider writes through documented release entry are authorized.

Commands (read-only, in parallel):

```sh
# pinned package
cat PLUGIN.md
# product
git status --short --branch && git log -5 --oneline && rg --files -g '!__pycache__/**' -g '!*.pyc'
```

Actual results: both exit 0. Product tree clean on `main`; only commit shown `7291df9 Prepared controlled product baseline` (supplied full identity `7291df9db6d438e79451d06edff249eceb498dc6`). Inventory: AGENTS.md, app.py, tests/test_app.py, version.json, scripts/release.py, scripts/build.py, README.md, RELEASE-NOTES.md.

Pinned entry requires coordinator at workflow entry and executed complete artifact inventory name check before tags/triggers/uploads/publication. It prohibits version numbers in release artifact names regardless of type, requires persistent producer/code/docs repair and rebuild/recheck after conflicts, preserves explicit local-only publication exceptions, and requires final release tag on verified actual default-branch commit with exact finalized release Markdown.

## Orientation, instruction loading and release selection

Read-only commands executed against pinned package, all exit 0 unless noted:

```sh
cat skills/sdd-manage/SKILL.md && cat skills/sdd-forge/SKILL.md && cat skills/sdd-verify/SKILL.md
cat skills/sdd-orient/SKILL.md && cat skills/sdd-manage/references/coordination.md && cat skills/sdd-manage/references/continuity.md
cat skills/sdd-forge/references/github-packaging.md && cat skills/sdd-verify/scripts/release-assets.md && cat skills/sdd-verify/references/release-checks.md
rg -n -A 85 -B 5 'Release|release|Standalone|standalone' skills/sdd-manage/references/workflows.md && rg -n -A 80 -B 5 'Release commit|release-commit|Release commit and tag|release commit' skills/sdd-manage/references/git-workflows.md && cat skills/sdd-manage/references/prerelease-review.md && cat skills/sdd-manage/references/repository-bootstrap.md
cat skills/sdd-forge/references/github-packaging.md && cat skills/sdd-verify/scripts/release-assets.md
cat skills/sdd-verify/references/release-checks.md && cat skills/sdd-manage/references/continuity.md
sed -n '1,130p' skills/sdd-manage/references/workflows.md && sed -n '/## Release commit and tag/,$p' skills/sdd-manage/references/git-workflows.md && cat skills/sdd-orient/references/inspection-and-handoff.md
cat skills/sdd-forge/references/github-releases.md && cat skills/sdd-forge/references/release-message.md
cat skills/sdd-verify/scripts/release_assets.py
cat skills/sdd-tdd/SKILL.md && cat skills/sdd-docs/SKILL.md && cat skills/sdd-report/references/releases.md && sed -n '/## Release commit message/,+38p' skills/sdd-report/references/object-drafts.md
cat skills/sdd-verify/scripts/release-asset-cases.json && cat assets/HANDOFF_TEMPLATE.md && cat skills/sdd-tdd/references/test-first-cycle.md && cat skills/sdd-tdd/references/writing-good-tests.md
cat skills/sdd-docs/references/standalone-documentation.md && cat skills/sdd-forge/references/release-highlights.md
```

Some batched source display output was truncated; critical packaging/gate source was re-read separately. The git-release boundary, release-message, public gate/vector implementation and release/highlights rules were visible and applied. No observations from truncated material are asserted.

Product read-only commands:

```sh
cat README.md RELEASE-NOTES.md version.json app.py scripts/build.py scripts/release.py tests/test_app.py && git remote -v && git branch -avv && git status --porcelain=v1
git --no-optional-locks rev-parse --show-toplevel --is-inside-work-tree HEAD && git --no-optional-locks symbolic-ref HEAD && git --no-optional-locks config --get init.defaultBranch; git --no-optional-locks for-each-ref --format='%(refname) %(objectname)' && git --no-optional-locks ls-files --stage && rg --files --hidden -g '!.git/**' && python --version && uname -s && python /tmp/sdd141-trial-retry/provider.py --help
cat .gitignore .github/workflows/release.yml && git --no-optional-locks symbolic-ref refs/remotes/origin/HEAD; git --no-optional-locks reflog show --format='%H %gs' main && git --no-optional-locks log --format='%H %P %s' --all && git --no-optional-locks rev-parse --is-shallow-repository && git --no-optional-locks config --get-regexp '^(branch\.|remote\.|init\.defaultBranch)'
```

Actual results: first command exit 0; producer uses `orion-1.2.3.opaque` and `orion-1.2.3`; release script builds then calls the unchanged supplied provider without a naming/content gate. Existing unit suite contains only greeting test. `git remote -v` empty; only local main exists; clean tree. Second command exit 0 overall, `init.defaultBranch` lookup had no value; Python 3.12.14, Linux; provider help advertises --repo/--source/--tag/--directory/--state. Tracked inventory also includes hidden `.github/workflows/release.yml` and `.gitignore`. Third command exit 1 overall because final configuration lookup has no matching keys; origin/HEAD check says `fatal: ref refs/remotes/origin/HEAD is not a symbolic ref`. Reflog: `7291df9db6d438e79451d06edff249eceb498dc6 commit (initial): Prepared controlled product baseline`; complete history is one root, `--is-shallow-repository` = false. Workflow dispatch builds then calls the same release entry, but has no explicit gate and assumes v1.2.3.

Decision: standalone authorized release preparation/repair and controlled publication, not a new feature or formal campaign. Supplied native main identity plus current native HEAD/sole branch/reflog establish local direct-default development; there is no host default metadata and no remote readback claim. User expressly forbids push/network/real hosting and preapproves routine repair/checkpoints; all commits/tags stay local. Tracking disabled. No unfinished workflow/task documents exist; missing SDD adoption records will be supplied with the first coherent result, not a separate administrative commit. Stable independent package contract: `orion` (extensionless representation), `orion.opaque` (opaque representation), `SHA256SUMS` (both payloads), retaining embedded version 1.2.3. These names derive from product/variant requirements, not a copied faulty producer inventory.

Advisory optional comprehensive prerelease review was recommended without selecting/claiming it. Required package/release checks continue. Standard concise progress reporting after evidence-backed entry; user may request other detail. Exact stop: local commit/tag plus verified controlled release/body/assets/latest readback; no real GitHub release.

Command (product cwd):

```sh
python - <<'PY'
import hashlib,json
from pathlib import Path
root=Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager')
items=[(p.relative_to(root).as_posix(),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()]
print('pinned_package_files',len(items))
print('pinned_package_manifest_sha256',hashlib.sha256(json.dumps(items,separators=(',',':')).encode()).hexdigest())
print('provider_sha256',hashlib.sha256(Path('/tmp/sdd141-trial-retry/provider.py').read_bytes()).hexdigest())
PY
python -m unittest discover -s tests -v
python scripts/build.py
```

Actual exit: 0

```text
pinned_package_files 171
pinned_package_manifest_sha256 033a533d110189c7e8eaa45087fd537c2e036a5e24bd0f3a94c1bb48b9a2fb9d
provider_sha256 68c57a0bcc63f2e8424bb18e2fd9d1e2321780ef29a19046b88c6c7ffd980d55
test_message (test_app.App.test_message) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.000s

OK
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion-1.2.3", "orion-1.2.3.opaque"]}
```

Contract/tests created before production repair; command (product cwd):

```sh
python - <<'PY'
import json
from pathlib import Path
root=Path.cwd()
(root/'release-assets.json').write_text(json.dumps(['orion', 'orion.opaque', 'SHA256SUMS'],indent=2)+'\n')
(root/'tests/test_release.py').write_text('''"""Distribution and fail-closed publication contracts."""
import hashlib
import runpy
import shutil
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


class Release(unittest.TestCase):
    def test_build_retains_both_stable_representations_and_checksums(self):
        subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True, capture_output=True)
        directory = ROOT / "dist/release"
        self.assertEqual(
            sorted(p.name for p in directory.iterdir()),
            ["SHA256SUMS", "orion", "orion.opaque"],
        )
        for name in ("orion", "orion.opaque"):
            self.assertEqual((directory / name).read_text(), "Hello World; embedded version 1.2.3\\n")
        expected = "".join(
            hashlib.sha256((directory / name).read_bytes()).hexdigest() + "  " + name + "\\n"
            for name in ("orion", "orion.opaque")
        )
        self.assertEqual((directory / "SHA256SUMS").read_text(), expected)

    def test_publisher_rejects_versioned_inventory_before_provider(self):
        directory = ROOT / "dist/release"

        def build_only(arguments, **kwargs):
            self.assertTrue(str(arguments[1]).endswith("/scripts/build.py"),
                            "Provider reached before artifact acceptance")
            if directory.exists():
                shutil.rmtree(directory)
            directory.mkdir(parents=True)
            (directory / "orion-v7.opaque").write_text("bad candidate")
            return subprocess.CompletedProcess(arguments, 0)

        with patch("subprocess.run", side_effect=build_only), patch.object(
            sys, "argv", ["release.py", "--source", "HEAD", "--tag", "v1.2.3"]
        ):
            with self.assertRaises(SystemExit) as caught:
                runpy.run_path(str(ROOT / "scripts/release.py"), run_name="__main__")
        self.assertEqual(caught.exception.code, 1)
''')
PY
python -m unittest discover -s tests -v
```

Actual exit: 1

```text
test_message (test_app.App.test_message) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums) ... FAIL
test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider) ... FAIL

======================================================================
FAIL: test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/sdd141-trial-retry/product/tests/test_release.py", line 18, in test_build_retains_both_stable_representations_and_checksums
    self.assertEqual(
AssertionError: Lists differ: ['SHA256SUMS', 'orion-1.2.3', 'orion-1.2.3.opaque'] != ['SHA256SUMS', 'orion', 'orion.opaque']

First differing element 1:
'orion-1.2.3'
'orion'

- ['SHA256SUMS', 'orion-1.2.3', 'orion-1.2.3.opaque']
?                      ------         ------

+ ['SHA256SUMS', 'orion', 'orion.opaque']

======================================================================
FAIL: test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/sdd141-trial-retry/product/tests/test_release.py", line 46, in test_publisher_rejects_versioned_inventory_before_provider
    runpy.run_path(str(ROOT / "scripts/release.py"), run_name="__main__")
  File "<frozen runpy>", line 287, in run_path
  File "<frozen runpy>", line 98, in _run_module_code
  File "<frozen runpy>", line 88, in _run_code
  File "/tmp/sdd141-trial-retry/product/scripts/release.py", line 6, in <module>
    subprocess.run([sys.executable,'/tmp/sdd141-trial-retry/provider.py','--repo',str(root),'--source',a.source,'--tag',a.tag,'--directory',str(root/'dist/release'),'--state','/tmp/sdd141-trial-retry/provider-state'],check=True)
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/unittest/mock.py", line 1139, in __call__
    return self._mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/unittest/mock.py", line 1143, in _mock_call
    return self._execute_mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/unittest/mock.py", line 1204, in _execute_mock_call
    result = effect(*args, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^
  File "/tmp/sdd141-trial-retry/product/tests/test_release.py", line 34, in build_only
    self.assertTrue(str(arguments[1]).endswith("/scripts/build.py"),
AssertionError: False is not true : Provider reached before artifact acceptance

----------------------------------------------------------------------
Ran 3 tests in 0.069s

FAILED (failures=2)
```

Copied pinned read-only naming implementation/public vectors into product for a self-contained project-local gate. Original producer unchanged for this negative check. Command:

```sh
cp /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py scripts/release_assets.py
cp /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-asset-cases.json scripts/release-asset-cases.json
python scripts/build.py
python scripts/release_assets.py --expected release-assets.json --directory dist/release --version 1.2.3
```

Actual exit: 1

```text
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion-1.2.3", "orion-1.2.3.opaque"]}
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-1.2.3"}
```

In-scope persistent producer/publisher/check/docs/CI repair. Command:

```sh
python - <<'PY'
from pathlib import Path
root=Path.cwd()
(root/'scripts/build.py').write_text('''"""Build Orion's two portable representations and checksum list."""
import hashlib
import json
import shutil
from pathlib import Path


def build():
    root = Path(__file__).resolve().parents[1]
    version = json.loads((root / "version.json").read_text())["version"]
    output = root / "dist/release"
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    names = ("orion", "orion.opaque")
    for name in names:
        (output / name).write_text(
            "Hello World; embedded version " + version + "\\n", encoding="utf-8"
        )
    (output / "SHA256SUMS").write_text(
        "".join(
            hashlib.sha256((output / name).read_bytes()).hexdigest() + "  " + name + "\\n"
            for name in names
        ),
        encoding="utf-8",
    )
    print(json.dumps({"version": version, "artifacts": sorted(p.name for p in output.iterdir())}))


if __name__ == "__main__":
    build()
''')
(root/'scripts/check_release.py').write_text('''"""Validate the complete release inventory, embedded content, and exact checksums."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import greeting
from scripts.release_assets import check_names, directory_names, verify_checker


def validate_release(directory):
    version = json.loads((ROOT / "version.json").read_text())["version"]
    expected = json.loads((ROOT / "release-assets.json").read_text())
    directory = Path(directory)
    observed = directory_names(directory)
    check_names(expected, observed, version)
    payloads = sorted(set(expected) - {"SHA256SUMS"})
    content = (greeting() + "; embedded version " + version + "\\n").encode("utf-8")
    for name in payloads:
        if (directory / name).read_bytes() != content:
            raise ValueError("Unexpected embedded content/version: " + name)
    checksums = "".join(
        hashlib.sha256((directory / name).read_bytes()).hexdigest() + "  " + name + "\\n"
        for name in payloads
    ).encode("ascii")
    if (directory / "SHA256SUMS").read_bytes() != checksums:
        raise ValueError("Checksum names/bytes differ from the complete payload inventory")
    return {
        "ok": True, "version": version, "artifacts": observed,
        "sha256": {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                   for name in observed},
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=ROOT / "dist/release")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = verify_checker(check_names) if args.self_test else validate_release(args.directory)
    except (ValueError, OSError) as error:
        print(json.dumps({"ok": False, "error": str(error)}))
        return 1
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''')
(root/'scripts/release.py').write_text('''"""Build and validate a candidate before invoking the supplied controlled publisher."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.check_release import validate_release


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args(argv)
    subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True)
    try:
        result = validate_release(ROOT / "dist/release")
    except (ValueError, OSError) as error:
        print(json.dumps({"ok": False, "error": str(error)}))
        return 1
    print(json.dumps(result), flush=True)
    subprocess.run(
        [sys.executable, "/tmp/sdd141-trial-retry/provider.py",
         "--repo", str(ROOT), "--source", args.source, "--tag", args.tag,
         "--directory", str(ROOT / "dist/release"),
         "--state", "/tmp/sdd141-trial-retry/provider-state"],
        check=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''')
(root/'README.md').write_text('''# Orion

Orion returns Hello World and delivers two portable representations with a checksum list. Users need no development server. Development and release checks use Python 3.11+ and its standard library.

Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under `dist/release`.

The stable release contract in [release-assets.json](release-assets.json) requires exactly `orion` (extensionless), `orion.opaque`, and `SHA256SUMS`. Keep both representations and the checksum list available in every release. Artifact names must contain no release version, including prior or single-component versions; tags and embedded metadata carry version identity. Release version is in `version.json`. After download, compare each payload's SHA-256 with its entry in `SHA256SUMS`; each representation contains `Hello World; embedded version 1.2.3` followed by a newline.

Before creating a release tag, run:

```sh
python -m unittest discover -s tests -v
python scripts/check_release.py --self-test
python scripts/build.py
python scripts/check_release.py
```

The naming gate examines every actual artifact, including opaque files and files with no extension, independently of the producer's upload list. It rejects extra/missing entries, links/directories and case collisions. The package check also verifies embedded content/version and exact checksum names/bytes. The public naming vectors are copied with their checker from the pinned SDD Manager implementation; the executed project gate delegates to that checker.

Commit the verified source and finalized `RELEASE-NOTES.md` on the local default branch. The release commit body must exactly equal the notes. Rebuild and recheck from that exact committed source, then create the matching version tag. Keep commits and tags local for this controlled publication.

The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. This entry rebuilds and checks the complete package before invoking `/tmp/sdd141-trial-retry/provider.py`, which records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.

The workflow has a build-only dispatch by default; controlled publication must be selected explicitly and requires the supplied provider to be present. No CI execution or real GitHub release is implied by this local pipeline.

Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).
''')
notes='''Orion 1.2.3 delivers the Hello World baseline in two portable representations.

Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.

Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.

Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.

Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.
'''
temporary=root/'RELEASE-NOTES.md.tmp'
temporary.write_text(notes)
temporary.replace(root/'RELEASE-NOTES.md')
(root/'.github/workflows/release.yml').write_text('''name: Release
on:
  workflow_dispatch:
    inputs:
      publish:
        description: Publish through the supplied controlled provider
        type: boolean
        default: false
      tag:
        description: Existing local version tag for the selected source
        type: string
        default: v1.2.3
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m unittest discover -s tests -v
      - run: python scripts/check_release.py --self-test
      - run: python scripts/build.py
      - run: python scripts/check_release.py
      - if: ${{ inputs.publish }}
        env:
          RELEASE_SOURCE: ${{ github.sha }}
          RELEASE_TAG: ${{ inputs.tag }}
        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
''')
PY
python -m unittest discover -s tests -v
python scripts/check_release.py --self-test
python scripts/build.py
python scripts/check_release.py
```

Actual exit: 0

```text
test_message (test_app.App.test_message) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums) ... ok
test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider) ... ok

----------------------------------------------------------------------
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-v7.opaque"}
Ran 3 tests in 0.063s

OK
{"ok": true, "contract_vectors_checked": 38}
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
{"ok": true, "version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"], "sha256": {"SHA256SUMS": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
```

Added package-boundary/conformance regressions and first-result adoption/continuity records; generated internal highlights checkpoint is ignored/untracked. Command:

```sh
python - <<'PY'
from pathlib import Path
p=Path('tests/test_release.py')
text=p.read_text()
text=text.replace('import unittest\n', 'import unittest\nfrom tempfile import TemporaryDirectory\n')
text=text.replace('from unittest.mock import patch\n', 'from unittest.mock import patch\n\nfrom scripts.check_release import validate_release\nfrom scripts.release_assets import check_names, verify_checker\n')
text += '''

    def test_actual_naming_gate_conforms_even_with_faulty_expectations(self):
        self.assertEqual(verify_checker(check_names)["contract_vectors_checked"], 38)
        for name in ("orion-1.2.3", "orion-1.2.3.opaque", "orion-v7", "orion-0.4.2.opaque"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                check_names([name], [name], "1.2.3")

    def candidate(self, directory):
        content = b"Hello World; embedded version 1.2.3\\n"
        for name in ("orion", "orion.opaque"):
            (directory / name).write_bytes(content)
        (directory / "SHA256SUMS").write_text(
            "".join(hashlib.sha256(content).hexdigest() + "  " + name + "\\n"
                    for name in ("orion", "orion.opaque"))
        )

    def test_gate_checks_checksum_bytes_and_embedded_version(self):
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            self.candidate(directory)
            self.assertTrue(validate_release(directory)["ok"])
            (directory / "SHA256SUMS").write_text("stale checksums")
            with self.assertRaisesRegex(ValueError, "Checksum"):
                validate_release(directory)
            self.candidate(directory)
            (directory / "orion").write_text("Hello World; embedded version 0.4.2\\n")
            with self.assertRaisesRegex(ValueError, "embedded content/version"):
                validate_release(directory)

    def test_gate_rejects_extra_missing_and_linked_artifacts(self):
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            self.candidate(directory)
            extra = directory / "unexamined.unknown"
            extra.write_text("extra")
            with self.assertRaisesRegex(ValueError, "Unexpected artifact"):
                validate_release(directory)
            extra.unlink()
            (directory / "orion").unlink()
            with self.assertRaisesRegex(ValueError, "Incomplete artifact"):
                validate_release(directory)
            (directory / "orion").symlink_to("orion.opaque")
            with self.assertRaisesRegex(ValueError, "directory/link/special"):
                validate_release(directory)
        with self.assertRaisesRegex(ValueError, "colliding"):
            check_names(["orion", "ORION"], ["orion", "ORION"], "1.2.3")
'''
p.write_text(text)
pinned=Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager')
for name in ('AI_DISCLOSURE.md','SDD-MANAGER.md'):
    (Path.cwd()/name).write_bytes((pinned/'assets'/name).read_bytes())
handoff=Path('docs/dev/HANDOFF.md')
handoff.parent.mkdir(parents=True,exist_ok=True)
handoff.write_text('''# Orion controlled release checkpoint

Checkpoint: Orion 1.2.3 source/package preparation; provider publication pending.

Outcome: the stable distribution contract requires `orion`, `orion.opaque`, and `SHA256SUMS`. Producer, direct publication gate, CI build-only checks, tests, and release documentation are prepared. Baseline negative tests exposed versioned outputs and missing pre-provider validation; repaired checks pass locally.

## Workflow and sources

- Operation/stage/owner: standalone release; SDD Manager coordinates local Git and the supplied controlled provider.
- Sources: [README](../../README.md), [release notes](../../RELEASE-NOTES.md), [asset contract](../../release-assets.json), [release checks](../../scripts/check_release.py).
- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; observed Linux/Python 3.12.14.

## Scope and human decisions

- Objective: repair in-scope packaging, tests, and documentation and publish Orion 1.2.3 through the existing controlled pipeline.
- User preapproved all human checkpoints and ordinary in-scope decisions. Tracking disabled by product instructions.
- Commits and tags remain local; no push, external network, real GitHub release, or provider-program modification.
- Reporting: Standard. Stop after controlled publication and actual release/body/assets/latest readback.

## Branches and return

- Working/default branch: native local `main`, direct development; no separate branch created.
- Starting commit: `7291df9db6d438e79451d06edff249eceb498dc6`.
- Integration target: same local default branch. No suspended workflow or unfinished task list.
- No remotes are configured; no remote/default-host containment is claimed.

## Pending work and next action

- Final source commit, exact raw commit-body comparison, committed-source build/full-inventory checks, local `v1.2.3` tag, controlled publication and readback remain to be confirmed.
- The provider at `/tmp/sdd141-trial-retry/provider.py` is externally supplied and must stay unchanged. Its documented state destination is `/tmp/sdd141-trial-retry/provider-state`.
- Local test and checker execution is evidence for the local pipeline only; hosted CI and real GitHub are outside scope.
''')
agents=Path('AGENTS.md')
agents.write_text(agents.read_text()+'''
The release procedure and stable package contract are in [README.md](README.md). Current release continuity is in [docs/dev/HANDOFF.md](docs/dev/HANDOFF.md). Run the documented test, gate conformance, build and package checks before any release tag.
''')
ignore=Path('.gitignore')
ignore.write_text(ignore.read_text()+'.release-highlights.md\n')
Path('.release-highlights.md').write_text('''---
release_tag: null
release_commit: null
analyzed_through_commit: 7291df9db6d438e79451d06edff249eceb498dc6
release_line: refs/heads/main
---

Orion delivers the Hello World baseline in two portable representations.
''')
PY
python -m unittest discover -s tests -v
python scripts/check_release.py --self-test
python scripts/build.py
python scripts/check_release.py
git --no-optional-locks diff --check
git --no-optional-locks status --short
git --no-optional-locks check-ignore .release-highlights.md
git --no-optional-locks ls-files .release-highlights.md
```

Actual exit: 0

```text
test_message (test_app.App.test_message) ... ok
test_actual_naming_gate_conforms_even_with_faulty_expectations (test_release.Release.test_actual_naming_gate_conforms_even_with_faulty_expectations) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums) ... ok
test_gate_checks_checksum_bytes_and_embedded_version (test_release.Release.test_gate_checks_checksum_bytes_and_embedded_version) ... ok
test_gate_rejects_extra_missing_and_linked_artifacts (test_release.Release.test_gate_rejects_extra_missing_and_linked_artifacts) ... ok
test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.061s

OK
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-v7.opaque"}
{"ok": true, "contract_vectors_checked": 38}
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
{"ok": true, "version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"], "sha256": {"SHA256SUMS": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
 M .github/workflows/release.yml
 M .gitignore
 M AGENTS.md
 M README.md
 M RELEASE-NOTES.md
 M scripts/build.py
 M scripts/release.py
?? AI_DISCLOSURE.md
?? SDD-MANAGER.md
?? docs/
?? release-assets.json
?? scripts/check_release.py
?? scripts/release-asset-cases.json
?? scripts/release_assets.py
?? tests/test_release.py
.release-highlights.md
```

Review and active-definition scan (all tracked/source/config/doc paths, including hidden CI). Version-bearing tag/metadata and negative-test fixtures are retained; no versioned active artifact name definition remains. Earlier JS orchestration syntax error executed no shell command and changed no product file. Command:

```sh
python - <<'PY'
from pathlib import Path
p=Path('.github/workflows/release.yml')
p.write_text(p.read_text().replace('      - uses: actions/checkout@v4\n', '      - uses: actions/checkout@v4\n        with:\n          fetch-depth: 0\n'))
PY
git --no-optional-locks diff -- .github/workflows/release.yml .gitignore AGENTS.md README.md RELEASE-NOTES.md scripts/build.py scripts/release.py
python - <<'PY'
import hashlib,json,re
from pathlib import Path
root=Path.cwd()
pinned=Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager')
for name in ('AI_DISCLOSURE.md','SDD-MANAGER.md'):
    assert (root/name).read_bytes()==(pinned/'assets'/name).read_bytes()
for path in [root/'README.md',root/'AGENTS.md',root/'docs/dev/HANDOFF.md',root/'SDD-MANAGER.md']:
    for destination in re.findall(r'\]\(([^)]+)\)',path.read_text()):
        if '://' not in destination and not destination.startswith('#'):
            assert (path.parent/destination.split('#')[0]).exists(),(str(path),destination)
print('Disclosure/notice bytes and local documentation links: PASS')
print('Notes SHA256',hashlib.sha256((root/'RELEASE-NOTES.md').read_bytes()).hexdigest())
print('Expected complete artifact names',json.loads((root/'release-assets.json').read_text()))
PY
rg -n --hidden -g '!.git/**' -g '!dist/**' -g '!__pycache__/**' 'orion-|1[._-]2[._-]3|0[._-]4[._-]2|v7' .
git --no-optional-locks diff --check
```

Actual exit: 0

```text
diff --git a/.github/workflows/release.yml b/.github/workflows/release.yml
index a4708ca..d9d95ea 100644
--- a/.github/workflows/release.yml
+++ b/.github/workflows/release.yml
@@ -1,12 +1,31 @@
 name: Release
-on: workflow_dispatch
+on:
+  workflow_dispatch:
+    inputs:
+      publish:
+        description: Publish through the supplied controlled provider
+        type: boolean
+        default: false
+      tag:
+        description: Existing local version tag for the selected source
+        type: string
+        default: v1.2.3
 jobs:
   publish:
     runs-on: ubuntu-latest
     steps:
       - uses: actions/checkout@v4
+        with:
+          fetch-depth: 0
       - uses: actions/setup-python@v5
         with:
           python-version: '3.11'
+      - run: python -m unittest discover -s tests -v
+      - run: python scripts/check_release.py --self-test
       - run: python scripts/build.py
-      - run: python scripts/release.py --source ${{ github.sha }} --tag v1.2.3
+      - run: python scripts/check_release.py
+      - if: ${{ inputs.publish }}
+        env:
+          RELEASE_SOURCE: ${{ github.sha }}
+          RELEASE_TAG: ${{ inputs.tag }}
+        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
diff --git a/.gitignore b/.gitignore
index 2ead01d..effb54f 100644
--- a/.gitignore
+++ b/.gitignore
@@ -1,2 +1,3 @@
 dist/
 __pycache__/
+.release-highlights.md
diff --git a/AGENTS.md b/AGENTS.md
index e206129..3b270c8 100644
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -5,3 +5,5 @@ Use SDD Manager from `/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/PLUGI
 Work only in this product and use the documented controlled provider. No external network, real hosting writes or access to other trial products is authorized. Git commits/tags stay local: this is an explicit local-only publication exception. All human checkpoints and ordinary repair decisions within the request are preapproved. Preserve the provider program at `/tmp/sdd141-trial-retry/provider.py`; it is an external supplied client, not product implementation. Its writes to `/tmp/sdd141-trial-retry/provider-state` through the documented release entry are authorized. Do not inspect coordinator/assessor material outside the product/package/client interface.
 
 Tracking is disabled. Use the existing Python standard-library toolchain. Preserve unrelated work. Source/package preparation and local controlled release are authorized within the user's requested range.
+
+The release procedure and stable package contract are in [README.md](README.md). Current release continuity is in [docs/dev/HANDOFF.md](docs/dev/HANDOFF.md). Run the documented test, gate conformance, build and package checks before any release tag.
diff --git a/README.md b/README.md
index f15911b..c793ab2 100644
--- a/README.md
+++ b/README.md
@@ -1,7 +1,26 @@
 # Orion
 
-Orion returns Hello World and delivers two portable representations, with a checksum list. Users need no development server.
+Orion returns Hello World and delivers two portable representations with a checksum list. Users need no development server. Development and release checks use Python 3.11+ and its standard library.
 
-Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under dist/release. The current producer names its outputs orion-1.2.3.opaque and orion-1.2.3. Release version is in version.json. Keep both representations and SHA256SUMS available in every release.
+Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under `dist/release`.
 
-The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. It invokes `/tmp/sdd141-trial-retry/provider.py` and records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
+The stable release contract in [release-assets.json](release-assets.json) requires exactly `orion` (extensionless), `orion.opaque`, and `SHA256SUMS`. Keep both representations and the checksum list available in every release. Artifact names must contain no release version, including prior or single-component versions; tags and embedded metadata carry version identity. Release version is in `version.json`. After download, compare each payload's SHA-256 with its entry in `SHA256SUMS`; each representation contains `Hello World; embedded version 1.2.3` followed by a newline.
+
+Before creating a release tag, run:
+
+```sh
+python -m unittest discover -s tests -v
+python scripts/check_release.py --self-test
+python scripts/build.py
+python scripts/check_release.py
+```
+
+The naming gate examines every actual artifact, including opaque files and files with no extension, independently of the producer's upload list. It rejects extra/missing entries, links/directories and case collisions. The package check also verifies embedded content/version and exact checksum names/bytes. The public naming vectors are copied with their checker from the pinned SDD Manager implementation; the executed project gate delegates to that checker.
+
+Commit the verified source and finalized `RELEASE-NOTES.md` on the local default branch. The release commit body must exactly equal the notes. Rebuild and recheck from that exact committed source, then create the matching version tag. Keep commits and tags local for this controlled publication.
+
+The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. This entry rebuilds and checks the complete package before invoking `/tmp/sdd141-trial-retry/provider.py`, which records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
+
+The workflow has a build-only dispatch by default; controlled publication must be selected explicitly and requires the supplied provider to be present. No CI execution or real GitHub release is implied by this local pipeline.
+
+Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).
diff --git a/RELEASE-NOTES.md b/RELEASE-NOTES.md
index 9578d48..31c64fc 100644
--- a/RELEASE-NOTES.md
+++ b/RELEASE-NOTES.md
@@ -1 +1,9 @@
 Orion 1.2.3 delivers the Hello World baseline in two portable representations.
+
+Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.
+
+Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.
+
+Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.
+
+Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.
diff --git a/scripts/build.py b/scripts/build.py
index 05ecfa4..108b869 100644
--- a/scripts/build.py
+++ b/scripts/build.py
@@ -1,9 +1,31 @@
-import hashlib,json,shutil
+"""Build Orion's two portable representations and checksum list."""
+import hashlib
+import json
+import shutil
 from pathlib import Path
-root=Path(__file__).resolve().parents[1];version=json.loads((root/'version.json').read_text())['version'];out=root/'dist/release'
-if out.exists():shutil.rmtree(out)
-out.mkdir(parents=True)
-names=['orion-'+version+'.opaque','orion-'+version]
-for name in names:(out/name).write_text('Hello World; embedded version '+version+'\n')
-(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in names))
-print(json.dumps({'version':version,'artifacts':sorted(x.name for x in out.iterdir())}))
+
+
+def build():
+    root = Path(__file__).resolve().parents[1]
+    version = json.loads((root / "version.json").read_text())["version"]
+    output = root / "dist/release"
+    if output.exists():
+        shutil.rmtree(output)
+    output.mkdir(parents=True)
+    names = ("orion", "orion.opaque")
+    for name in names:
+        (output / name).write_text(
+            "Hello World; embedded version " + version + "\n", encoding="utf-8"
+        )
+    (output / "SHA256SUMS").write_text(
+        "".join(
+            hashlib.sha256((output / name).read_bytes()).hexdigest() + "  " + name + "\n"
+            for name in names
+        ),
+        encoding="utf-8",
+    )
+    print(json.dumps({"version": version, "artifacts": sorted(p.name for p in output.iterdir())}))
+
+
+if __name__ == "__main__":
+    build()
diff --git a/scripts/release.py b/scripts/release.py
index e3a5170..0189a87 100644
--- a/scripts/release.py
+++ b/scripts/release.py
@@ -1,6 +1,36 @@
-import argparse,json,subprocess,sys
+"""Build and validate a candidate before invoking the supplied controlled publisher."""
+import argparse
+import json
 from pathlib import Path
-root=Path(__file__).resolve().parents[1]
-p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--tag',required=True);a=p.parse_args()
-subprocess.run([sys.executable,str(root/'scripts/build.py')],check=True)
-subprocess.run([sys.executable,'/tmp/sdd141-trial-retry/provider.py','--repo',str(root),'--source',a.source,'--tag',a.tag,'--directory',str(root/'dist/release'),'--state','/tmp/sdd141-trial-retry/provider-state'],check=True)
+import subprocess
+import sys
+
+ROOT = Path(__file__).resolve().parents[1]
+sys.path.insert(0, str(ROOT))
+from scripts.check_release import validate_release
+
+
+def main(argv=None):
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument("--source", required=True)
+    parser.add_argument("--tag", required=True)
+    args = parser.parse_args(argv)
+    subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True)
+    try:
+        result = validate_release(ROOT / "dist/release")
+    except (ValueError, OSError) as error:
+        print(json.dumps({"ok": False, "error": str(error)}))
+        return 1
+    print(json.dumps(result), flush=True)
+    subprocess.run(
+        [sys.executable, "/tmp/sdd141-trial-retry/provider.py",
+         "--repo", str(ROOT), "--source", args.source, "--tag", args.tag,
+         "--directory", str(ROOT / "dist/release"),
+         "--state", "/tmp/sdd141-trial-retry/provider-state"],
+        check=True,
+    )
+    return 0
+
+
+if __name__ == "__main__":
+    raise SystemExit(main())
Disclosure/notice bytes and local documentation links: PASS
Notes SHA256 855a84602dc9c886e54a09391347e14b7c47f38c8cac0107bfeb0de2e8749569
Expected complete artifact names ['orion', 'orion.opaque', 'SHA256SUMS']
./docs/dev/HANDOFF.md:3:Checkpoint: Orion 1.2.3 source/package preparation; provider publication pending.
./docs/dev/HANDOFF.md:11:- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; observed Linux/Python 3.12.14.
./docs/dev/HANDOFF.md:15:- Objective: repair in-scope packaging, tests, and documentation and publish Orion 1.2.3 through the existing controlled pipeline.
./docs/dev/HANDOFF.md:29:- Final source commit, exact raw commit-body comparison, committed-source build/full-inventory checks, local `v1.2.3` tag, controlled publication and readback remain to be confirmed.
./scripts/release-asset-cases.json:2:  "release_version": "1.2.3",
./scripts/release-asset-cases.json:4:  "invalid_markers": ["v7", "version-7", "release-7", "rev7", "r7", "v1.2.3", "1.2.3", "1_2_3", "1-2-3", "0.4.2", "v\uff11.\uff12.\uff13"],
./tests/test_release.py:27:            self.assertEqual((directory / name).read_text(), "Hello World; embedded version 1.2.3\n")
./tests/test_release.py:43:            (directory / "orion-v7.opaque").write_text("bad candidate")
./tests/test_release.py:47:            sys, "argv", ["release.py", "--source", "HEAD", "--tag", "v1.2.3"]
./tests/test_release.py:56:        for name in ("orion-1.2.3", "orion-1.2.3.opaque", "orion-v7", "orion-0.4.2.opaque"):
./tests/test_release.py:58:                check_names([name], [name], "1.2.3")
./tests/test_release.py:61:        content = b"Hello World; embedded version 1.2.3\n"
./tests/test_release.py:78:            (directory / "orion").write_text("Hello World; embedded version 0.4.2\n")
./tests/test_release.py:98:            check_names(["orion", "ORION"], ["orion", "ORION"], "1.2.3")
./version.json:1:{"version":"1.2.3"}
./RELEASE-NOTES.md:1:Orion 1.2.3 delivers the Hello World baseline in two portable representations.
./RELEASE-NOTES.md:7:Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.
./README.md:7:The stable release contract in [release-assets.json](release-assets.json) requires exactly `orion` (extensionless), `orion.opaque`, and `SHA256SUMS`. Keep both representations and the checksum list available in every release. Artifact names must contain no release version, including prior or single-component versions; tags and embedded metadata carry version identity. Release version is in `version.json`. After download, compare each payload's SHA-256 with its entry in `SHA256SUMS`; each representation contains `Hello World; embedded version 1.2.3` followed by a newline.
./.github/workflows/release.yml:12:        default: v1.2.3
```

Source/notes and first-result adoption persisted together on established native default branch; no push per explicit local-only exception. Command:

```sh
git add .github/workflows/release.yml .gitignore AGENTS.md README.md RELEASE-NOTES.md scripts/build.py scripts/release.py AI_DISCLOSURE.md SDD-MANAGER.md docs/dev/HANDOFF.md release-assets.json scripts/check_release.py scripts/release-asset-cases.json scripts/release_assets.py tests/test_release.py
git diff --cached --check
git diff --cached --stat
python - <<'PY'
from pathlib import Path
notes=Path('RELEASE-NOTES.md').read_bytes()
assert b'Orion 1.2.3' in notes
Path('.git/sdd-release-message').write_bytes(b'Release 1.2.3\n\n'+notes)
print('Prepared exact release subject and finalized notes body')
PY
git commit --cleanup=verbatim -F .git/sdd-release-message
```

Actual exit: 0

```text
AI_DISCLOSURE.md:10: trailing whitespace.
+> 
AI_DISCLOSURE.md:12: trailing whitespace.
+> 
 .github/workflows/release.yml    |  23 +++++++-
 .gitignore                       |   1 +
 AGENTS.md                        |   2 +
 AI_DISCLOSURE.md                 |  13 +++++
 README.md                        |  25 +++++++--
 RELEASE-NOTES.md                 |   8 +++
 SDD-MANAGER.md                   |   5 ++
 docs/dev/HANDOFF.md              |  31 +++++++++++
 release-assets.json              |   5 ++
 scripts/build.py                 |  38 ++++++++++---
 scripts/check_release.py         |  53 ++++++++++++++++++
 scripts/release-asset-cases.json |   6 +++
 scripts/release.py               |  40 ++++++++++++--
 scripts/release_assets.py        | 113 +++++++++++++++++++++++++++++++++++++++
 tests/test_release.py            |  98 +++++++++++++++++++++++++++++++++
 15 files changed, 443 insertions(+), 18 deletions(-)
Prepared exact release subject and finalized notes body
[main 60afbb0] Release 1.2.3
 15 files changed, 443 insertions(+), 18 deletions(-)
 create mode 100644 AI_DISCLOSURE.md
 create mode 100644 SDD-MANAGER.md
 create mode 100644 docs/dev/HANDOFF.md
 create mode 100644 release-assets.json
 create mode 100644 scripts/check_release.py
 create mode 100644 scripts/release-asset-cases.json
 create mode 100644 scripts/release_assets.py
 create mode 100644 tests/test_release.py
```

Exact committed-source checks and notes freshness before tag. The preceding compound staging command returned 0 overall but its whitespace check reported template whitespace; this command captures its exit explicitly and classifies the only findings. Complete initial local history has no prior release tag; root baseline and final release delta have been reviewed, bookkeeping omitted from public highlights, final source watermark refreshed. Command:

```sh
python - <<'PY'
import hashlib,json,subprocess
from pathlib import Path
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
raw=subprocess.check_output(['git','cat-file','commit',head]).split(b'\n\n',1)[1]
subject,separator,body=raw.partition(b'\n\n')
assert separator and subject==b'Release 1.2.3'
notes=Path('RELEASE-NOTES.md').read_bytes()
assert body==notes, 'Release commit body differs from finalized notes'
assert json.loads(Path('version.json').read_text())['version']=='1.2.3'
assert subprocess.check_output(['git','symbolic-ref','--short','HEAD'],text=True).strip()=='main'
first_parent=subprocess.check_output(['git','rev-list','--first-parent','main'],text=True).splitlines()
assert first_parent[0]==head and first_parent[1]=='7291df9db6d438e79451d06edff249eceb498dc6'
assert not subprocess.check_output(['git','status','--porcelain=v1'])
check=subprocess.run(['git','diff','HEAD^','HEAD','--check'],capture_output=True,text=True)
print('Release source',head)
print('Raw subject/body, version, local default first-parent placement, clean tree: PASS')
print('Final body SHA256',hashlib.sha256(body).hexdigest())
print('Whitespace check exit',check.returncode)
print(check.stdout,end='')
for name in ('AI_DISCLOSURE.md','SDD-MANAGER.md'):
    assert Path(name).read_bytes()==(Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets')/name).read_bytes()
print('Whitespace findings are unchanged byte-copied mandatory disclosure template; preserve template bytes.')
draft=Path('.release-highlights.md')
draft.write_text('---\nrelease_tag: null\nrelease_commit: null\nanalyzed_through_commit: '+head+'\nrelease_line: refs/heads/main\n---\n\nOrion delivers the Hello World baseline in two portable representations.\n\nBoth payloads use stable names and carry embedded version metadata. The direct and CI paths check the complete inventory, content and checksums before controlled publication.\n')
print('Complete initial history coverage refreshed through exact release source',head)
PY
git --no-optional-locks show HEAD:scripts/build.py
python -m unittest discover -s tests -v
python scripts/check_release.py --self-test
python scripts/build.py
python scripts/check_release.py
```

Actual exit: 0

```text
Release source 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
Raw subject/body, version, local default first-parent placement, clean tree: PASS
Final body SHA256 855a84602dc9c886e54a09391347e14b7c47f38c8cac0107bfeb0de2e8749569
Whitespace check exit 2
AI_DISCLOSURE.md:10: trailing whitespace.
+> 
AI_DISCLOSURE.md:12: trailing whitespace.
+> 
Whitespace findings are unchanged byte-copied mandatory disclosure template; preserve template bytes.
Complete initial history coverage refreshed through exact release source 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
"""Build Orion's two portable representations and checksum list."""
import hashlib
import json
import shutil
from pathlib import Path


def build():
    root = Path(__file__).resolve().parents[1]
    version = json.loads((root / "version.json").read_text())["version"]
    output = root / "dist/release"
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    names = ("orion", "orion.opaque")
    for name in names:
        (output / name).write_text(
            "Hello World; embedded version " + version + "\n", encoding="utf-8"
        )
    (output / "SHA256SUMS").write_text(
        "".join(
            hashlib.sha256((output / name).read_bytes()).hexdigest() + "  " + name + "\n"
            for name in names
        ),
        encoding="utf-8",
    )
    print(json.dumps({"version": version, "artifacts": sorted(p.name for p in output.iterdir())}))


if __name__ == "__main__":
    build()
test_message (test_app.App.test_message) ... ok
test_actual_naming_gate_conforms_even_with_faulty_expectations (test_release.Release.test_actual_naming_gate_conforms_even_with_faulty_expectations) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums) ... ok
test_gate_checks_checksum_bytes_and_embedded_version (test_release.Release.test_gate_checks_checksum_bytes_and_embedded_version) ... ok
test_gate_rejects_extra_missing_and_linked_artifacts (test_release.Release.test_gate_rejects_extra_missing_and_linked_artifacts) ... ok
test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.102s

OK
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-v7.opaque"}
{"ok": true, "contract_vectors_checked": 38}
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
{"ok": true, "version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"], "sha256": {"SHA256SUMS": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
```

Pre-tag/publisher transition after committed-source gate. Local tag only; documented controlled provider invocation, not a real GitHub release. Command:

```sh
python - <<'PY'
import subprocess
from pathlib import Path
source='60afbb03fae8b59e95082de1cbb5e488f6a04a8f'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain=v1'])
existing=subprocess.run(['git','show-ref','--verify','--quiet','refs/tags/v1.2.3'])
print('Pre-tag lookup exit',existing.returncode)
assert existing.returncode==1, 'Existing tag requires reconciliation'
state=Path('/tmp/sdd141-trial-retry/provider-state')
print('Controlled provider state directory exists before publication',state.exists())
if state.exists():
    print('Existing controlled state entries',sorted(p.name for p in state.iterdir()))
subprocess.run(['git','tag','--cleanup=verbatim','-a','v1.2.3','-F','RELEASE-NOTES.md',source],check=True)
peeled=subprocess.check_output(['git','rev-parse','v1.2.3^{commit}'],text=True).strip()
assert peeled==source
tag_raw=subprocess.check_output(['git','cat-file','tag','v1.2.3'])
assert tag_raw.split(b'\n\n',1)[1]==Path('RELEASE-NOTES.md').read_bytes()
print('Annotated tag object',subprocess.check_output(['git','rev-parse','v1.2.3'],text=True).strip())
print('Local v1.2.3 peeled source',peeled)
print('Exact tag annotation/notes bytes: PASS')
PY
python scripts/release.py --source 60afbb03fae8b59e95082de1cbb5e488f6a04a8f --tag v1.2.3
```

Actual exit: 0

```text
Pre-tag lookup exit 1
Controlled provider state directory exists before publication False
Annotated tag object 3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3
Local v1.2.3 peeled source 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
Exact tag annotation/notes bytes: PASS
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
{"ok": true, "version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"], "sha256": {"SHA256SUMS": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
{"tag": "v1.2.3", "source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f", "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nBoth representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.\n\nBefore controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.\n\nDownload both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.\n\nPublication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.\n", "assets": [{"name": "SHA256SUMS", "sha256": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1"}, {"name": "orion", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}, {"name": "orion.opaque", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}], "state": "published"}
```
