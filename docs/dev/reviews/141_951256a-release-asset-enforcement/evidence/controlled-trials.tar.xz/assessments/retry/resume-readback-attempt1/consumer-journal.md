# Orion 1.2.3 continuation provenance

Fresh inspection; saved progress will be verified against repository and provider evidence.

## Command

```bash
pwd
```

```text
/tmp/sdd141-trial-retry/product
```

Exit status: 0

## Command

```bash
git status --short --branch
```

```text
## main
```

Exit status: 0

## Command

```bash
git log -6 --oneline --decorate
```

```text
60afbb0 (HEAD -> main, tag: v1.2.3) Release 1.2.3
7291df9 Prepared controlled product baseline
```

Exit status: 0

## Command

```bash
rg --files -g 'AGENTS.md' -g '!node_modules' -g '!vendor' -g '!dist' .
```

```text
./AGENTS.md
```

Exit status: 0

## Command

```bash
rg --files -g '!node_modules' -g '!vendor' -g '!dist' . | sort
```

```text
./AGENTS.md
./AI_DISCLOSURE.md
./README.md
./RELEASE-NOTES.md
./SDD-MANAGER.md
./app.py
./docs/dev/HANDOFF.md
./release-assets.json
./scripts/build.py
./scripts/check_release.py
./scripts/release-asset-cases.json
./scripts/release.py
./scripts/release_assets.py
./tests/test_app.py
./tests/test_release.py
./version.json
```

Exit status: 0

## Command

```bash
rg --files --hidden /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager | sort
```

```text
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/LICENSE
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/PLUGIN.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/README.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/AGENTS_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/AI_DISCLOSURE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/BROWSER_DEV_POLICY.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/DOCS_PREPARATION_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/DOCS_TASKS_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/DOCS_TRACKING_TEMPLATE.json
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/FEATURE_DOCS_TASKS_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/FEATURE_PREPARATION_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/Greenfield Project Prompt Template.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/HANDOFF_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/SDD-MANAGER.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/SKILL_DISCOVERY_PROTOCOL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/WINDOWS_SHELL_POLICY.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/ai-logs/AGENTS_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/ai-logs/EXPLORE_DRIVE_TEMPLATE.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/icon.png
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/logo.png
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/logo.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/playwright.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/assets/vite-worker-loading.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/plugin.json
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/backend-object-lifecycle.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/design-heuristics.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/development-document-qc.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/hosting-tokens.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/markdown-style.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/modularity.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/review-campaigns.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/task-hierarchy.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-conventions/references/workflow-identity.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/references/architecture.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/references/decomposition.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/references/exploration.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/references/feature-brief.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-design/references/project-brief.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/references/in-code-documentation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/references/review-and-findings.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/references/standalone-documentation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-docs-preparation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-feature-preparation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-issue-lifecycle.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-milestone-lifecycle.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-packaging.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-projection.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-release-workflows.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-releases.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-highlights.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-message.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-close.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-close.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project-draft.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project-input.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-runtime.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/github-client.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/projection-input.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/references/completion-and-checkpoints.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/references/environment-recovery.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/references/range-selection.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/references/startup-and-continuation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-implement/references/task-execution.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/references/feature-incorporation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/agent-orientation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/ai-logs.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/branch-management.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/continuity.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/coordination.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/credentials.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/doc-design-modes.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/document-qc-gates.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/examples.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/feature-delivery.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/feature-preparation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/git-workflows.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/human-document-review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/main-preparation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/phase-activation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/prerelease-review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/repository-bootstrap.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/review-and-revision.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/revision-modes.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/tracking-decision.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/workflows.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-auth-recover.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-auth-recover.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-process-supervisor.py
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-publish.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/protected-token.mjs
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/references/inspection-and-handoff.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/references/delivery-plan.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/references/physical-layout.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-plan/references/review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/campaign-artifacts.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/change-kinds.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/completion-reports.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/document-qc-reports.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/object-drafts.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/releases.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/references/change-specification.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/references/review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-specify/references/system-specification.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/references/amendment-execution.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/references/objective-and-impact.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-steer/references/verification-and-stop.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/references/conformance-review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/references/progress-review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tasks/references/task-derivation.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/LICENSE
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/references/test-first-cycle.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/references/testing-strategy.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/references/upstream-provenance.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-tdd/references/writing-good-tests.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/SKILL.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/agents/openai.yaml
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/assets/icon.svg
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/boundary-review.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/check-selection.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/execution-and-evidence.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/failure-assessment.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/release-checks.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-asset-cases.json
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-assets.md
/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py
```

Exit status: 0

## Command

```bash
cat AGENTS.md SDD-MANAGER.md docs/dev/HANDOFF.md README.md
```

```text
# Product instructions

Use SDD Manager from `/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/PLUGIN.md` and its coordinator. This pinned package is the instruction source for this trial.

Work only in this product and use the documented controlled provider. No external network, real hosting writes or access to other trial products is authorized. Git commits/tags stay local: this is an explicit local-only publication exception. All human checkpoints and ordinary repair decisions within the request are preapproved. Preserve the provider program at `/tmp/sdd141-trial-retry/provider.py`; it is an external supplied client, not product implementation. Its writes to `/tmp/sdd141-trial-retry/provider-state` through the documented release entry are authorized. Do not inspect coordinator/assessor material outside the product/package/client interface.

Tracking is disabled. Use the existing Python standard-library toolchain. Preserve unrelated work. Source/package preparation and local controlled release are authorized within the user's requested range.

The release procedure and stable package contract are in [README.md](README.md). Current release continuity is in [docs/dev/HANDOFF.md](docs/dev/HANDOFF.md). Run the documented test, gate conformance, build and package checks before any release tag.
# SDD Manager usage

This repository uses [SDD Manager](https://github.com/pchemguy/SDD-Manager), a plugin for specification-driven development, to assist its development workflow: project exploration and design, specifications, plans, task lists, implementation, verification, and reporting. Actual use is bounded by the accepted project scope and recorded development evidence; this notice does not claim that every workflow stage has been executed.

See [AI_DISCLOSURE.md](AI_DISCLOSURE.md) for the AI-assisted development disclosure. The project maintainer remains responsible for the published work. Use of SDD Manager does not imply endorsement or certification by its author.
# Orion controlled release checkpoint

Checkpoint: Orion 1.2.3 source/package preparation; provider publication pending.

Outcome: the stable distribution contract requires `orion`, `orion.opaque`, and `SHA256SUMS`. Producer, direct publication gate, CI build-only checks, tests, and release documentation are prepared. Baseline negative tests exposed versioned outputs and missing pre-provider validation; repaired checks pass locally.

## Workflow and sources

- Operation/stage/owner: standalone release; SDD Manager coordinates local Git and the supplied controlled provider.
- Sources: [README](../../README.md), [release notes](../../RELEASE-NOTES.md), [asset contract](../../release-assets.json), [release checks](../../scripts/check_release.py).
- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; observed Linux/Python 3.12.14.

## Scope and human decisions

- Objective: repair in-scope packaging, tests, and documentation and publish Orion 1.2.3 through the existing controlled pipeline.
- User preapproved all human checkpoints and ordinary in-scope decisions. Tracking disabled by product instructions.
- Commits and tags remain local; no push, external network, real GitHub release, or provider-program modification.
- Reporting: Standard. Stop after controlled publication and actual release/body/assets/latest readback.

## Branches and return

- Working/default branch: native local `main`, direct development; no separate branch created.
- Starting commit: `7291df9db6d438e79451d06edff249eceb498dc6`.
- Integration target: same local default branch. No suspended workflow or unfinished task list.
- No remotes are configured; no remote/default-host containment is claimed.

## Pending work and next action

- Final source commit, exact raw commit-body comparison, committed-source build/full-inventory checks, local `v1.2.3` tag, controlled publication and readback remain to be confirmed.
- The provider at `/tmp/sdd141-trial-retry/provider.py` is externally supplied and must stay unchanged. Its documented state destination is `/tmp/sdd141-trial-retry/provider-state`.
- Local test and checker execution is evidence for the local pipeline only; hosted CI and real GitHub are outside scope.
# Orion

Orion returns Hello World and delivers two portable representations with a checksum list. Users need no development server. Development and release checks use Python 3.11+ and its standard library.

Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under `dist/release`.

The stable release contract in [release-assets.json](release-assets.json) requires exactly `orion` (extensionless), `orion.opaque`, and `SHA256SUMS`. Keep both representations and the checksum list available in every release. Artifact names must contain no release version, including prior or single-component versions; tags and embedded metadata carry version identity. Release version is in `version.json`. After download, compare each payload's SHA-256 with its entry in `SHA256SUMS`; each representation contains `Hello World; embedded version 1.2.3` followed by a newline.

Before creating a release tag, run:

```sh
python -m unittest discover -s tests -v
python scripts/check_release.py --self-test
python scripts/build.py
python scripts/check_release.py
```

The naming gate examines every actual artifact, including opaque files and files with no extension, independently of the producer's upload list. It rejects extra/missing entries, links/directories and case collisions. The package check also verifies embedded content/version and exact checksum names/bytes. The public naming vectors are copied with their checker from the pinned SDD Manager implementation; the executed project gate delegates to that checker.

Commit the verified source and finalized `RELEASE-NOTES.md` on the local default branch. The release commit body must exactly equal the notes. Rebuild and recheck from that exact committed source, then create the matching version tag. Keep commits and tags local for this controlled publication.

The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. This entry rebuilds and checks the complete package before invoking `/tmp/sdd141-trial-retry/provider.py`, which records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.

The workflow has a build-only dispatch by default; controlled publication must be selected explicitly and requires the supplied provider to be present. No CI execution or real GitHub release is implied by this local pipeline.

Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/SKILL.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/SKILL.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/SKILL.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/SKILL.md
```

```text
---
name: sdd-manage
description: Coordinate SDD project development, document-design modes, feature preparation, bounded or resumed task implementation, checkpoint amendments, review/revision and accepted feature integration. Use for multi-stage requests, workflow selection or switching, shared prerequisites, branch and phase transitions, human decisions, stopping boundaries and hosted task synchronization. Also coordinate complete release-message preparation, Git release highlights, release package/workflow preparation and GitHub releases, plus hosting credentials and shell authentication recovery.
---

# Coordinate specification-driven development

## Role and scope

Translate the user's objective into a scoped workflow and coordinate the responsible skills. Establish context, select or recover the path, check shared readiness, pass work to its focused owner and return the reached boundary. These instructions support direct coordinator entry without requiring PLUGIN.md; load only the relevant skills and references.

Proactively identify relevant capabilities, unresolved decisions, coordination gaps and blockers at entry, preparation handoff, phase activation and completion. Apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md) to authored or reviewed Markdown, including direct calls.

## Shared gates

- **Authority:** Use the request and established decisions as authorization; proceed with routine work within that scope without repeated confirmation. Discussion, assessment or review alone does not authorize repairs. Check scope/instructions/pending decisions before each work unit and both path and proposed change before a user-file write under [scope checks](references/coordination.md#scope-checks-and-reporting-detail). Enter at the requested eligible stage and preserve the human's actual stopping boundary.
- **Execution host/tools:** Identify the actual execution OS and required tools under applicable user/repository instructions. Reuse sufficient current evidence, preserve orientation's read-only role and report concrete readiness blockers before dependent work. Apply [cross-platform verification scope](../sdd-verify/references/check-selection.md#cross-platform-artifacts-and-native-verification): unavailable target-native execution is out of scope by default, not a blocker to requested artifact delivery or remaining implementation.
- **Git and pending work:** Repository mutations require an eligible worktree and established change ownership. Read-only discussion/inspection can proceed outside Git. Preserve valid and unrelated work; dirty state alone does not justify reset. Apply [coordination prerequisites](references/coordination.md#establish-scope-and-prerequisites).
- **Continuity:** Load [checkpoint and recovery](references/continuity.md) at composite entry/reconstruction, milestone/phase review, revision finalization and nested/steering return, including focused calls affecting an active workflow. Maintain `docs/dev/HANDOFF.md` at those boundaries; recover later work from owning records and Git, without per-commit handoff updates.
- **Document content:** Enforce the [development-document content boundary](references/human-document-review.md#development-document-content-boundary) for every main/feature root and child, in every mode. Documents describe the project; DOCS_PREPARATION owns main-preparation mode/pass/cursor, decisions and evidence, while DOCS_TASKS contains tasks/checkoffs only. Other workflows retain their existing evidence owners. Carry this condition into author/reviewer handoffs.
- **Doc-design mode/pass control:** Before main or feature document preparation, select or recover **interactive/onepass** (default), **autodoc/onepass**, **autodoc with human-controlled multipass**, or **autodoc/autoloop**. Load [mode and pass control](references/doc-design-modes.md) at that selection and carry its approval/delegation basis, current scope/pass and stop into the document-owner handoff. Multipass delivery is **strict by default**, preserving earlier phase/task ranges; only explicit human permission selects **flexible** integration of small, fitting changes. Retain and hand off this independent choice. Predefined autodoc scope sequences default to autoloop unless human-controlled multipass is requested; do not infer future scopes.
- **Human document review:** Apply the selected mode and explicit scoped preapproval; otherwise pause after each necessary new FEATURE, PROJECT, ARCHITECTURE, DECOMPOSITION, SPEC, PLAN, layout and TASKS proposal under [human document review](references/human-document-review.md). Broad workflow authority does not preaccept new documents. Reuse acceptable existing inputs without mandatory interactive replay.
- **Release artifact names:** **Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** For an authorized release, require the executed [naming gate](../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) over every actual artifact before tagging, dispatch, upload or publication. Missing/failed evidence returns to producer repair and rebuild; an expected list or checksum pass cannot waive this gate. Established versioned names and explicit project policies/templates/examples must be corrected for the new release regardless of prior release count.
- **Publication:** [Push/read back every owned commit](references/git-workflows.md#publish-each-commit) before further work or another commit, including direct focused calls. Use the [supervised HTTPS publication entry](references/git-workflows.md#monitor-pending-git-operations) from the first attempt, with deterministic supplied-token/existing-auth selection; diagnose a stall without waiting for a human prompt. Unresolved publication blocks progression; the linked task-recovery exception permits only necessary correction/check/evidence work for an unsafe retained completion. Explicit scoped local-only/deferred instructions remain exceptions.
- **Task closure:** For TASKS/FEATURE-TASKS implementation, enforce the [task commit contract](../sdd-implement/references/completion-and-checkpoints.md#task-commit-contract): one executable task's verified result, evidence and initial owning checkbox close together. The implementation owner performs closure and the bounded [audit](../sdd-implement/references/completion-and-checkpoints.md#task-persistence-audit-and-recovery) on continuation and before applicable integration; resolve violations only within actual recovery authority. DOCS_TASKS initialization, first approvals and package QC follow [main preparation](references/main-preparation.md) under coordinator ownership.
- **Requested tracking:** Before implementation handoff, establish the [tracking decision](references/tracking-decision.md) and [phase activation](references/phase-activation.md). An explicit request is confirmation. Required objects/associations must be verified; pending or unknown projection blocks dependent execution. Pass the actual decision/readiness or blocker to the owner.
- **Preparation:** [Merge, verify and publish accepted preparation](references/branch-management.md#preparation-integration-gate) into the actual default branch before dependent implementation branching. Campaign plans/reports retain their revision branch.
- **Integration and stops:** Use the [eligible Git boundary](references/git-workflows.md): incomplete main phases push/pause; integrate only complete authorized boundaries. Human-requested implementation ranges define stops. Steering returns without task resumption; a completed child does not authorize parent continuation.
- **History:** Preserve [closed campaign records](../sdd-conventions/references/review-campaigns.md#closed-campaign-records) outside routine loading and validation; consult selected history only for a specific need. Load [revision modes](references/revision-modes.md) before nested work or selected eligible reopening, preserving suspension/return and actual authority.
- **Main preparation:** Load [main preparation](references/main-preparation.md) before any fresh/resumed main documentation repository write: enabled `sdd-docs-main` projection precedes writes; DOCS_TASKS owns the task definitions/checkoffs and DOCS_PREPARATION their control/decision evidence; published documentation integration precedes milestone closure and the final implementation checkpoint.
- **Bootstrap:** Load [repository bootstrap](references/repository-bootstrap.md) before greenfield exploration or the first SDD persistence operation; reuse valid disclosure/usage records and respect selected path limits.

## Coordination cycle

1. **Establish or recover the baseline.** Identify the project, objective, requested operation, authoritative inputs and stop. Reuse sufficient current evidence; obtain **sdd-orient**'s scoped repository/instruction/Git/pending-work observations where missing or stale. Establish that evidence before selecting and announcing the path. Refresh it only when material state or scope changes.
2. **Select, load and explain the path.** Apply [workflow selection and continuity](references/workflows.md#workflow-selection-and-continuity): choose the core workflow/variant or standalone operation, assess continuation, stage/range change or switching, and load its governing instructions before the definitive evidence-backed decision in chat or dependent work. Honor requested reporting detail and [profile](references/coordination.md#reporting-profiles) (Standard by default) while keeping consequential decisions and checkpoints visible under [reporting guidance](references/coordination.md#scope-checks-and-reporting-detail). At composite-workflow entry/switch or context reconstruction, use [Explicit bootstrap reporting](references/coordination.md#composite-workflow-bootstrap-reporting), explain available profiles and announce the subsequent level. Preserve narrow requests and ask only for consequential missing decisions. Routine unchanged continuation reuses its selection.
3. **Establish readiness and hand off.** Follow the [coordination protocol](references/coordination.md), applying the shared gates before dependent authoring/execution. Carry the actual scope, authority, accepted inputs, readiness, unresolved decisions and stop; load the selected owner's instructions. **sdd-implement** owns range selection, task execution and persistence; **sdd-steer** owns checkpoint amendments; **sdd-integrate-feature** owns accepted feature reconciliation. Report unavailable capabilities rather than claim they ran.
4. **Assess results and blockers.** Collect actual outputs, evidence, changed state and remaining differences under [coordination execution](references/coordination.md#coordinate-execution). Return repairs and unresolved decisions to their proper owner; governing-document amendments raised by **sdd-docs** remain with the human before authoring. A standalone verification/review does not start implementation.
5. **Persist, integrate and return.** Coordinate non-task repository persistence and eligible integration through [Git workflows](references/git-workflows.md); implementation/steering retain their own commit procedures. Use **sdd-report** and [return results](references/coordination.md#return-results) to distinguish planned, implemented, verified, committed, pushed and hosted states, report limits/pending decisions and stop at the authorized boundary.

## Reference routing

Use each reference's scope and load conditions below to select it before reading its contents.

### Context and coordination

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [workflows.md](references/workflows.md) | Core workflow/variant selection, read-only workflow loading, continuity, supporting operations and release dispatch | Workflow context is insufficient, a workflow explanation/loading is requested, a request may change the path/stage/stop, or highlights, complete messages, packaging or release publication is requested |
| [coordination.md](references/coordination.md) | Shared prerequisites, scope checks/reporting profiles, handoff payload, execution/persistence, results and environment recovery; focused skills retain their procedures | Coordinating scope/reporting, readiness, a handoff, blockers, non-task persistence or returned results |
| [examples.md](references/examples.md) | Representative requests and expected boundaries; examples do not grant authority | Checking a request interpretation or workflow boundary against a representative case |

### Preparation and adoption

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [agent-orientation.md](references/agent-orientation.md) | Root AGENTS.md maintenance preserving governing instructions | Creating/maintaining target-project orientation or updating affected instruction links |
| [feature-delivery.md](references/feature-delivery.md) | Feature phase/campaign branch mapping, incremental incorporation, phase integration/release and continuation | Selecting feature execution or crossing a feature phase/final integration boundary |
| [feature-preparation.md](references/feature-preparation.md) | Feature brief/records, FDOCS progression, mapped modes/reset, package QC, tracking and preparation handoff | Opening/resuming feature preparation or recording its decisions/acceptance |
| [main-preparation.md](references/main-preparation.md) | Main-only pre-write tracking, task/preparation-record ownership and adoption, initialization, approval persistence, package QC and final integration/checkpoint; document owners retain authoring | Entering/resuming main preparation, before its first repository write or a document completion/integration handoff |
| [repository-bootstrap.md](references/repository-bootstrap.md) | Initial exploration and disclosure/usage records; no implicit Git initialization | Before greenfield exploration or the first target-repository SDD commit |
| [ai-logs.md](references/ai-logs.md) | Manual-provenance scaffold setup and recovery; conversation recording remains manual | Before default provenance setup within DOCS-001, an explicit provenance request or recovery of an adopted scaffold |
| [human-document-review.md](references/human-document-review.md) | Development-document content boundary, entry review choice, new-document HIL and acceptable existing inputs | Authoring/reviewing development documents in any mode, entering/resuming preparation or resolving a pending/requested human review |
| [doc-design-modes.md](references/doc-design-modes.md) | Approval/loop selection, strict/flexible delivery preservation, stops, reset and pass recovery; main preparation retains task/QC ownership | Selecting/resuming main doc-design, revising prior-pass delivery ranges, reaching DOCS-008, or handling reset, predefined scope passes or mode steering |
| [document-qc-gates.md](references/document-qc-gates.md) | Technical SPEC/PLAN/layout/TASKS readiness, distinct from human acceptance | Before dependent preparation, implementation or hosted projection, or when affected inputs need reassessment |

### Execution and continuity

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [continuity.md](references/continuity.md) | Repository checkpoint, branch selection, recovery since checkpoint and parent return; focused owners retain their procedures | Entering/reconstructing a composite workflow, refreshing its checkpoint, returning from child/steering work or preparing a transfer |
| [branch-management.md](references/branch-management.md) | Actual branch identities, setup, preparation integration and phase transitions | Creating/reusing workflow branches or changing an integration/phase boundary |
| [git-workflows.md](references/git-workflows.md) | Per-commit publication, bounded operation monitoring, verified integration/recovery and release commit/tag persistence | Before publication/readback, when a pending Git operation needs diagnosis, or for eligible integration, Git/host recovery or release persistence |
| [credentials.md](references/credentials.md) | Deterministic Git credentials, repository token handling and helper/Git/API recovery; authentication is not operation authority | Before supervised HTTPS publication or credential handling/recovery; routes the bundled Node/Python publication utility and preserves pre-write gates |
| [tracking-decision.md](references/tracking-decision.md) | Optional hosting recommendation/confirmation and retained scope; separate from projection readiness | Establishing/recovering tracking choice before implementation handoff or handling an omitted requested gate |
| [phase-activation.md](references/phase-activation.md) | Eligible-phase hosted object/association verification and transition gates | Activating or reassessing required projection before task execution or a phase transition |

### Review and revision

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [prerelease-review.md](references/prerelease-review.md) | Explicit comprehensive prerelease review and advisory reminder; reminder does not activate review | A comprehensive prerelease review is selected or its release-readiness reminder is due |
| [revision-modes.md](references/revision-modes.md) | Nested parent suspension/return and authorized eligible reopening; ordinary history stays frozen | Opening work within an active campaign or selecting a closed-campaign amendment |
| [review-and-revision.md](references/review-and-revision.md) | Scoped review, accepted revision planning/execution and campaign evidence; assessment is distinct from repair | Planning/coordinating a review or accepted revision campaign, including direct focused amendments |
---
name: sdd-orient
description: Use when locating and inspecting a software project's repository before SDD work, checking execution OS/shell readiness, Git worktree and interrupted-task state, discovering governing instructions and development documents, or handing a scoped project orientation to an orchestrating agent. Read-only; report whether a proposed mutation has the required Git and authority baseline.
---

# Orient in a project

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Establish a factual, scoped starting point before another SDD skill changes repository files. This skill is a shared, **read-only** capability. It neither authorizes a mutation nor decides which later workflow to run. Read [inspection and handoff](references/inspection-and-handoff.md) for the evidence checks and report contract.

1. Establish the user's intended project path and proposed scope, if supplied. Distinguish the project root from its enclosing Git root; do not assume the current directory is the project. Identify the actual execution host/tools under [execution readiness](references/inspection-and-handoff.md#execution-os-and-tool-readiness). Follow applicable user/repository instructions and return observed readiness failures to sdd-manage without repairing the environment.
2. Read root/applicable nested AGENTS.md; assess concise orientation, command/link currency and execution-owner discoverability under **sdd-manage**'s [agent orientation](../sdd-manage/references/agent-orientation.md). Report missing/stale guidance without creating or editing it. Inspect root `SDD-MANAGER.md`, `AI_DISCLOSURE.md` and README links as adoption/disclosure evidence and report missing or conflicting records in the handoff; do not create them during orientation. Identify applicable repository instructions, including root and path-scoped `AGENTS.md`, referenced policies, and project-designated sources. Inspect `docs/dev/PROJECT.md` for the project brief; if it contains operating instructions, preserve their applicability and report their scope and any conflict.
3. Inspect Git, current branch or detached/unborn state, HEAD, worktree status, and changes affecting the intended paths. Suppress optional Git writes with command-scoped `git --no-optional-locks` or an equivalent scoped `GIT_OPTIONAL_LOCKS=0`. Git commands must not change the index, branch, working tree, or configuration.
4. Inspect the HANDOFF checkpoint, relevant later decision/task evidence and available workflow refs under [inspection and handoff](references/inspection-and-handoff.md#continuity-checkpoint). Report candidate parents, containment and remote-state uncertainty to the coordinator without selecting/fetching/switching branches. Inspect adjacent SPEC/PLAN/TASKS (and selected feature) review reports, finding/gate state and reviewed/governing identities; report absent or apparently stale readiness without performing QC or writing reports. Discover present development documents and their focused children, the active feature or change context, relevant code and tests, and declared project commands. When a task list exists, identify the last committed task and compare it with the owning checklist, pending changes, and existing verification evidence. Distinguish completed work awaiting commit from incomplete work; pass the identified state to **sdd-implement** for continuation.
5. Produce the scoped orientation report. Separate observed facts from inferences and unknowns, identify concrete blockers, and state whether the Git prerequisite for a contemplated mutation is met. Re-orient when the project path, target scope, HEAD, instructions, or material worktree state changes.

Use current governing documents and the active campaign for routine orientation. Do not load prior campaign documents unless the current task specifically needs their historical context; then read only the relevant records/sections. Identity/path discovery does not require reading historical contents. Apply the [closed-record boundary](../sdd-conventions/references/review-campaigns.md#closed-campaign-records).

If the target is outside a usable Git worktree, mark **repository mutation blocked**. Do not initialize Git, create files, clean worktrees, restore files, run tests with side effects, commit, or invoke a mutating workflow. A conversational or read-only inspection may continue.

For a subagent, the orchestrator supplies the applicable path scope, instructions, relevant document authorities, Git baseline, known dirty paths, and prohibited mutations. A subagent can inspect additional evidence within its scope; the orchestrator rechecks the overall state before coordinating any mutation or commit.

For feature preparation, observe FEATURE, task-only FEATURE_DOCS_TASKS, FEATURE_PREPARATION mode/pass/acceptance evidence and FEATURE-QC-REPORT readiness and next boundary under [feature preparation](../sdd-manage/references/feature-preparation.md), without authoring. For main/feature preparation, observe actual document progress and pending human instructions under [human document review](../sdd-manage/references/human-document-review.md). For main preparation, inspect DOCS_TASKS for task definitions/checkoffs and DOCS_PREPARATION for mode/pass, initialization/approval evidence and pending effects, together with actual document, QC, Git and hosted state under [main preparation](../sdd-manage/references/main-preparation.md); orientation remains read-only. Pass the next unfinished stage and any selected review to the coordinator; absent retrospective acceptance evidence alone does not require interactive replay. Keep readiness observation separate from authoring and substantive owner QC.
---
name: sdd-forge
description: Use when projecting software-development phases, milestones, and tasks to a hosted repository; creating or reconciling GitHub labels, milestones, and task issues; finding an issue for a task ID; or closing verified task issues and milestones, reopening invalidated milestones, or recovering interrupted hosted transitions. Also use for provider-independent complete release-message preparation, Git release highlights and incremental highlights drafts, GitHub release package assessment, release workflow preparation or dispatch, release creation and interrupted release recovery. GitHub is the available backend. Ordinary local Git and SDD work does not require hosting access.
---

# Git release preparation and hosted operations

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

## Shared protocol

- **Feature preparation:** For selected preparation tracking use [GitHub feature preparation](references/github-feature-preparation.md), through the backend prerequisites: campaign-specific milestone/nine FDOCS issues, exact source/readback, mapped pass reset and published integration before milestone closure. FEATURE_DOCS_TASKS holds checkoffs; FEATURE_PREPARATION owns control/evidence. Existing docs-main utilities are not feature projection tools.
- **Main preparation:** Before enabled main documentation repository writes, use [GitHub main preparation](references/github-docs-preparation.md), after its parent backend prerequisites, for `sdd-docs-main` and nine issues from the bundled JSON definitions. DOCS_TASKS contains task definitions/checkoffs; DOCS_PREPARATION supplies active-pass approval/control evidence; explicit cursor reset reopens the same DOCS-002–009 issues under that lifecycle. Autodoc stops leave package QC/milestone completion pending; final milestone closure follows verified published documentation integration. Product PLAN/TASKS and implementation-phase activation are not prerequisites for this separate preparation operation.
- **Scope:** Run only for a requested hosted operation or release/package preparation, including local Git release highlights. Route shared highlights before provider selection; identify the provider before loading a hosted backend; report ambiguous remotes or unsupported providers without guessing. Local preparation/inspection and workflows without selected tracking need no hosted activation; requested/confirmed tracking retains the manager's phase execution gates.
- **Release artifacts:** **Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before tagging, publishing triggers, uploads or publication, enforce the independent [artifact-name gate and repair](references/github-packaging.md#artifact-name-gate-and-repair). Require stable version-free actual names, project-local direct/CI checks and current passing evidence; route failing scripts/related code/tests/docs through authorized repair, source publication, rebuild and recheck, then finish the requested release/readback. Correct every conflicting active project naming policy/template/example even when previous releases used it; never carry prohibited legacy aliases into the new release. Preserve narrower stops and existing-tag/immutable recovery.
- **Hierarchy:** For implementation task tracking, use the **sdd-conventions** task hierarchy to read phase, milestone, and task IDs and names from TASKS or the active FEATURE-TASKS and preserve their parentage in the host projection. The selected backend defines its concrete objects.
- **Coordination:** Before a local draft edit or hosted mutation, **sdd-manage** coordinates the user's request and a current **sdd-orient** handoff establishing the eligible Git worktree and governing instructions. Read-only inspection needs no Git mutation gate.
- **Credentials:** Use the available authenticated client or a suitable supplied token. **sdd-manage** discovers, accepts, and persists tokens under **sdd-conventions**' **Hosting tokens** rules and recovers the affected client's authentication when needed. A direct caller may supply a token to **sdd-forge**. Consume it through a protected mechanism without ordinary handoff/output exposure; Git shell authentication does not prove API-client access. The selected backend defines provider-specific checks and permission requirements.
- **Access failure:** For a backend access-related 403, request a suitable token from **sdd-manage** and return the endpoint, required access, and any provider-indicated non-credential cause without exposing the credential. The coordinator checks credential suitability and identifies any policy or other restriction requiring a different remedy; escalation does not require substituting a token when the existing credential is suitable. For direct use without **sdd-manage**, ask the user. Recheck access before retrying; a replacement token does not establish permission by itself.
- **Operational failure:** Let the selected backend distinguish access failures, rate limits, service/transport outages, invalid requests, and uncertain writes. Preserve successful independent results and return pending/unknown effects with bounded retry or deferred-reconciliation context; do not route every 403 to credential replacement.
- **Handoff:** Return the repository, requested operation, changed objects, checks, access failures and remaining differences. Tracking returns task/issue associations; release work returns package/source/tag, workflow/run, release/assets/URLs and actual latest state. Local file preparation returns changed files to sdd-manage for Git persistence. Hosted state does not itself establish task completion or downloaded-byte verification.

Do not create commits, push branches, or create or merge pull requests here.

Add a backend only when it supports a concrete hosted operation with its own repository resolution, authentication, object mapping, and reconciliation rules. Give it a focused reference and explicit trigger; do not advertise a provider before its workflow is defined.

## Shared release preparation

For requested release creation/completion or a publishing workflow run, apply sdd-manage's shared [advisory prerelease review reminder](../sdd-manage/references/prerelease-review.md#advisory-release-reminder), including direct calls. Reuse its handoff disposition when already covered by the coordinator.

For requests to prepare, draft, assemble or update a release message or release notes, load [complete release-message preparation](references/release-message.md). Coordinate source/output ownership through manage, collect Git highlights, and use report to assemble the full message with applicable compatibility, installation and limitation sections. Retain the complete message, normally finalized at root `RELEASE-NOTES.md`; an active revision campaign may stage it within its directory for placement in the release commit. Preparation stops before publication. Editing-only requests remain scoped to supplied text.

For “collect key changes since the latest release,” highlights-only preparation or incremental highlights, load [Git release highlights](references/release-highlights.md). Pin the release-tag baseline and target, collect complete range identities/parents/subjects, read integration summaries first (latest adequate cumulative summary for reopened campaigns) and resolve direct/uncovered changes with targeted evidence, curate an ignored YAML-checkpointed draft and return body-only notes. No provider, token, tracking or TASKS is required. Release creation consumes this shared workflow; preparation alone stops before publication. Keep draft cleanup tied to verified published-body consumption.

## Available backends

- **GitHub:** Read [GitHub backend](references/github.md) when the requested operation targets a GitHub repository. It resolves repository identity and access, then routes tracking, package/workflow preparation and release lifecycle operations. An available [GitHub CLI](references/github.md#github-cli) may perform supported operations with suitable existing or provided/saved-token authentication. Apply the shared backend object lifecycle for tracking; standalone release requests need no task hierarchy or tracking activation. Package preparation does not implicitly publish a release.

For hosted operations, carry the confirmed request scope, destination/object identity and explicit limits through the [coordination handoff](../sdd-manage/references/coordination.md#coordinate-execution). Keep credentials protected and optional tracking activation separate from access capability.

## Optional local tracking utilities

For canonical-list input authoring and eligible phase or main-preparation projection with local Node 22+ and Git, select the [input-authoring workflow](scripts/forge-project-input.md) and [projection utility](scripts/forge-project.md). Phase drafting extracts structure for agent-authored dependencies/briefs and retains an explicit reviewed request. For routine `docs-main`, prefer the single-call projection entry with repository DOCS_TASKS and origin defaults; its guide defines bootstrap template fallback, explicit overrides and the required apply eligibility confirmation. The agent reviews outgoing content and the coordinator establishes actual eligibility. Preparation drafting before its pre-write gate keeps files outside the target repository. Exact conflicts/unsupported scopes retain the existing backend procedures.

For eligible completed implementation task/milestone reconciliation with local Node 22+, Git and an eligible ignored repository token, the backend can select [forge-close.mjs](scripts/forge-close.mjs) under its [CLI and handoff contract](scripts/forge-close.md). Load the backend and selected lifecycle first; the utility performs bounded mechanics, while execution/coordination establishes actual acceptance/publication and exclusive ownership. Consume known/unknown effects and use reconcile-only for uncertain prior writes. Other clients and unsupported scopes retain their existing backend procedures.

## Supporting modules

Load the [GitHub backend](references/github.md) first for these operations; it supplies identity/access prerequisites and routes the selected module. Load only the relevant support module and its stated dependencies, including for a direct request. Shared local highlights and release-message preparation keep their routes above.

| Module | Purpose and boundary | Route through | Load when |
| --- | --- | --- | --- |
| [github-packaging.md](references/github-packaging.md) | Package contents, archive assessment and names; preparation only | [github.md](references/github.md) | Assessing or developing GitHub release packaging |
| [github-release-workflows.md](references/github-release-workflows.md) | Workflow authoring, dispatch and monitoring within requested effects | [github.md](references/github.md); package contract as required | Preparing, inspecting or running a release workflow |
| [github-releases.md](references/github-releases.md) | Release reconciliation, upload, publication and readback | [github.md](references/github.md); accepted package contract | Creating, completing, inspecting or recovering a release |
| [github-projection.md](references/github-projection.md) | Eligible-phase labels, native milestones and task issues | [github.md](references/github.md) | Creating or reconciling the selected task hierarchy |
| [github-feature-preparation.md](references/github-feature-preparation.md) | Campaign-specific feature preparation milestone/nine FDOCS issues, completion/reset and integration-before-closure | [github.md](references/github.md) | Projecting/reconciling selected feature documentation preparation |
| [github-docs-preparation.md](references/github-docs-preparation.md) | Main preparation milestone/nine issues, current-pass closure, explicit reset reopening and merge-before-milestone completion | [github.md](references/github.md) | Projecting or reconciling main documentation preparation, including its early pre-write gate |
| [github-milestone-lifecycle.md](references/github-milestone-lifecycle.md) | Milestone closure, reopening and backlog reconciliation | [github.md](references/github.md) | Reconciling milestone completion or invalidation |
| [github-issue-lifecycle.md](references/github-issue-lifecycle.md) | Exact task/issue identity and verified issue-state changes | [github.md](references/github.md) | Resolving a task issue or closing/reopening it |
---
name: sdd-verify
description: Use when selecting and running checks for an SDD task, selected change, milestone, phase, or project; assessing acceptance and exit-condition coverage; classifying observed failures; performing read-only milestone/phase implementation code review, checking Git release-highlight ranges and drafts, release package contents, release workflows, CI outputs and hosted asset integrity; or returning verification evidence and remaining gaps before completion.
---

# Verify a selected work boundary

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** For package/release checks, validate every actual name without type/extension filtering through the [independent naming gate](../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair). Matching manifests/checksums cannot waive it.

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

For whole-feature preparation QC, use the coordinator's [FDOCS-009 contract](../sdd-manage/references/feature-preparation.md#final-package-qc-integration-and-checkpoint): assess the complete delta plus affected accepted main context and retain FEATURE-QC-REPORT. Do not infer package readiness from individual document reports or implement repairs outside the selected scope.

Establish the requested task, change, milestone, phase, or project scope. Load the relevant references:

| Work | Load |
| --- | --- |
| Review milestone/phase implementation code and findings | [boundary review](references/boundary-review.md) |
| Derive checks from requirements, changes, and dependencies | [check selection](references/check-selection.md) |
| Execute a complete-inventory artifact-name check; select the project check or Python helper | [executed naming gate](scripts/release-assets.md) |
| Assess Git highlights, package contents, release workflows, CI outputs and hosted download evidence | [package and release checks](references/release-checks.md) |
| Execute checks and assess acceptance evidence | [execution and evidence](references/execution-and-evidence.md) |
| Classify failures and return unresolved work | [failure assessment](references/failure-assessment.md) |

Use a current **sdd-orient** handoff for governing instructions, Git state, dirty-path ownership, relevant documents, and declared commands. **sdd-manage** coordinates the requested scope and execution prerequisites; the active implementation workflow, **sdd-implement** for main task work or **sdd-steer** for a checkpoint amendment, requests verification within its boundary. For standalone package/release work, use accepted source/build/package inputs without inventing TASKS; load release checks. Otherwise read the owning TASKS or FEATURE-TASKS, relevant SPEC contracts, PLAN exit conditions, design and layout, actual changes, tests, and existing evidence as needed. Read-only check planning can precede execution; commands with side effects require the established eligible Git worktree and authorized environment.

For main documentation package QC, use [main preparation](../sdd-manage/references/main-preparation.md#final-package-qc-integration-and-checkpoint) and DOCS-009 in DOCS_TASKS, not the implementation task/audit lifecycle. Assess the current whole document set, DOCS_TASKS checkoffs and DOCS_PREPARATION control/decision evidence; return the passing/blocked DOCS-QC-REPORT to the coordinator for repairs, checked-task persistence, publication and hosted closure. Ordinary later edits retain first-approval completion; an explicit cursor reset invalidates DOCS-002–009 for the next pass. Before package QC, verify the [selected mode/range permits DOCS-009](../sdd-manage/references/doc-design-modes.md#complete-a-pass); autodoc’s DOCS-008 stop does not select it.

For an explicit boundary review task, load boundary review and assess implementation code separately from test execution. Neither activity substitutes for the other. Return findings and recheck evidence without repairs or task/hosted state changes.

1. Identify the acceptance and exit conditions to verify and the implementation state being checked.
2. Select sufficient direct, dependent, integration, and boundary checks. Use project commands and an existing verification map where useful; neither a map nor new scripts are required.
3. Establish representative environment capabilities for the planned checks through check selection; load its browser guidance only for relevant browser work. Run the selected checks and inspect actual outcomes, including failures, warnings, skips, and collection counts where relevant.
4. Associate each condition with evidence and any limitation. Distinguish verified, failed, blocked, and not checked conditions; passing checks do not establish acceptance they never exercised.
5. Classify observed failures where evidence permits and return remaining work to its owner. Do not silently omit an unrelated or pre-existing failure from the results.

**sdd-tdd** owns testing strategy and test design or changes; this skill assesses coverage and executes the verification campaign. **sdd-docs** owns documentation maintenance. The active workflow owns repair coordination, completion, persistence and hosted closure: **sdd-manage** for main preparation, **sdd-implement** or **sdd-steer** for implementation. Leave source, tests, governing documents, and task status unchanged during verification; report necessary changes rather than repairing them here. Account for command-generated artifacts and preserve unrelated pending work.

Return the boundary and implementation state, conditions assessed, check selection and rationale, commands and environment, observed outcomes and evidence locations, failure classifications, omitted or blocked checks, and remaining gaps. **sdd-report** owns presentation of these facts. Existing task evidence or a project-designated record may hold durable results; no separate verification journal is required. State when the selected conditions are verified without equating that finding with task completion or whole-project correctness.
```

Exit status: 0

## Command

```bash
rg --files --hidden docs .github .agents 2>/dev/null
```

```text
.github/workflows/release.yml
docs/dev/HANDOFF.md
```

Exit status: 2

## Command

```bash
python3 /tmp/sdd141-trial-retry/provider.py --help
```

```text
usage: provider.py [-h] --repo REPO --source SOURCE --tag TAG --directory
                   DIRECTORY --state STATE

options:
  -h, --help            show this help message and exit
  --repo REPO
  --source SOURCE
  --tag TAG
  --directory DIRECTORY
  --state STATE
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/PLUGIN.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-orient/SKILL.md
```

```text
---
name: sdd-manager
displayName: SDD Manager
---

# SDD Manager

SDD Manager provides specification-driven development workflows for Git projects through focused skills. This entry orients the agent and routes workflow and capability requests. Each skill's `SKILL.md` owns its procedure; `references/*.md` supply selectively loaded sub-workflows. The [README](README.md) explains capabilities and workflows to humans.

**`sdd-manage` is SDD Manager’s workflow coordinator. Generally load its [entry](skills/sdd-manage/SKILL.md) alongside `PLUGIN.md` before other skills at workflow entry.**

Read an available `PLUGIN.md` explicitly when the client has not loaded it and entry guidance is needed. If it is unavailable, use the coordinator and skill entries directly. This is a non-standard entry convention, not a guarantee of automatic discovery. Bundled skills use relative Markdown links and named handoffs; load only relevant entries and references.

## Establish the request and context

Identify the actual execution host and available tools at startup, following applicable user and repository instructions. Orientation observes read-only.

For a new development, functionality, review or revision request without sufficient workflow context, use `sdd-manage` to establish project state and select the path. Use [sdd-orient](skills/sdd-orient/SKILL.md) when current repository evidence is insufficient. Select by purpose; new, existing or interrupted state determines the eligible stage, not the workflow by itself.

| Core workflow | Purpose |
| --- | --- |
| Main development | Define and deliver the whole project, reusing sufficient accepted inputs. |
| Feature | Add a bounded capability to an existing system. |
| Revision | Correct, simplify or improve defined or implemented work. Steering is its focused variant at a paused implementation checkpoint. |

Follow the coordinator's [selection and continuity](skills/sdd-manage/references/workflows.md#workflow-selection-and-continuity). At entry or a material routing/boundary change, explain the selected workflow or standalone operation, its request/project evidence, current stage/owner, authorized outputs and next checkpoint in chat.

A request to read/explain a workflow before development uses the coordinator's [workflow-loading operation](skills/sdd-manage/references/workflows.md#workflow-loading): report actual sources, stages/checkpoints, scope and next step in chat, then stop without project changes.

Check scope before work and both the path and proposed change before writes. Honor requested reporting detail: omit unchanged context and routine explanation when brevity is requested, while preserving consequential decisions, blockers, verification and human checkpoints. Use Standard reporting by default; “minimal reporting” or “explicit reporting” selects the corresponding [profile](skills/sdd-manage/references/coordination.md#reporting-profiles). Follow [scope checks and reporting detail](skills/sdd-manage/references/coordination.md#scope-checks-and-reporting-detail); an unchanged turn needs no repeated full brief.

At composite-workflow entry, material switching or context reconstruction, the coordinator uses [Explicit bootstrap reporting](skills/sdd-manage/references/coordination.md#composite-workflow-bootstrap-reporting), briefly explains the profiles and announces Standard for subsequent work unless a human preference is established. Routine continuation does not repeat this introduction.

**Established workflow and skill context normally resolves follow-ups.** A request to implement through a milestone belongs to `sdd-implement` in that context; it does not require plugin re-entry or a repeated selection brief. If context cannot identify a clear workflow/owner, use `sdd-manage` to recover it. Recover discoverable state; ask only for consequential missing decisions. Do not guess lost approvals, ranges or integration authority, or require the user to name lower-level skills.

Preserve narrow direct/standalone requests, pending decisions and unfinished work. Read-only discussion/inspection may proceed without Git; repository mutations require an eligible worktree and do not implicitly initialize Git.

**Product development documents must describe the project, not their preparation workflow.** Apply the [development-document content boundary](skills/sdd-manage/references/human-document-review.md#development-document-content-boundary) to every main/feature root and focused child, in every mode. Keep documentation-pass sequencing, cursor and approval/reset state in DOCS_PREPARATION for main preparation, in FEATURE_PREPARATION for new feature preparation, or revision evidence. DOCS_TASKS holds tasks/checkoffs only. Check these boundaries during authoring and review.

## Human checkpoints and Git publication

**Push every workflow-owned commit and verify remote containment before further work or another commit.** This includes completed documents, tasks, review reports, revision actions and merges. A failed push blocks progression. A retained implementation task completion with known failure or uncertain eligibility first follows [publication preflight](skills/sdd-implement/references/startup-and-continuation.md#push-before-task-work); only bounded authorized recovery/corrective persistence may precede its safe publication. Follow [per-commit publication](skills/sdd-manage/references/git-workflows.md#publish-each-commit); preserve explicit human-directed local-only or deferred-publication exceptions.

**At each necessary document checkpoint, publish the reviewable proposal and its selected artifacts, present substantive results and pause for human acceptance before dependent work unless applicable preapproval covers it.** Model/API-design artifacts share the DECOMPOSITION checkpoint; contract artifacts share SPEC, without extra DOCS/FDOCS tasks or approval rounds. The same checkpoints apply to necessary feature documents/proposals. Reuse sufficient existing inputs rather than creating optional documents to fill the sequence.

For main or feature document preparation, select or recover the [doc-design mode](#doc-design-modes) before applying the document checkpoints below. The selected mode determines which approvals remain active and where its preparation pass stops.

| Human checkpoint | Hold before |
| --- | --- |
| PROJECT / FEATURE | Dependent project/feature design or specification, unless mapped mode/preapproval covers the checkpoint |
| ARCHITECTURE | DECOMPOSITION or contract work |
| DECOMPOSITION | SPEC |
| SPEC | PLAN |
| PLAN | New layout or TASKS |
| layout | TASKS |
| TASKS | Implementation or hosted task projection |
| Requested implementation range completed | Any task beyond the requested count, milestone, phase or named checkpoint |
| Steering amendment completed | Resuming implementation |
| Assessment-only review completed | Repairs or revision execution |

**The human defines the implementation range and decides what follows it.** Commit each task’s verified result, evidence and initial completion checkbox together, then push and verify remote containment. At the end of the requested range, report the boundary results and stop. Do not add ready tasks, review tasks or another phase beyond the selected range. The human may request continuation or steering; start neither automatically. Partial main phases push and pause without merging. A complete phase or feature integrates only when its established verification and scope gates are met.

**The human may preapprove future checkpoints at any point, individually or as a scoped set.** Retain that decision through interruptions; report covered results without repeated approval pauses. Preapproval preserves QC, publication/tracking gates and the authorized implementation range. See [future-checkpoint preapproval](skills/sdd-manage/references/human-document-review.md#future-checkpoint-preapproval).

Clarification, agent QC, passing tests and commits/pushes do not constitute human acceptance. Broad development authority does not preaccept unseen documents or expand a selected implementation range. Preserve pending decisions after interruption. See [document review](skills/sdd-manage/references/human-document-review.md) and [implementation checkpoints](skills/sdd-implement/references/completion-and-checkpoints.md#parent-completion-and-stopping).

## Requested backend tracking

**For fresh/resumed main preparation, enabled tracking precedes repository modifications:** use [main preparation](skills/sdd-manage/references/main-preparation.md) for the native `sdd-docs-main` milestone and all nine issues defined in bundled JSON before writes. DOCS_TASKS holds the nine task definitions/checkoffs; DOCS_PREPARATION owns mode/pass, decisions and evidence. Publish each accepted-document/preparation-evidence/checked-task commit before issue closure; ordinary later edits retain completion, while an explicit cursor reset reopens DOCS-002–009 for a new pass. Final QC issue closure → verified/published docs merge → milestone closure → final preimplementation checkpoint. This is separate from implementation phase activation.

Feature preparation tracking uses a separate campaign milestone and nine FDOCS issues before writes, under [its preparation contract](skills/sdd-manage/references/feature-preparation.md); it does not reuse main DOCS objects or product phase labels.

### Implementation tracking

**When tracking is requested, prepare and maintain hosted objects throughout task-list-based implementation.** Use `sdd-manage` to coordinate and `sdd-forge` for GitHub issues, labels and milestones, or supported provider equivalents.

- **Before execution:** create/reconcile the eligible phase's phase label, all milestones and all task issues, including review/report tasks. On GitHub, use milestone objects and verify each issue's phase label and milestone association. Use milestone labels only where the provider lacks native milestones and its backend defines equivalent completion/reconciliation semantics. Missing or unverified objects block affected implementation. Activate later phases only when eligible.
- **During execution:** project added tasks and update changed associations before their execution. After each task is verified, committed and pushed, close its issue with evidence. Close milestones only after all constituent issues, required reviews and exit conditions are complete.
- **After amendments or interruption:** reconcile actual hosted state, reuse existing identities, finish pending operations and reopen affected issues/milestones when acceptance is invalidated.
- **At each implementation checkpoint:** report tracking status and unresolved operations. Provider failures preserve local results but do not waive required projection or dependent closure gates.

Follow [phase activation](skills/sdd-manage/references/phase-activation.md) and the [tracking lifecycle](skills/sdd-conventions/references/backend-object-lifecycle.md).

## Skill routing

This capability directory identifies owners, including skills normally activated within a workflow. It does not replace their procedures or interpret every contextual follow-up.

| Capability | Owner and entry |
| --- | --- |
| Workflow selection, coordination, branches, credentials and transitions | [sdd-manage](skills/sdd-manage/SKILL.md) |
| Read-only repository/instruction state and interruption inspection | [sdd-orient](skills/sdd-orient/SKILL.md) |
| Modularity, design review, task hierarchy and shared conventions | [sdd-conventions](skills/sdd-conventions/SKILL.md) |
| Project brief, architecture, component APIs and model design | [sdd-design](skills/sdd-design/SKILL.md) |
| Behavior, interfaces, contracts and acceptance requirements | [sdd-specify](skills/sdd-specify/SKILL.md) |
| Delivery strategy, milestones, dependencies and physical layout | [sdd-plan](skills/sdd-plan/SKILL.md) |
| Executable tasks, dependencies and task-list review | [sdd-tasks](skills/sdd-tasks/SKILL.md) |
| Bounded task-range selection, implementation and resumption | [sdd-implement](skills/sdd-implement/SKILL.md) |
| Human-directed amendment at a paused implementation checkpoint | [sdd-steer](skills/sdd-steer/SKILL.md) |
| Accepted feature incorporation and task-ownership reconciliation | [sdd-integrate-feature](skills/sdd-integrate-feature/SKILL.md) |
| Test strategy, scenarios and test changes | [sdd-tdd](skills/sdd-tdd/SKILL.md) |
| Checks, failures, acceptance coverage and boundary code review | [sdd-verify](skills/sdd-verify/SKILL.md) |
| README, guides and module/API documentation | [sdd-docs](skills/sdd-docs/SKILL.md) |
| Issues, commit/merge messages and evidence-backed reports | [sdd-report](skills/sdd-report/SKILL.md) |
| Git highlights, release messages/packages and hosted tracking/releases | [sdd-forge](skills/sdd-forge/SKILL.md) |

Name the next owner and preserve accepted inputs, actual context and the stopping boundary; use its handoff procedure. A sibling reference supplies shared guidance without selecting that skill's entire workflow. Execution handoffs depend on client facilities.

## Composite workflows

The [canonical catalog](skills/sdd-manage/references/workflows.md) owns definitions and transitions. These summaries show principal stages, owners, outputs and stops; implementation and release operations can also be selected independently within scope.

### Doc-design modes

Main and feature document preparation support the following mapped selections. Load [mode and pass control](skills/sdd-manage/references/doc-design-modes.md) before applying a selection or handling a cursor reset; it owns approval/delegation, retained-document revision, reset and recovery rules.

| Selection | Approval and pass boundary |
| --- | --- |
| **interactive/onepass** (default) | Each necessary document checkpoint remains active unless explicitly preapproved; follow the selected preparation range. |
| **autodoc/onepass** | Approve PROJECT or FEATURE; later applicable document checkpoints through TASKS/FEATURE-TASKS are preapproved. Stop at DOCS-008/FDOCS-008 before package QC. |
| **autodoc with human-controlled multipass** | Approve the mapped brief each pass; later applicable document checkpoints are preapproved. After the document pass, wait for reset or advance direction. |
| **autodoc/autoloop** | Use predefined scope passes: first mapped brief approval remains active; announce that later brief approvals are waived. Run the agreed passes, then stop after final DOCS-008/FDOCS-008 before package QC. |

Predefined autodoc scope sequences default to autoloop unless human-controlled multipass is requested. New material autoloop decisions are delegated to agent judgment with visible rationale while proceeding. A cursor reset retains documents and reopens mapped DOCS-002–009 or FDOCS-002–009 and their existing issues; mode selection preserves required QC, publication and tracking gates.

Multipass delivery is **strict by default**: later passes preserve earlier phase/task ranges. **Explicitly permitted flexible multipass** may integrate small changes fitting an earlier pass's scope into its corresponding range. This choice is independent of approval/loop control; [mode details](skills/sdd-manage/references/doc-design-modes.md#multipass-delivery-modes) govern selection, retention and planning/task review.

### Project preparation and bounded delivery

`PROJECT.md` is the concise project brief: purpose, users, outcomes, scope/non-goals and consequential constraints, with material assumptions/questions identified. Use `sdd-design`'s [brief contract](skills/sdd-design/references/project-brief.md); PROJECT supplies context rather than architecture or exact SPEC behavior.

[Main preparation](skills/sdd-manage/references/main-preparation.md) starts with DOCS-001: preserve existing root guidance/disclosure/discovery files, copy missing ones and publish initialization. Mixed initial presence requires a named retained/copied warning and a continuation pause unless explicitly preapproved; none/all present adds no pause.

Main preparation routes `sdd-manage`/`sdd-orient` → `sdd-design` (PROJECT, ARCHITECTURE, DECOMPOSITION) → `sdd-specify` (SPEC) → `sdd-plan` (PLAN, layout) → `sdd-tasks` (TASKS), with `sdd-conventions` as needed. Existing work enters at the next eligible stage; requested interactive review comes first. Apply the [human checkpoints](#human-checkpoints-and-git-publication) and [document QC](skills/sdd-manage/references/document-qc-gates.md).

Completed main preparation includes DOCS-009 whole-package QC and published documentation integration, then `sdd-docs-main` milestone closure and the final implementation checkpoint. Autodoc stops earlier at DOCS-008; advancing to package QC is separate. Otherwise completed preparation-only stops at that final checkpoint; an authorized implementation handoff requires accepted preparation to be integrated, verified and published to the actual default branch before creating the dependent branch; see [preparation integration](skills/sdd-manage/references/branch-management.md#preparation-integration-gate).

### Task implementation and continuation

`sdd-implement` selects and executes the authorized range, composing `sdd-tdd`, `sdd-docs` and `sdd-verify`, with `sdd-report` for evidence/messages. `sdd-manage` establishes the [tracking decision](skills/sdd-manage/references/tracking-decision.md) and [phase activation](skills/sdd-manage/references/phase-activation.md); `sdd-forge` maintains confirmed hosted effects.

Follow [task completion and recovery](skills/sdd-implement/references/completion-and-checkpoints.md) and the prominent [publication/range stops](#human-checkpoints-and-git-publication). Finish pending work before advancing. Requested tracking and unresolved dependent effects retain their gates; partial main phases push and pause, while complete verified phases use eligible integration.

### Feature preparation, execution and incorporation

`sdd-manage`/`sdd-orient` establish the bounded addition and accepted main inputs. Feature preparation follows the shared interactive/autodoc/multipass policy mapped through [FEATURE, task-only FEATURE_DOCS_TASKS and FEATURE_PREPARATION](skills/sdd-manage/references/feature-preparation.md). First FEATURE approval precedes dependent stages unless preapproved; assess unchanged design/layout for reuse. Autodoc stops after FDOCS-008 before FEATURE-QC-REPORT/package QC. Completed preparation passes FDOCS-009, verified/published preparation integration and selected preparation milestone closure before its implementation checkpoint. Design/specification/planning/task owners produce only necessary deltas, with human checkpoints and QC. Accepted preparation integrates before the dependent implementation branch; FEATURE-TASKS drives its authorized range through `sdd-implement`.

Use [feature phase delivery](skills/sdd-manage/references/feature-delivery.md) for the retained campaign branch, complete-phase integration and continued later scope. Incomplete phases pause; completed phases incorporate only their selected delivered delta and verify/publish the receiving target. Final campaign completion alone permits eligible final archive. Before final feature verification, `sdd-integrate-feature` incorporates accepted deltas within the selected scope. Task transfer needs both owning lists in scope; document-only incorporation does not authorize execution. A complete coherent feature verifies/integrates/publishes its established target, then stops. Follow [feature incorporation](skills/sdd-integrate-feature/SKILL.md).

### Review and accepted revision

`sdd-manage` establishes source, concerns, evidence mode and boundary; selected owners assess, with `sdd-report` retaining located findings. Systematic reviews plan units; focused reviews may use prompt-defined criteria. Publish authorized report checkpoints and stop before repairs unless execution is included.

Accepted revisions route bounded changes to owners and `sdd-verify` for rechecks. Integrate only the complete authorized verified boundary. [Review/revision](skills/sdd-manage/references/review-and-revision.md) owns the procedure; [nested/reopened modes](skills/sdd-manage/references/revision-modes.md) preserve parent/return context and opening provenance. Do not automatically resume a suspended parent.

### Checkpoint steering

At a paused implementation checkpoint, `sdd-manage` routes the human-defined amendment to [sdd-steer](skills/sdd-steer/SKILL.md). Assessment-only returns impact. Commanded execution reconciles existing documents, code, tests and documentation without feature overlays or an obligatory formal campaign; verify/commit/push and integrate/verify/publish into the paused target. Return control without resuming `sdd-implement`.

### Release preparation and publication

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before any release tag, publishing trigger, upload or publication, require an executed [artifact-name check](skills/sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) over the complete actual inventory. No type/extension may be skipped. Prior releases and explicit project naming policies/templates/examples create no exemption: correct all conflicting active definitions and use compliant names in every new release. Failures require persistent producer/code/docs repair, source publication, rebuild and recheck before continuing the authorized release.

`sdd-manage` routes [highlights-only](skills/sdd-forge/references/release-highlights.md) versus [complete messages](skills/sdd-forge/references/release-message.md) through `sdd-forge` and `sdd-report`. Complete preparation refreshes retained notes, preserving human curation and explicit template/path or supplied-text scope. Root RELEASE-NOTES.md is the default final destination; release documents may be committed within the active revision directory and moved in the release commit. Complete required Git persistence of owned ignore/tracked-note changes; stop before tagging or hosted release publication.

An authorized release verifies notes coverage/context and version; version match alone is insufficient. The tag targets a verified release commit on the actual default branch: either a direct commit or the merge from its designated primary development branch. Its body and GitHub body use the exact finalized Markdown. Follow [release Git boundaries](skills/sdd-manage/references/git-workflows.md#release-commit-and-tag) and the [GitHub release owner](skills/sdd-forge/references/github.md). `sdd-verify` checks actual release evidence; reports distinguish prepared, Git-published and hosted-complete states. Package preparation alone does not authorize a release; prerelease review requires explicit selection.

### Focused maintenance and optional hosting

Select independent work through its owner and preserve its narrow outputs. Assessment/checks/drafts do not authorize repairs, task completion, PR creation or release publication. Persist reports or owned changes only within established repository authority; required Git publication still applies.

Hosted-only requests stop after their selected effects. Local work needs no provider credential. Accept supported supplied credentials through [protected handling](skills/sdd-manage/references/credentials.md); do not echo values into generated prompts, source, reports, diagnostics or normal handoffs. Authentication recovery preserves scope and does not bypass policy.

## Branches, integration and continuity

Use the coordinator's [continuity subworkflow](skills/sdd-manage/references/continuity.md) for `docs/dev/HANDOFF.md` and recovery from later records/Git. Milestone/phase review tasks refresh it in their completion commits; revision finalization and parent return refresh their boundaries. Ordinary task commits need no handoff update. At reconstructed startup, inspect unfinished branches against their recorded parents and request the continuation branch unless already selected.

Establish actual working/source/target identities, creation parent and branch-off checkpoint; completed new workflows integrate into that parent and restore its context without automatic task resumption. Preparation uses `design-docs`, main execution uses phase branches, and feature/revision identities follow [branch management](skills/sdd-manage/references/branch-management.md). Prefixes do not establish acceptance or authorize a merge.

For invalid implementation task completions, the manager resolves [forward recovery](skills/sdd-implement/references/completion-and-checkpoints.md#resolve-a-task-recovery) under existing authority; a repaired verification failure alone does not require renewed approval of the original range. Historical composition exceptions remain human decisions. For TASKS/FEATURE-TASKS, follow the [task commit contract and audit](skills/sdd-implement/references/completion-and-checkpoints.md#task-commit-contract): one executable task closes per commit with result/evidence and initial checkbox; exactly one owning task ID leads its subject. DOCS/FDOCS preparation persistence belongs to the coordinator's mapped [main](skills/sdd-manage/references/main-preparation.md) or [feature preparation](skills/sdd-manage/references/feature-preparation.md), not the product implementation audit. Non-task work invents no task ID. Preserve pending/unrelated work; a dirty tree does not authorize reset.

Eligible integration uses an explicit two-parent merge, merged verification and target publication. Partial ranges do not imply complete integration. On conflict, denied publication or uncertain effects, preserve work and reconcile state through [Git recovery](skills/sdd-manage/references/git-workflows.md); never reset or force-push unrelated work. Hosted state follows verified local evidence and the [backend lifecycle](skills/sdd-conventions/references/backend-object-lifecycle.md).

## Campaign records and shared conventions

Use the [campaign convention](skills/sdd-conventions/references/review-campaigns.md) for records and `sdd-report` for evidence/integration summaries. Preserve original opening provenance, accepted scope and return boundaries. Campaign records stay on their revision branch; no preliminary default/design-docs merge is required.

Current owners and active records guide routine work. Closed packages are frozen history: do not load without a specific need, edit or assess later compatibility. Eligible reopening uses the selected coordinator mode.

Apply [Markdown conventions](skills/sdd-conventions/references/markdown-style.md): heading/list/block separation, four-space indentation and one space after list markers. Preserve literals and closed records. Git provides checkpoints; no transaction journal is required.
---
name: sdd-orient
description: Use when locating and inspecting a software project's repository before SDD work, checking execution OS/shell readiness, Git worktree and interrupted-task state, discovering governing instructions and development documents, or handing a scoped project orientation to an orchestrating agent. Read-only; report whether a proposed mutation has the required Git and authority baseline.
---

# Orient in a project

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Establish a factual, scoped starting point before another SDD skill changes repository files. This skill is a shared, **read-only** capability. It neither authorizes a mutation nor decides which later workflow to run. Read [inspection and handoff](references/inspection-and-handoff.md) for the evidence checks and report contract.

1. Establish the user's intended project path and proposed scope, if supplied. Distinguish the project root from its enclosing Git root; do not assume the current directory is the project. Identify the actual execution host/tools under [execution readiness](references/inspection-and-handoff.md#execution-os-and-tool-readiness). Follow applicable user/repository instructions and return observed readiness failures to sdd-manage without repairing the environment.
2. Read root/applicable nested AGENTS.md; assess concise orientation, command/link currency and execution-owner discoverability under **sdd-manage**'s [agent orientation](../sdd-manage/references/agent-orientation.md). Report missing/stale guidance without creating or editing it. Inspect root `SDD-MANAGER.md`, `AI_DISCLOSURE.md` and README links as adoption/disclosure evidence and report missing or conflicting records in the handoff; do not create them during orientation. Identify applicable repository instructions, including root and path-scoped `AGENTS.md`, referenced policies, and project-designated sources. Inspect `docs/dev/PROJECT.md` for the project brief; if it contains operating instructions, preserve their applicability and report their scope and any conflict.
3. Inspect Git, current branch or detached/unborn state, HEAD, worktree status, and changes affecting the intended paths. Suppress optional Git writes with command-scoped `git --no-optional-locks` or an equivalent scoped `GIT_OPTIONAL_LOCKS=0`. Git commands must not change the index, branch, working tree, or configuration.
4. Inspect the HANDOFF checkpoint, relevant later decision/task evidence and available workflow refs under [inspection and handoff](references/inspection-and-handoff.md#continuity-checkpoint). Report candidate parents, containment and remote-state uncertainty to the coordinator without selecting/fetching/switching branches. Inspect adjacent SPEC/PLAN/TASKS (and selected feature) review reports, finding/gate state and reviewed/governing identities; report absent or apparently stale readiness without performing QC or writing reports. Discover present development documents and their focused children, the active feature or change context, relevant code and tests, and declared project commands. When a task list exists, identify the last committed task and compare it with the owning checklist, pending changes, and existing verification evidence. Distinguish completed work awaiting commit from incomplete work; pass the identified state to **sdd-implement** for continuation.
5. Produce the scoped orientation report. Separate observed facts from inferences and unknowns, identify concrete blockers, and state whether the Git prerequisite for a contemplated mutation is met. Re-orient when the project path, target scope, HEAD, instructions, or material worktree state changes.

Use current governing documents and the active campaign for routine orientation. Do not load prior campaign documents unless the current task specifically needs their historical context; then read only the relevant records/sections. Identity/path discovery does not require reading historical contents. Apply the [closed-record boundary](../sdd-conventions/references/review-campaigns.md#closed-campaign-records).

If the target is outside a usable Git worktree, mark **repository mutation blocked**. Do not initialize Git, create files, clean worktrees, restore files, run tests with side effects, commit, or invoke a mutating workflow. A conversational or read-only inspection may continue.

For a subagent, the orchestrator supplies the applicable path scope, instructions, relevant document authorities, Git baseline, known dirty paths, and prohibited mutations. A subagent can inspect additional evidence within its scope; the orchestrator rechecks the overall state before coordinating any mutation or commit.

For feature preparation, observe FEATURE, task-only FEATURE_DOCS_TASKS, FEATURE_PREPARATION mode/pass/acceptance evidence and FEATURE-QC-REPORT readiness and next boundary under [feature preparation](../sdd-manage/references/feature-preparation.md), without authoring. For main/feature preparation, observe actual document progress and pending human instructions under [human document review](../sdd-manage/references/human-document-review.md). For main preparation, inspect DOCS_TASKS for task definitions/checkoffs and DOCS_PREPARATION for mode/pass, initialization/approval evidence and pending effects, together with actual document, QC, Git and hosted state under [main preparation](../sdd-manage/references/main-preparation.md); orientation remains read-only. Pass the next unfinished stage and any selected review to the coordinator; absent retrospective acceptance evidence alone does not require interactive replay. Keep readiness observation separate from authoring and substantive owner QC.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/workflows.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/continuity.md
```

```text
# Available workflows

Select by the user's objective, not by which documents happen to be missing. A scoped request may enter any stage whose required inputs are established. A combined request may authorize preparation and implementation together; retain its explicit implementation boundary. Do not require fresh approval for a transition already covered by that request.

## Workflow selection and continuity

Apply at a development/functionality/review/revision request when no sufficient workflow context exists, and when a later request may change the active objective, scope or stopping boundary. The human need not name a skill or core workflow.

1. **Recover context.** At initial/reconstructed composite entry, apply [continuity](continuity.md) for branch discovery/selection and recovery from HANDOFF plus later records/Git; reuse an explicit or established branch choice. Use the request and established decisions; obtain `sdd-orient` evidence only where current project state is missing or stale. Distinguish a new project from existing or interrupted work, and recover the active workflow, stage, accepted inputs, pending human decisions, task range and unfinished owned work. Greenfield/brownfield is starting context, not a compulsory workflow choice.
2. **Select the path.** Apply the core definitions below. Whole-project definition/delivery uses main development; a bounded capability addition uses feature; review/correction/improvement uses revision. For main or feature document preparation, select or recover [doc-design mode/pass control](doc-design-modes.md) before routing document work; retain that selection when determining approvals and stops. A human-directed amendment at a paused implementation checkpoint uses revision's steering variant. Preserve a narrow standalone operation or direct owner request when a full workflow is unnecessary. Treat explicit user selection as controlling within supported scope; ask only for a consequential ambiguity that prevents a sound selection.
3. **Assess continuity.** Determine whether the request continues the workflow, changes its stage/range, or switches workflows. A correction during preparation can remain with its current owner; a bounded addition does not require restarting main development. Do not switch from filenames, branch prefixes or missing documents alone. Before a switch, preserve pending work, authority and human checkpoints; apply the relevant branch/revision-mode procedure, including parent suspension/return where applicable. A switch cannot accept pending documents, widen scope or resume paused implementation.
4. **Load, report and route.** Load the selected workflow or operation instructions and relevant dependencies before stating its definitive procedure/checkpoints or beginning dependent work. Preserve a provisional selection as such while resolving instruction availability. Before dependent authoring/execution, give a concise user-visible chat brief: workflow/variant (or standalone operation), continuation/stage-change/switch decision and its request/project evidence, current stage and owner, authorized outputs and next human checkpoint/stop. Cite relevant paths or observed state; distinguish facts from uncertainty. At composite-workflow entry, material switching or context reconstruction, apply [bootstrap reporting](coordination.md#composite-workflow-bootstrap-reporting): announce Explicit, briefly explain profiles and state the subsequent level before dependent work. Visible progress commentary may carry the brief; hidden reasoning does not. Use only the selected owners and needed references, then act within the established boundary without another routine approval question.

Reuse an applicable selection and sufficient evidence on routine continuation; repeat the brief when the routing decision or authorized boundary materially changes. Use [scope checks and reporting detail](coordination.md#scope-checks-and-reporting-detail) for operational checks and adaptable event-based reporting; no per-response preamble, new journal or mandatory selection file is required.

## Core development workflows

Choose among three core workflows by the intended change. They describe purpose and overall path; focused skills and the operation catalog below supply reusable stages. A workflow name grants no authorization or branch destination. Apply **sdd-conventions**' **Workflow identity** and [branch management](branch-management.md) for actual names and target context.

| Workflow | Purpose | Typical path |
| --- | --- | --- |
| Main development | Define and deliver the complete intended project, reusing sufficient accepted inputs when available. | Exploration → PROJECT → ARCHITECTURE → DECOMPOSITION → SPEC → PLAN/layout → TASKS → bounded implementation and verification. |
| Revision | Correct, simplify, or improve previously defined or implemented work. | Review plan when needed → review → review report → revision plan → revision → revision report. |
| Feature | Add a scoped capability to an existing system. | FEATURE + FEATURE_PREPARATION → necessary feature design/specification/plan documents → FEATURE-TASKS → implementation → accepted document incorporation and verification. |

- **Entry:** Main development covers both new and existing projects: greenfield starts with sdd-design's [guided exploration](../../sdd-design/references/exploration.md) before PROJECT, proactively assessing the seed and consequential choices; an existing project may enter at an established stage. Reuse accepted inputs rather than replaying stages.
- **Scope selection:** Main development addresses whole-project definition and delivery. Feature is the usual route for a bounded addition to an existing project; an existing project needing whole-system specification/planning can use main development. Revision addresses corrections to defined or implemented work. Greenfield/brownfield describes starting context, not a separate workflow or compulsory routing rule.
- **Revision scope:** Use [review and revision](review-and-revision.md) for formal campaigns. Use [revision modes](revision-modes.md) for a nested revision’s suspended parent/default return target or a human-authorized eligible reopened campaign amendment. A focused prompt may define review scope or an accepted revision directly; do not invent a preceding review or mandatory artifact stage when it adds no needed evidence.
- **Feature preparation:** Establish the [feature brief and preparation record](feature-preparation.md), with sdd-design owning FEATURE and its first acceptance checkpoint before dependent deltas. Use sdd-design's [exploration](../../sdd-design/references/exploration.md) for consequential uncertainty in the feature delta, reusing accepted project decisions. Return later design questions to that same bounded procedure without replaying initial discovery. Define the scoped feature package on a dedicated design-docs branch before dependent implementation, using only the design, specification, and planning deltas it needs. Explicitly merge accepted project preparation into the default branch before creating the feature implementation branch. FEATURE-TASKS governs active task-list feature work. Reuse sufficient existing design/layout; not every correction needs a feature package.
- **Shared execution:** Implement only the authorized bounded scope. Apply relevant verification and commit/push checkpoints under [Git workflows](git-workflows.md). Main development uses phase branches: partial ranges pause after pushes, complete phases explicitly integrate, and an authorized next phase starts from updated main. Revision/feature and steering use their applicable integration gates. Preparation, assessment, and review stop before implementation unless it is authorized. A narrow task request does not authorize unrelated incorporation or a whole-project campaign.

### Steering as lightweight revision

**sdd-steer** is the focused human-directed revision path at a paused task-list checkpoint, especially for reducing implemented functionality. The human supplies the amendment objective and commands execution. Steering directly updates affected existing documents, code, tests, and documentation; it creates no feature-document layer and requires no feature-document integration step or obligatory formal review/revision campaign.

Steering still verifies, commits/pushes, explicitly integrates into the paused implementation branch, verifies/publishes that target, and reports. It returns control without handing off to or resuming sdd-implement; the human separately resumes the task list. A broader revision may use the formal campaign instead. Steering is a revision variant, not a fourth core workflow.

## Operation catalog

These entries select stages or supporting operations within a core workflow; they can also be requested independently within their stated boundaries.

| Operation | Entry and coordination | Outputs and stop |
| --- | --- | --- |
| Read and explain a workflow before project work | Use the [workflow-loading procedure](#workflow-loading) for the requested main, feature, revision or supporting operation; load only relevant instructions and dependencies. | Chat-only sources actually read, stages/checkpoints, authorized scope and next step. No project preparation or mutation by implication. |
| Prepare initial development | Load [main preparation](main-preparation.md) before any fresh/resumed repository writes: enabled `sdd-docs-main` and all nine issues first, then task-only DOCS_TASKS, the DOCS_PREPARATION control/evidence record and initialization. Apply [doc-design mode/pass control](doc-design-modes.md) to the seven document approvals, cursor reset and DOCS-008 stop before eligible package QC, published integration and milestone closure. Enforce [document QC gates](document-qc-gates.md) between dependent stages, including scoped corrections/rechecks and adjacent reports. Use **sdd-design** and its [project brief contract](../../sdd-design/references/project-brief.md) for PROJECT (concise purpose/users/outcomes/scope/constraints), then ARCHITECTURE and DECOMPOSITION; **sdd-specify** for behavior and acceptance; **sdd-plan** for delivery strategy and layout; **sdd-tasks** for TASKS. Resolve consequential decisions as they arise. | Selected artifacts and open decisions. Completed main preparation includes verified/published documentation integration, then milestone closure and the final preimplementation checkpoint; preparation-only stops before implementation. Explicit earlier stops remain controlling. |
| Prepare a feature | Establish the [required brief/record pair](feature-preparation.md) and obtain applicable FEATURE acceptance before dependent deltas. Enforce [document QC gates](document-qc-gates.md) for the selected feature delta against accepted main inputs. Inspect existing contracts and implementation. Use design deltas where needed, then **sdd-specify**, **sdd-plan**, and **sdd-tasks** for the necessary FEATURE-SPEC, FEATURE-PLAN, and FEATURE-TASKS. Reuse established design and layout where sufficient. | Bounded feature requirements, delivery strategy, and executable tasks. Stop at preparation unless implementation is included in the request. |
| Implement a bounded range | Apply [tracking decision](tracking-decision.md) and [phase activation](phase-activation.md) before executable handoff; requested/confirmed tracking needs verified eligible-phase projection, otherwise report blocked execution. Pass the owning TASKS or FEATURE-TASKS, requested IDs/count/milestone/phase, dependencies, and boundary to **sdd-implement**. It resolves the executable range and coordinates **sdd-tdd**, **sdd-docs**, **sdd-verify**, **sdd-report**, and active **sdd-forge** tracking. | Evidence-backed completed tasks, commits, pushes, and applicable issue closure. For main development, pause on an incomplete phase branch or explicitly integrate the verified full phase. For other workflows, integrate only the coherent authorized boundary. Verify/push applicable targets, then stop; retain branch state on a blocker. |
| Resume interrupted implementation | Pass orientation's identified pending task and evidence to **sdd-implement**. It inspects publication eligibility, then pushes eligible outstanding commits before ordinary task work, even on a clean tree; known-invalid completion enters its bounded recovery exception. It finishes pending work before advancing. Use the established boundary; clarify it if unavailable. | Continuation of the bounded implementation workflow. No separate recovery protocol or automatic reset. |
| Steer at a checkpoint | Use **sdd-steer** for the human-defined focused amendment during partial implementation. An assessment request returns impact only; a command to implement authorizes direct changes to affected existing development documents, code, tests, and documentation. | Assessment, or a verified amendment branch explicitly merged into the paused implementation branch, merged-state verified and target pushed. Create no feature overlay and invoke no feature-document integration step. Stop; the human separately resumes implementation. |
| Integrate accepted feature documents | Pass the accepted sources and explicit target set to **sdd-integrate-feature**. TASKS and FEATURE-TASKS are independently selectable; transferring task ownership requires both lists in scope. Document-only integration does not imply task reconciliation. | Selected main documents incorporated, task relationships reconciled only within scope, source disposition, and external impacts. Stop without executing tasks. |
| Run a review/revision campaign | Use [review and revision](review-and-revision.md) for planned systematic review or prompt-driven focused review, stable findings, accepted revision planning, and authorized execution. Route concerns to focused owners. | Retained campaign plans/reports. Review stops before source changes unless revisions are authorized; implemented revisions finish with verified explicit merge/publication. |
| Run comprehensive prerelease review | When explicitly selected, load the [prerelease profile](prerelease-review.md) and use the existing review campaign lifecycle and focused owners against the pinned complete current product. | Published candidate-specific coverage, findings, readiness and revision proposals; stop before repairs or release unless independently authorized. This review is optional. |
| Review or maintain a selected scope | Route design review to **sdd-design**, behavior review to **sdd-specify**, strategy/layout review to **sdd-plan**, task-list review to **sdd-tasks**, selection-only requests to **sdd-implement**, test strategy or test maintenance to **sdd-tdd**, documentation to **sdd-docs**, and acceptance checks plus read-only milestone/phase implementation code review to **sdd-verify**. Use **sdd-conventions** for relevant criteria. | Findings, evidence, or explicitly requested maintenance. Review and verification do not authorize repairs or completion updates. Stop at the selected scope. |
| Prepare a handoff for another agent | Apply [continuity transfer preparation](continuity.md#explicit-transfer-preparation): reconstruct the checkpoint plus later records/Git, optionally refresh it and verify branch publication and necessary input availability. | Accurate transfer checkpoint/evidence and explicit limits; no fabricated milestone completion, automatic range expansion or additional implementation. Ordinary continuation requires no explicit handoff command. |
| Synchronize hosted tracking | Use **sdd-forge** for the requested projection, association lookup, or issue reconciliation. Use available client authentication first and coordinate credential recovery through the credential protocol when needed; leave provider access checks and object mapping to its backend. | Repository and task-to-issue associations, eligible-phase object creation, verified issue/milestone closures, differences, and access blockers. Stop after the hosted operation. |

## Workflow loading

Use this operation when the human asks to read, load or explain SDD Manager workflows before development. It is distinct from preparing project documents. Greenfield selects the new-project starting context of main development, not a separate core workflow.

1. Identify the requested workflow or operation and the purpose of this loading turn. Use supplied context; recover target-project evidence only when the request needs it. A generic workflow explanation requires no target repository or Git worktree.
2. Read the coordinator entry and selected workflow/operation instructions, including dependencies governing relevant transitions and human checkpoints. Load selectively; do not read unrelated workflows or every reference. If a required source is unavailable, identify that limit rather than claim it was loaded or the procedure is established.
3. Report in chat the repository paths of sources actually read, applicable stage sequence and human checkpoints, authorized work/outputs and exclusions, and the next step. Distinguish the documented path from actual project readiness or approvals. Honor an explicit request for sources even when routine reporting detail is reduced.
4. Stop at the requested loading boundary. Do not create project files, bootstrap records, branches, hosted objects or commits merely to prepare the workflow. Loading instructions neither accepts artifacts nor authorizes subsequent development.

## Release operations

For requested release publication, apply the [advisory prerelease review reminder](prerelease-review.md#advisory-release-reminder) at entry and carry its disposition through the release handoff. The shared policy defines when to remind and how to continue; selecting release work does not select review.

| Request | Route and boundary |
| --- | --- |
| Prepare/draft/assemble/update a release message or release notes | Coordinate [complete message preparation](../../sdd-forge/references/release-message.md): forge supplies validated Git highlights, report assembles applicable ancillary sections, and manage establishes output ownership. Retain body-only notes, refreshing them atomically. Root `RELEASE-NOTES.md` is the default final path; active revision campaigns may commit release documents within their directory for placement during the release commit. No provider, tracking, release/tag writes or dispatch is required. Explicit supplied-text-only editing keeps its narrower scope. |
| Collect/revise highlights since a release | Use sdd-forge’s [shared Git highlights](../../sdd-forge/references/release-highlights.md) before provider selection and sdd-report for curation. Coordinate draft/ignore ownership and exact source coverage. Return the ignored local draft or finalized body; no hosting access, TASKS, release/tag creation or publication is required. |
| Assess a package or develop release packaging/workflow | Use sdd-forge's [package preparation](../../sdd-forge/references/github-packaging.md) and [release workflow](../../sdd-forge/references/github-release-workflows.md) guidance. Coordinate accepted repository edits, meaningful checks, commits/pushes and eligible integration through existing Git ownership. Retain interactive decisions; stop before product release publication unless requested. |
| Create/finish a release or run its established workflow | Pass repository, exact verified source/tag, package set, notes, state/latest policy and authorized effects to sdd-forge's [release lifecycle](../../sdd-forge/references/github-releases.md). Verify/refresh retained complete notes using local provenance and version agreement; coordinate the default-branch release commit (direct or a merge from the designated primary development branch), whose body is the complete message, verify its published first-parent provenance and tag that exact SHA. Create/update shared highlights through the exact source before the new tag becomes a baseline, establish finalized-notes transfer, select one publisher, coordinate any necessary tag/Git work, verify actual outputs and remote state, verify the published complete body before cleaning up only the owned internal highlights checkpoint; retain the complete-message file, then return release URLs/evidence or pending effects. |

Before release tags/triggers/uploads/publication, coordinate forge and verify through the mandatory [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair). A failing name requires authorized repairs to producers and related code/tests/docs, published source, refreshed release provenance, exact rebuild/checksums and revalidation; do not bless the bad expected set or stop at a routine repair report. Continue the authorized release through actual publication/readback, preserving narrow stops, human constraints and existing-tag/immutable recovery.

Release requests do not require TASKS, GitHub tracking activation or automatic phase-end release creation. Existing source/build documentation supplies sufficient contracts for a scoped package request; consequential unresolved choices return to the user, while routine authorized steps proceed. Use sdd-verify's [release checks](../../sdd-verify/references/release-checks.md) and sdd-report's [release reporting](../../sdd-report/references/releases.md). Permission recovery distinguishes workflow-file modification, release writes and workflow dispatch.

## Delivery strategy handoff

Commit preimplementation project artifacts and adjacent QC reports on the designated design-docs branch. Completed main preparation follows [its completion sequence](main-preparation.md#final-package-qc-integration-and-checkpoint); completed feature preparation follows [its mapped sequence](feature-preparation.md#final-package-qc-integration-and-checkpoint). Both include verified/published documentation integration, closure of their selected preparation milestone and the final preimplementation checkpoint. Autodoc’s [pass boundary](doc-design-modes.md#complete-a-pass) stops after DOCS-008 or starts the next predefined reset; it does not select package QC/integration. Other preparation-only paths stop on design-docs; feature autodoc stops at FDOCS-008 before feature package QC/integration, just as main autodoc stops at DOCS-008. Honor explicit earlier, no-merge and local-only limits. Before an authorized implementation handoff, complete [preparation integration](branch-management.md#preparation-integration-gate), then branch from the recorded integration parent containing that published checkpoint; the implementation range still needs authorization. Campaign review/revision records remain on their revision branch and do not require this project-document stage.

Preparation uses **sdd-plan**'s [delivery procedure](../../sdd-plan/references/delivery-plan.md) to bound every phase as a coherent functionality increment; greenfield Phase 1 establishes the simplest sensible usable product. Version scope may span phases and does not select a single phase. Retain complete design/SPEC, justified prerequisites, prior working behavior and scoped exits before **sdd-tasks** derives executable work. A feature or existing system begins with its bounded changed outcome; no new MVP is imposed.

Pass the selected range, owning capability/milestone outcomes, dependencies, verification obligations, and applicable human decision gates into implementation. At consequential checkpoints, return the demonstrated functionality and relevant usability/risk evidence for the human's continue/amend/simplify/stop decision. This does not authorize automatic steering, broaden the selected range, or require approval for routine work already authorized.

## Feature sequencing

At feature initialization, execute/reuse [manual AI provenance setup](ai-logs.md#default-execution-and-overrides) by default, without an opt-in question. Honor explicit opt-out/deferral and use its existing-initialization procedure for missing setup; report/recover enabled blockers. Do not replay completed DOCS-001 or automatically merge manual log changes.

- **Preparation:** Load [feature preparation](feature-preparation.md) for the required FEATURE/FEATURE_PREPARATION pair, decision/acceptance ownership and continuation rules. Establish the convention's campaign/package identity and `design-docs/<campaign>-<slug>` under [branch management](branch-management.md). Record its identity, branch/target and active source links in FEATURE_PREPARATION; preserve another active package in the same worktree. Establish the entry HANDOFF with scope, parent and active package links under [continuity](continuity.md); intermediate approvals stay in FEATURE_PREPARATION, with refresh at completed preparation/integration. Keep feature deltas distinguishable from complete main documents. Creating a feature task list does not require immediate incorporation into TASKS.
- **Implementation:** Apply [feature phase/campaign delivery](feature-delivery.md) for phase segmentation, receiving targets, scoped incorporation and retained future work. Explicitly merge, verify and publish the accepted feature preparation into the default branch before creating `feature/<campaign>-<slug>` from its recorded integration parent containing that checkpoint. If that parent is an active phase, apply the preparation gate's verified propagation step first; final integration returns to the creation parent. Accepted FEATURE-TASKS can then drive implementation while its authoritative feature documents remain active. Identify those sources explicitly in the handoff.
- **Document integration:** Incorporate accepted targets included in the request on the feature branch before final verification and Git merge. A complete feature implementation includes incorporation needed for a coherent final project; a preparation-only or narrow task request does not authorize unrelated incorporation. Do not infer acceptance from passing tests.
- **Archive:** After accepted final incorporation and task/evidence disposition, **sdd-integrate-feature** retains eligible sources under the package directory, repairs selected links, and marks historical snapshots. Partial/narrow integration retains needed active documents; verify archive ownership before final merge.
- **Git integration:** Feature phases use [phase-matched incorporation and integration](feature-delivery.md); incomplete phases push/pause, completed phases integrate and preserve later work, and final campaign completion alone permits eligible final archive. Merge the verified completed boundary into its recorded target explicitly, verify and publish. Completed feature preparation includes its package QC and verified published preparation integration, then stops before implementation unless authorized; autodoc first stops at FDOCS-008 pending explicit advance. The earlier preparation merge is a separate document-only boundary.
- **Consistency:** If the selected work requires an unresolved contract or dependency decision, report it before the dependent mutation. Continue independent authorized work when sound.

## Cross-cutting operations

- **Reporting:** Use **sdd-report** throughout, or independently for an issue, commit message, PR description, or progress report. Drafting PR text does not create or merge a PR.
- **Hosted tracking:** Local workflows remain usable when tracking is not selected; selection makes its gates required for dependent execution. Hosting outages permit independent execution only in an already verified activated phase for projected tasks with satisfied dependencies; preserve verified local results and report pending closure without waiving initial/added-work or transition gates. Apply the shared backend lifecycle: activate/project only an eligible phase before its first task; coordinate committed milestone/phase review tasks and reports, task issue closure and then milestone closure; gate next-phase activation on verified predecessor integration/publication. Use phase activation for the transition. When tracking is active, coordinate task associations before commit composition and verified closure through **sdd-forge**; issue state never supplies completion evidence.
- **Authentication:** Use the [supervised HTTPS publication entry](git-workflows.md#monitor-pending-git-operations) from the first authorized push, with deterministic supplied-token/existing-auth selection. Route access/credential failures to the coordinator's repository-token recovery protocol; preserve distinct Git and API access and the active backend's permission profile.
- **Continuity:** All composite workflows and focused calls affecting them use [checkpoint/recovery](continuity.md). Supporting and release operations return material state/decision changes to the active owner; do not invent task campaigns or change release-message, commit/tag or provider rules to maintain a handoff.
- **Persistence:** Implementation and steering own their commits and pushes. Coordinate persistence of other authorized repository edits through the shared protocol; hosted-only changes have no local commit by implication.

## Optional tracking decision at handoff

Use **sdd-manage**'s [tracking decision](tracking-decision.md) before dependent phase activation. Carry the recommendation, actual confirmation/decline, repository/scope and observed hosted state separately. A supplied GitHub token recommends enabled tracking but does not activate it; unresolved activation choices return to the manager. Reuse confirmed scope without repeated approval. Late confirmation reconciles retained evidence instead of replaying product tasks.

## Human preparation sequence

Use [human document review](human-document-review.md) for both initial and feature preparation. Apply selected [doc-design mode/pass control](doc-design-modes.md) for main/feature preparation and explicit scoped preapproval before determining active checkpoints. FEATURE has its own boundary before dependent feature design/specification. PROJECT, ARCHITECTURE, DECOMPOSITION, SPEC, PLAN, layout and TASKS each have their own boundary; guide the human through necessary new proposals and hold dependent progression only where human acceptance remains required. Feature campaigns review their necessary deltas and reuse sufficient existing main inputs without inventing optional overlays.

At startup or after interruption, assess existing progress and continue from the next eligible stage by default. An explicitly requested interactive review comes first; important issues can prompt a concern and offer. Preserve the selected mode, its stopping boundary and actual pending human decisions. Agent QC and broad continuation authority do not replace required creation checkpoints.
# Preserve and recover workflow context

Use this subworkflow at composite-workflow entry or reconstruction, scheduled handoff checkpoints, nested/steering return and explicit handoff preparation. Focused calls affecting an active workflow use the same continuity contract. Read-only discovery/review does not authorize adoption, checkout or execution.

## Checkpoint and owners

Maintain tracked target-project `docs/dev/HANDOFF.md` from the bundled [template](../../../assets/HANDOFF_TEMPLATE.md). It describes a named checkpoint; later task commits need not change it. The coordinator owns continuity, the active owner supplies its facts and persistence, and **sdd-orient** observes/reconstructs without writes. AGENTS links the record and this coordinator route. The main/default branch retains its integrated checkpoint; workflow branches inherit and update their own copies until integration.

Keep a brief outcome summary and four groups:

1. Workflow/variant, stage/owner and links to governing documents, task list and evidence.
2. Authorized objective/range, exclusions, exact stop, pending approvals and scoped preapprovals/overrides with decision sources.
3. Working branch, recorded creation parent, full branch-off commit, integration target, suspended parent stage and return boundary.
4. Pending work/effects, blockers and next eligible action **as of the checkpoint**. Include necessary package/version/setup/input availability and transfer limits when relevant.

TASKS, current campaign/phase reports and accepted documents own their details. Feature preparation retains its current decisions, exact acceptance/QC references and pending stage in [FEATURE_PREPARATION](feature-preparation.md), with checkoffs in FEATURE_DOCS_TASKS, package readiness in FEATURE-QC-REPORT and product scope in FEATURE; HANDOFF links these owners rather than duplicating their records. In main preparation, DOCS_TASKS owns task definitions/checkoffs and DOCS_PREPARATION owns control, scope sequence, decisions and evidence; HANDOFF links both rather than duplicating their detail. Preserve later grants, revocations, stops and tracking decisions in those existing records when received, before dependent work; ordinary commits retain their normal result/evidence. Link their locations from the handoff. Retain the selected reporting preference here when needed. Summarize older phase/campaign outcomes with links instead of repeating tasks, logs or a conversation. Require no additional journal, issue registry, incremental handoff files or saved patch series.

## Establish and refresh

At authorized workflow entry/adoption, reconcile existing context and create/update the checkpoint with the actual scope, sources and parent. Preserve controlling/manual content and unrelated work. Apply [main preparation](main-preparation.md) before its first repository write; its initial handoff is generated workflow metadata, outside DOCS-001's four-file presence test. Do not merge unfinished preparation merely to expose the handoff on default.

| Boundary | Required persistence |
| --- | --- |
| Each main/feature milestone's assigned final boundary task: standalone review when required, otherwise final implementation task | Refresh HANDOFF with the verified outcome, evidence, remaining scope, pending effects and next stop in the same commit as that task's report/result and initial checked completion. |
| Phase review/report task | Refresh with overall exits and integration readiness in its completion commit. One task closing both a review milestone and the phase produces one combined update. |
| Revision finalization | Refresh its outcome and return boundary with existing campaign finalization evidence; intermediate action detail stays in campaign records. |
| Completed main/feature preparation or other composite operation | Refresh the preparation/operation checkpoint with its actual pending human/hosted boundary. Intermediate document approvals stay in their owning evidence. |
| Nested entry, steering return or eligible integration | Preserve parent suspension or restore parent context under the return procedure below. |
| Doc-design cursor reset or autodoc DOCS-008 stop | Refresh with concise mode/pass/next-boundary context and a DOCS_PREPARATION evidence link, retaining outstanding hosted effects under [pass control](doc-design-modes.md); include the snapshot in the reset or DOCS-008 completion commit. |

Refresh at these boundaries automatically, without waiting for a handoff request. Include it in the owning commit; do not add handoff tasks or routine maintenance commits. Failed/blocked review retains its findings and incomplete boundary; it cannot produce a successful-completion snapshot. A completed milestone inside an incomplete main phase pushes/pauses without merging.

No per-commit handoff edit or handoff audit is required between checkpoints. Refresh earlier only when existing records cannot adequately preserve a consequential change or a transfer is explicitly requested. Keep every owned commit's [publication](git-workflows.md#publish-each-commit) and task/document atomicity unchanged.

Identify the checkpoint by workflow/milestone and the commit containing its explicit snapshot. Inspect path history, for example `git log -1 --format=%H -- docs/dev/HANDOFF.md`, and verify the selected content/ancestry; a timestamp alone is insufficient. A snapshot must not contain its own future SHA. Completion reports may name known baseline/end commits for on-demand diffs. A checkpoint cannot prove its own later push, issue closure or merge: record required subsequent effects as requiring confirmation and reconcile them by readback.

## Select the continuation branch

At initial/reconstructed startup, inspect local and remote workflow refs and relevant active navigation. Include revision/feature and unfinished preparation/phase branches. Establish remote freshness through permitted coordinator Git operations; orientation inspects available refs without fetching or switching. An unavailable remote means unknown state, not no unfinished work. Inspect only the identities/current sections needed; closed campaigns are not a reading queue.

Reserved `design-docs/ai-logs` is a [manual provenance branch](ai-logs.md), not a continuation candidate merely because manual records are unmerged. Do not read transcripts or ask to resume it during unrelated startup. A known interrupted adopted initialization still requires reconciliation of its actual seed/merge/publication; explicit provenance requests may select that scope.

For each candidate, recover its recorded creation parent, branch-off checkpoint and actual unfinished boundary. Test source-tip containment against that parent and its established remote destination, not main alone. A retained child already merged into its unfinished parent is integrated; a target merge awaiting push is pending publication, not a reason to repeat the merge. Unmerged history alone does not prove execution remains authorized.

If the continuation branch is not already explicitly selected or established in sufficient current context, present candidate branches with their parent and pending stage and **ask which branch to continue**, even for one candidate. Do not select by recency or prefix. Preserve an explicit selected branch and avoid repeating the question on ordinary continuation. With no unfinished candidate, use the main/default checkpoint and actual request without resurrecting completed work. Missing/ambiguous parent or authority requires the consequential decision before affected mutation.

After selection, follow [branch management](branch-management.md) for safe checkout/worktree handling. Do not stash, reset, discard incomplete milestones or switch over unrelated work implicitly.

## Reconstruct after the checkpoint

1. Read applicable AGENTS instructions, selected HANDOFF and relevant current owners. Establish actual branch/HEAD, worktree/index ownership and package availability. If the record is absent, reconstruct derivable facts from existing documents/Git and establish it only within authorized write scope; do not invent past grants.
2. Locate and verify its checkpoint. Inspect relevant commits/diffs since it, current TASKS or campaign evidence, and main DOCS_TASKS plus DOCS_PREPARATION and later decisions as applicable. Include non-task and merge changes; an older handoff followed by valid task commits is expected, not a failure.
3. Recover the current objective/range, stop, approvals/revocations, tracking choice, accepted inputs, unfinished operation and parent return. Current controlling instructions and actual later human decisions supersede the older snapshot. Branch names, ready tasks and checkboxes do not supply missing authorization.
4. Inspect uncertain Git/hosted effects by exact identity before retrying. Preserve an eligible retained commit, in-progress merge, issue operation and their evidence; use the owning recovery procedure. Do not replay completed work or infer external success from saved text.
5. Hand reconstructed facts to the selected owner and resume the earliest eligible operation within actual authority. Report a concrete missing decision/facility if evidence is contradictory, unresolvable or outside scope. A current clean snapshot is not a prerequisite for safe recovery.

## Integrate and return

For workflow completion, new branches record their creation parent and branch-off commit at setup and integrate their completed eligible scope into that same parent under [Git workflows](git-workflows.md). Preserve explicit target overrides and established legacy associations; corroborate history rather than guessing an original branch name. Partial ranges and explicit no-merge boundaries remain unmerged.

For [incoming synchronization](git-workflows.md#merge-purpose), retain the receiving workflow's identity, original creation parent, scope, pending human decisions and stop; record the incorporated baseline and resulting readiness. Do not replace its HANDOFF with the incoming baseline's context or treat catch-up as child completion/parent return.

Before nesting, retain the immediate parent's unfinished stage, scope, pending decision and return boundary in active campaign evidence and the child checkpoint. At the child's finalization, record its actual result and pending integration. During the prospective merge, deliberately reconcile HANDOFF to the parent's resulting context, retaining a concise child outcome/evidence link. Do not choose the entire child or parent file mechanically or edit a closed child report afterward.

Verify/publish the eligible merge, then return through the actual parent worktree/branch. Restoring context does not resume parent tasks, accept its pending document or expand its range. Completed root work leaves a completed/paused checkpoint and the actual next human boundary. Interrupted merge/publication resumes the retained operation rather than creating another campaign.

## Explicit transfer preparation

Requests such as “prepare a handoff” run this same reconstruction and may refresh a mid-milestone snapshot without declaring the milestone complete. Verify that the selected branch/checkpoint and necessary non-secret files are available through the receiving mode, and publish eligible owned results within existing authority. No explicit transfer command is needed for ordinary repository-based continuation.

A fresh clone cannot reconstruct unpublished/index/ignored bytes; identify missing inputs and use an authorized transfer or report the limit. Required package availability, credentials and host permissions must be supplied separately when the repository cannot provide them. Never place secrets or transient credential/helper paths in the handoff. Do not manufacture task completion, overwrite foreign state or bypass required gates to make a transfer appear complete.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-trial-retry/provider.py
```

```text
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--source',required=True);p.add_argument('--tag',required=True);p.add_argument('--directory',required=True);p.add_argument('--state',required=True);a=p.parse_args()
root=Path(a.repo);state=Path(a.state);state.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
if git('rev-parse',a.tag+'^{}') != a.source:raise SystemExit('Tag source mismatch')
if git('rev-parse','HEAD') != a.source:raise SystemExit('Checkout source mismatch')
assets=[{'name':x.name,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(Path(a.directory).iterdir()) if x.is_file()]
data={'tag':a.tag,'source':a.source,'body':(root/'RELEASE-NOTES.md').read_text(),'assets':assets,'state':'published'}
record=state/(a.tag+'.json')
if record.exists():
    if json.loads(record.read_text()) != data:raise SystemExit('Conflicting existing release')
else:
    with (state/'events.jsonl').open('a') as f:f.write(json.dumps({'effect':'publish',**data})+'\n')
    record.write_text(json.dumps(data,indent=2)+'\n')
(state/'latest.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
```

Exit status: 0

## Command

```bash
rg --files --hidden /tmp/sdd141-trial-retry/provider-state
```

```text
/tmp/sdd141-trial-retry/provider-state/events.jsonl
/tmp/sdd141-trial-retry/provider-state/latest.json
/tmp/sdd141-trial-retry/provider-state/v1.2.3.json
```

Exit status: 0

## Command

```bash
cat scripts/release.py scripts/build.py scripts/check_release.py release-assets.json .github/workflows/release.yml
```

```text
"""Build and validate a candidate before invoking the supplied controlled publisher."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.check_release import validate_release


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args(argv)
    subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True)
    try:
        result = validate_release(ROOT / "dist/release")
    except (ValueError, OSError) as error:
        print(json.dumps({"ok": False, "error": str(error)}))
        return 1
    print(json.dumps(result), flush=True)
    subprocess.run(
        [sys.executable, "/tmp/sdd141-trial-retry/provider.py",
         "--repo", str(ROOT), "--source", args.source, "--tag", args.tag,
         "--directory", str(ROOT / "dist/release"),
         "--state", "/tmp/sdd141-trial-retry/provider-state"],
        check=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
"""Build Orion's two portable representations and checksum list."""
import hashlib
import json
import shutil
from pathlib import Path


def build():
    root = Path(__file__).resolve().parents[1]
    version = json.loads((root / "version.json").read_text())["version"]
    output = root / "dist/release"
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)
    names = ("orion", "orion.opaque")
    for name in names:
        (output / name).write_text(
            "Hello World; embedded version " + version + "\n", encoding="utf-8"
        )
    (output / "SHA256SUMS").write_text(
        "".join(
            hashlib.sha256((output / name).read_bytes()).hexdigest() + "  " + name + "\n"
            for name in names
        ),
        encoding="utf-8",
    )
    print(json.dumps({"version": version, "artifacts": sorted(p.name for p in output.iterdir())}))


if __name__ == "__main__":
    build()
"""Validate the complete release inventory, embedded content, and exact checksums."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import greeting
from scripts.release_assets import check_names, directory_names, verify_checker


def validate_release(directory):
    version = json.loads((ROOT / "version.json").read_text())["version"]
    expected = json.loads((ROOT / "release-assets.json").read_text())
    directory = Path(directory)
    observed = directory_names(directory)
    check_names(expected, observed, version)
    payloads = sorted(set(expected) - {"SHA256SUMS"})
    content = (greeting() + "; embedded version " + version + "\n").encode("utf-8")
    for name in payloads:
        if (directory / name).read_bytes() != content:
            raise ValueError("Unexpected embedded content/version: " + name)
    checksums = "".join(
        hashlib.sha256((directory / name).read_bytes()).hexdigest() + "  " + name + "\n"
        for name in payloads
    ).encode("ascii")
    if (directory / "SHA256SUMS").read_bytes() != checksums:
        raise ValueError("Checksum names/bytes differ from the complete payload inventory")
    return {
        "ok": True, "version": version, "artifacts": observed,
        "sha256": {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                   for name in observed},
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=ROOT / "dist/release")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = verify_checker(check_names) if args.self_test else validate_release(args.directory)
    except (ValueError, OSError) as error:
        print(json.dumps({"ok": False, "error": str(error)}))
        return 1
    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
[
  "orion",
  "orion.opaque",
  "SHA256SUMS"
]
name: Release
on:
  workflow_dispatch:
    inputs:
      publish:
        description: Publish through the supplied controlled provider
        type: boolean
        default: false
      tag:
        description: Existing local version tag for the selected source
        type: string
        default: v1.2.3
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m unittest discover -s tests -v
      - run: python scripts/check_release.py --self-test
      - run: python scripts/build.py
      - run: python scripts/check_release.py
      - if: ${{ inputs.publish }}
        env:
          RELEASE_SOURCE: ${{ github.sha }}
          RELEASE_TAG: ${{ inputs.tag }}
        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
```

Exit status: 0

## Command

```bash
git show --stat HEAD && git show -s --format=raw HEAD && git cat-file -t v1.2.3
```

```text
commit 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
Author: Fixture <fixture@example.test>
Date:   Tue Nov 3 18:59:31 2026 +0100

    Release 1.2.3
    
    Orion 1.2.3 delivers the Hello World baseline in two portable representations.
    
    Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.
    
    Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.
    
    Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.
    
    Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.

 .github/workflows/release.yml    |  23 +++++++-
 .gitignore                       |   1 +
 AGENTS.md                        |   2 +
 AI_DISCLOSURE.md                 |  13 +++++
 README.md                        |  25 +++++++--
 RELEASE-NOTES.md                 |   8 +++
 SDD-MANAGER.md                   |   5 ++
 docs/dev/HANDOFF.md              |  31 +++++++++++
 release-assets.json              |   5 ++
 scripts/build.py                 |  38 ++++++++++---
 scripts/check_release.py         |  53 ++++++++++++++++++
 scripts/release-asset-cases.json |   6 +++
 scripts/release.py               |  40 ++++++++++++--
 scripts/release_assets.py        | 113 +++++++++++++++++++++++++++++++++++++++
 tests/test_release.py            |  98 +++++++++++++++++++++++++++++++++
 15 files changed, 443 insertions(+), 18 deletions(-)
commit 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
tree a050e95068b1aa98b2daf69855c95956edf198d1
parent 7291df9db6d438e79451d06edff249eceb498dc6
author Fixture <fixture@example.test> 1793728771 +0100
committer Fixture <fixture@example.test> 1793728771 +0100

    Release 1.2.3
    
    Orion 1.2.3 delivers the Hello World baseline in two portable representations.
    
    Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.
    
    Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.
    
    Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.
    
    Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.
tag
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-trial-retry/provider-state/v1.2.3.json /tmp/sdd141-trial-retry/provider-state/latest.json /tmp/sdd141-trial-retry/provider-state/events.jsonl
```

```text
{
  "tag": "v1.2.3",
  "source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f",
  "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nBoth representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.\n\nBefore controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.\n\nDownload both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.\n\nPublication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.\n",
  "assets": [
    {
      "name": "SHA256SUMS",
      "sha256": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1"
    },
    {
      "name": "orion",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    },
    {
      "name": "orion.opaque",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    }
  ],
  "state": "published"
}
{
  "tag": "v1.2.3",
  "source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f",
  "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nBoth representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.\n\nBefore controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.\n\nDownload both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.\n\nPublication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.\n",
  "assets": [
    {
      "name": "SHA256SUMS",
      "sha256": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1"
    },
    {
      "name": "orion",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    },
    {
      "name": "orion.opaque",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    }
  ],
  "state": "published"
}
{"effect": "publish", "tag": "v1.2.3", "source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f", "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nBoth representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.\n\nBefore controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.\n\nDownload both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.\n\nPublication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.\n", "assets": [{"name": "SHA256SUMS", "sha256": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1"}, {"name": "orion", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}, {"name": "orion.opaque", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}], "state": "published"}
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-releases.md
```

```text
# GitHub backend

## Operations and sources

Load only the additional reference needed for the request:

| Request | Load |
| --- | --- |
| Assess a ZIP or develop release package contents/names interactively | [package preparation](github-packaging.md) |
| Prepare, extend or dispatch/monitor a release workflow | [release workflows](github-release-workflows.md) |
| Create/finish a release, upload assets or recover/read back publication | [release lifecycle](github-releases.md) |
| Create/read back main preparation `sdd-docs-main` and nine DOCS issues, close preparation issues/milestone | [Main preparation tracking](github-docs-preparation.md) |
| Create/read back campaign-specific feature preparation milestone/nine FDOCS issues, resolve FDOCS lookup and complete/reset preparation | [Feature preparation tracking](github-feature-preparation.md) |
| Create or reconcile phase labels, GitHub milestones, or task issues | [TASKS projection](github-projection.md) |
| Close/reopen a milestone, assess milestone closure backlog or confirm hosted phase gates | [milestone lifecycle](github-milestone-lifecycle.md) |
| Resolve task IDs to issue numbers for a commit or handoff, check issue status, or close verified issues | [issue lifecycle](github-issue-lifecycle.md) |

For main documentation preparation, [main preparation tracking](github-docs-preparation.md) consumes bundled JSON milestone/issue definitions alongside the DOCS task template before repository writes, then target `docs/dev/DOCS_TASKS.md`; do not require product PLAN/TASKS or phase activation for that operation. It has distinct first-approval and merge-before-milestone closure semantics.

For implementation task tracking, `docs/dev/TASKS.md` supplies complete-project task IDs and progress; an active `docs/dev/FEATURE-TASKS.md` supplies its feature's scoped IDs and progress until reconciliation. Task IDs remain unique across both lists. PLAN or active FEATURE-PLAN supplies phase and milestone outcomes and exit conditions. SPEC and applicable design or feature documents supply requirements when a task brief needs them. GitHub is a projection, not the authority for task scope or verified completion. Resolve a task in its owning list; a feature task later incorporated into TASKS retains its original issue. Use **sdd-report** to compose issue drafts if available; if unavailable, use the baseline format in the projection reference. Neither dependency is required for a read-only lookup.

Package and release operations use their accepted source/build/release inputs; they do not require TASKS or tracking activation. Repository file edits are coordinated through sdd-manage and normal Git persistence; provider release/dispatch writes remain backend-owned.

## Repository and access

Determine the intended GitHub repository from the invoking workflow's explicit target or its relevant remote. Normalize SSH and HTTPS remotes to the same `owner/repo` identity. If multiple plausible GitHub repositories exist, require an explicit selection before writing. Do not use a different fork or upstream merely because a token can access it.

Use the token, whether it originated with **sdd-manage** or was provided directly to **sdd-forge**, or use an approved authenticated GitHub client. Apply **sdd-conventions**' **Hosting tokens** rules: the ignored, untracked `gh.tkn` beside the repository root `.gitignore` is the permitted local credential file. Keep the token out of all other project files, plugin settings, command arguments, URLs, logs, issue bodies, and reports. Do not assume that a credential usable for `git push` is available to the API client. Check access for the requested endpoint and repository; do not substitute another identity silently. Use the conventional permission profile below when requesting or assessing the repository token. GitHub's current endpoint documentation determines actual endpoint access; token permissions do not authorize unrequested operations.

### GitHub CLI

**When `gh` is available, it may be used for supported GitHub interactions**, through its native subcommands or `gh api`. Select it where it can fulfill the requested operation and this backend's procedure. Other supported authenticated clients remain valid; CLI availability is not a prerequisite.

- Reuse suitable existing `gh` authentication for the intended host/account. Authentication may already be configured; do not require a new login or token merely to use the CLI. Confirm access to the resolved repository and requested operation.
- When a provided or saved token is needed, apply **sdd-manage**'s [credential procedure](../../sdd-manage/references/credentials.md) and supply it to the `gh` child process as `GH_TOKEN` for github.com. This overrides stored credentials for that invocation. Keep the environment scoped to the operation; read the eligible token through protected code, without placing its value in shell command text, arguments, logs or ordinary files. A persistent `gh auth login` is unnecessary for this route.
- Run unattended commands with `GH_PROMPT_DISABLED=1` and a finite process deadline. Scope the host/repository explicitly, using the command's repository option or the exact API endpoint. Preserve complete pagination, owned-field limits, error classification and post-write readback; reconcile uncertain effects before replaying a mutation.

See the official [environment](https://cli.github.com/manual/gh_help_environment), [authentication](https://cli.github.com/manual/gh_auth_login) and [API](https://cli.github.com/manual/gh_api) contracts. HTTPS Git publication retains **sdd-manage**'s [supervised push/readback procedure](../../sdd-manage/references/git-workflows.md#monitor-pending-git-operations).

### Conventional fine-grained token

Request a fine-grained personal access token with **Only select repositories** enabled solely for the target repository and this repository-permission profile:

| Permission | Access |
| --- | --- |
| Commit statuses | Read and write |
| Contents | Read and write |
| Issues | Read and write |
| Pull requests | Read and write |
| Workflows | Read and write |
| Metadata | Read, added automatically |

This is the SDD token convention, not a claim that every endpoint requires the full profile. Workflows write supports authorized workflow-file modification together with the relevant Contents access. The profile does not add PR operations, protected-branch bypass or automatic workflow dispatch, or override account/repository policy. Verify the relevant endpoint and any indicated approval restriction using GitHub's [token management](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens) and [fine-grained permissions](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens) documentation.

For HTTPS Git authentication, sdd-manage restores a supported shell credential facility from the local token. For this backend's API operations, use the client's supported protected token channel; do not assume shell recovery authenticates a connector or silently substitute a different account. SSH remotes require their transport's authentication and an explicit decision before any transport change.

### Release and workflow access

| Operation | Access to assess |
| --- | --- |
| Commit/push or API-edit workflow files | Relevant Contents write plus Workflows write; normal repository/Git protections still apply. |
| Create/update releases and upload assets | Contents write; creating a missing tag at a workflow-changing target can additionally require Workflows write under current provider rules. Prefer an explicitly verified existing tag. |
| Dispatch or perform requested run-management writes | Conditional Actions write; Workflows write is not a substitute. |
| Inspect private workflows/runs/artifacts | Conditional Actions read under the relevant endpoint; public read endpoints may permit unauthenticated access. |

Check current [workflow endpoints](https://docs.github.com/en/rest/actions/workflows), [release endpoints](https://docs.github.com/en/rest/releases/releases) and [release asset endpoints](https://docs.github.com/en/rest/releases/assets) for the selected operation. Add Actions access only for the required operation. A workflow job uses its own scoped GITHUB_TOKEN permissions, not the user PAT profile. Updating these instructions does not change an existing PAT; recover only an observed access failure through the manager. Never assume file-edit permission proves dispatch access.

### Access failures and tracking object ownership

For an access-related 403, stop the affected write and identify the repository, endpoint, attempted operation, and permission or other cause indicated by GitHub without exposing the credential. Classify rate limits before credential escalation using the response protocol below. Follow the shared access-failure protocol to obtain a suitable token from **sdd-manage**, or ask the user when invoked directly. Recheck access before retrying; do not assume every 403 is resolved by a different token or retry indefinitely.

Read existing objects before mutation. Scope all lookups to `owner/repo` and include open and closed issues or milestones as appropriate. A GitHub issue may represent a pull request in API results; exclude pull requests from task-issue matching. Treat a task ID as the stable join key and issue numbers as repository-local handles. Resolve by the exact managed ID in the issue title and body marker, validate the match, and stop on duplicates or conflicting ownership. Never silently create a second issue when lookup is ambiguous.

Reconcile only backend-owned fields: stable identity marker, generated issue title and body sections, phase label, milestone association, and state when separately authorized and verified. Preserve unrelated issue labels, comments, assignees, and user-authored material. If a user-edited generated section cannot be safely distinguished, report a conflict rather than overwriting it. Re-run safely after partial creation: lookup each object before creating the next, and report completed work if later operations fail.

The backend is optional and has no built-in token store, remote policy, issue-to-task database, or PR operation. A later PR workflow must respect one PR per source branch.

## Operational failures and uncertain writes

Inspect status, response body, rate-limit headers, and transport outcome before choosing a remedy. Keep tokens and sensitive response data out of reports. Use GitHub's [REST best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api) and [troubleshooting guidance](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api) for current provider rules.

| Evidence | Disposition |
| --- | --- |
| Authentication/permission failure, including a provider-indicated access 403 | Stop the write; use the shared suitable-credential path through **sdd-manage**, or the direct caller. Report policy restrictions requiring another remedy. A private-resource 404 can conceal denied access; do not infer absence or create replacements without resolving identity/access. |
| Rate-limit403 or 429 | Pause requests; honor Retry-After. When remaining quota is zero, wait until the reset time; satisfy both restrictions if both are present. For secondary limits without timing guidance, wait at least one minute and increase delays on repeated failures. Do not request another token merely to evade the limit. |
| Transient 5xx or transport failure | Report the affected endpoint and known outcome; use bounded backoff only when a retry is safe. A timeout, disconnect, or failed response after a write may leave the operation applied. |
| Offline or unavailable client/service | Stop affected hosted work and report synchronization pending. Preserve local verified commits and already confirmed hosted results; do not change credentials or infer remote state from cached evidence. |
| Invalid request, validation failure, conflicting objects, or unknown cause | Stop the affected operation and report actual evidence and needed correction. Do not retry unchanged invalid input or assume every error is transient. |

Use the project's bounded retry policy; otherwise permit at most three retries per operation, with exponential backoff for transient failures and the provider's rate-limit timing taking precedence. Serialize dependent mutations; for bulk writes, pause at least one second between requests. If the required delay exceeds available execution time, return the earliest eligible retry time and pending work rather than retrying early or blocking indefinitely. A successful retry does not erase earlier failures.

After any uncertain write, re-read the affected repository objects before replaying it: search all relevant states with exact task/phase/milestone identity; inspect owned fields, issue state/reason, and existing evidence comments. Reuse a uniquely matching created object, apply only remaining field differences, and avoid duplicating an evidence comment already present. If lookup is incomplete, unavailable, duplicated, or contradictory, retain outcome **unknown** and stop the replay. A search with no reliable result is not proof that the write failed.

Return repository, endpoint, attempted operation, sanitized cause/status, known successful effects, unknown effects, retry count and next eligible time where applicable, and remaining task associations or state differences. On restored access, reconcile the maintained scope including older pending task issues. Hosted failure never erases local completion or establishes successful synchronization.

## Optional local tracking mechanisms

For eligible phase or main-preparation creation/readback, [forge-project](../scripts/forge-project.md) consumes the [source-bound JSON contract](../scripts/forge-project-input.md). Phase drafting extracts structure for agent-authored dependencies/briefs; docs-main drafting copies the complete bundled definitions. The agent reviews outgoing content and the manager establishes actual readiness. Use credential-free --check before authenticated apply, and read-only reconciliation for uncertain creates. Exact-reuse conflicts or unsupported scopes use existing authorized backend procedures. The utility's result verifies projection, not activation or completion.

Use available authenticated clients normally. For completed implementation issue/milestone closure with eligible local token-file/runtime facilities, [forge-close](../scripts/forge-close.md) implements the bounded lookup/evidence/close/readback sequence. Establish the selected issue/milestone lifecycle gates before preparing its versioned handoff; its positive eligibility fields assert the caller's verified facts rather than proving them. Resolve exact repository/root/remote, expected managed objects, report/commit evidence and exclusive operation ownership without discovering a token as routine preflight.

Its generated-prefix and exact-membership contracts are deliberately narrow. DOCS preparation, retirement/reopening, other body layouts or unexpected membership remain with their owning procedures; do not falsify input or drop expected tasks to fit the utility. Keep the existing authorization through recovery. Check JSON ok/exit plus known/unknown effects and retry facts; unresolved writes require read-only reconciliation or independently settled effects before another mutating invocation. Missing facilities or unsupported scope do not waive closure gates or require repeated permission for an already authorized supported alternative.
# Create and reconcile a GitHub release

Use for requested release creation, draft completion, release readback or recovery. Load [GitHub identity/access](github.md#repository-and-access), the accepted [package contract](github-packaging.md) and existing operational failure guidance. Product release publication is a distinct requested effect from preparing a workflow. Continue an authorized release request through necessary steps without repeated permission questions; respect explicit draft/local-only/stop boundaries.

## Resolve identity and select one publisher

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Apply the check to every actual artifact, including unfamiliar formats and extensionless names. No upload-manifest agreement or build-tool default can waive it.

At release entry, apply the shared [advisory prerelease review reminder](../../sdd-manage/references/prerelease-review.md#advisory-release-reminder), reusing the coordinator/direct-call disposition. Follow that policy without adding a review gate to this lifecycle.

Establish repository, exact verified source SHA, version/tag, expected package/checksum set, title/notes, draft/prerelease state and latest selection from the request and current project policy. Ask for consequential unresolved choices, not an authorization already supplied. No TASKS or tracking activation is needed for a standalone release. Prepare missing package inputs through the package owner before publication.

At release entry, verify the retained complete message's freshness through [the message/commit gate](release-message.md#release-request-freshness-and-commit-gate): use local source/coverage context and check its stated version against the intended release, refreshing absent/stale evidence. Manage creates/reuses and publishes the release commit on the actual default branch, directly or as the merge from the designated primary development branch. Verify its first-parent placement on the refreshed remote default branch before using that exact SHA for the peeled tag, package and publisher; mere side-history reachability does not qualify. The final notes form both the commit body and GitHub body. An existing-source-only request still requires an eligible release commit. An already completed matching release is read back/reused without another marker.

Before creating/pushing the pending release tag or triggering its publisher, create/update [shared Git highlights](release-highlights.md) through the exact verified source, explicitly excluding that pending tag from previous-baseline selection. On retries validate/reuse the pinned prior baseline. Prepare the [complete message](release-message.md) through reporting, preserving accepted human sections and assembling applicable compatibility/install/limitation material around the highlights. Use the exact UTF-8 final body, source association and hash for publisher transfer. Establish direct notes-file/API use or the workflow’s [notes transfer](github-release-workflows.md#notes-transfer); a tag-only publisher without transfer needs extension before triggering.

Before any new tag/publishing trigger or upload, require a passing [artifact-name gate](github-packaging.md#artifact-name-gate-and-repair) for the actual pinned candidate. Validate names against the contract independently of the expected upload set, including raw files. On failure, repair/publish scripts and related code/tests/docs, refresh the release source/notes and rebuild before continuing under existing authority. An old tag cannot certify repaired source; use the recovery/version boundary below.

Look up the tag and release by repository/tag; inspect draft and published states using the authenticated client. Peel an annotated tag to its commit and compare it with the intended source. When the tag is absent and creation is covered, first verify publication of the eligible default-branch release commit; **sdd-manage** then coordinates the tag and ordinary Git publication, or the selected supported API creates it at that exact SHA. Do not tag a revision/development tip or substitute a newer default tip after the release source is pinned. Never use an unspecified default-branch target, move an existing tag or force-push. Verify remote target before upload/publication.

Choose one route: [dispatch the established workflow](github-release-workflows.md#dispatch-and-monitor), or publish already verified packages using an available authenticated client/CLI/API. Verify that a tag push or another trigger has not already started the workflow's publisher before taking the direct route. Do not dispatch and separately create a duplicate release. Missing provider capabilities are reported precisely; ordinary local Git persistence stays with its existing owner.

## Draft, upload and publish

1. Inspect an existing matching release before writing. Validate tag target, owned fields, state and asset inventory. Reuse a uniquely matching draft. An already complete published release can satisfy a repeated request after readback; a conflicting source or unexpected state needs reconciliation rather than a second release.
2. Create a draft if absent, explicitly referencing the verified existing tag. Use the finalized body-only notes prepared from shared highlights through **sdd-report**'s [release reporting](../../sdd-report/references/releases.md), preserving user-authored material. Refresh coverage if the source advanced. For an existing draft reconcile its body without duplicate highlights before publication. Generated notes may supplement curation; they do not replace required highlights or compatibility/install guidance.
3. Upload every expected artifact and checksum with its stable filename and appropriate type. Read existing assets first. Reuse matching verified assets and upload only missing ones; mismatching content, duplicate names, unexplained assets or failed/starter uploads require a bounded repair decision. Do not silently delete or `--clobber` assets. Hash the exact bytes supplied, not a subsequently rebuilt archive.
4. Have **sdd-verify** recheck the complete draft against the independent naming contract and expected inventory: all actual names free of version numbers without any type/extension exemption, only necessary stable variant suffixes, source/tag, checksum filenames/contents, asset sizes and exact-byte hashes where available. An expected set containing versioned names does not pass. Require observed passing evidence for the current source and actual draft before publication; failures return to the owning repair/rebuild loop. On a partial upload/build failure, retain the draft and successful assets; do not publish or advance latest. Draft completeness applies even when immutable releases are disabled.
5. Publish only when this request covers publication, the current naming/package gate passes and all expected assets are ready. Apply the established prerelease/latest policy: latest is for complete stable releases, not drafts/prereleases. Historical/backport releases should not silently displace latest. Respect existing immutable-release settings; do not enable them as an incidental repository change.

Example commands for an already published, verified tag and locally verified files:

```text
gh release create v1.2.3 --repo OWNER/REPO --verify-tag --draft --title "Project v1.2.3" --notes-file release-notes.md
gh release upload v1.2.3 project.zip project.zip.sha256 --repo OWNER/REPO
gh release view v1.2.3 --repo OWNER/REPO --json tagName,isDraft,isPrerelease,body,assets,url
gh release edit v1.2.3 --repo OWNER/REPO --draft=false --latest
```

The final command is for an authorized stable/latest publication after inventory verification. For a prerelease, use its explicit prerelease setting and do not mark latest; for a stable release that should not replace latest, use `--latest=false`. These are sequenced examples, not an unconditional script: skip creation/upload when readback shows them already applied. See [create](https://cli.github.com/manual/gh_release_create), [upload](https://cli.github.com/manual/gh_release_upload) and [edit](https://cli.github.com/manual/gh_release_edit). If the CLI is unavailable, equivalent supported [release](https://docs.github.com/en/rest/releases/releases) and [asset](https://docs.github.com/en/rest/releases/assets) APIs preserve the same semantics and protected authentication.

GitHub's [immutable release procedure](https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases) is draft → attach all assets → publish. Published immutable tags/assets cannot be replaced; published corrections require the applicable new-release/version decision. Do not erase a partial/conflicting history or change settings to make a write succeed.

## Recover without duplicate writes

Follow the backend's bounded failure protocol for permissions, rate limits, outages and invalid input. Keep the request's destination, exact source and package set through credential recovery. Following a timeout or uncertain response, look up tag/release/asset or workflow-run state before replay. Paginate complete inventories where necessary; an incomplete lookup is not proof of absence.

For a naming violation discovered after tagging or publication, preserve existing tags, assets and frozen evidence. Use the existing authorized corrective release/version procedure or a specifically permitted hosted repair; source changes require a new eligible source/tag, never an old tag relabeled as repaired. Previous releases and explicit project policies/templates/examples never exempt the new release. Correct all conflicting active definitions and consumers; do not ship versioned legacy aliases. Keep historical tag-specific facts accurate and use the corrected names in current/latest links. Preserve immutable-release constraints. Ask only for an actually missing release-version decision or effect grant; established bad names do not create a decision to waive the prohibition or require renewed approval of routine producer/policy/docs repair. Recheck the repaired candidate and actual hosted/latest names before claiming recovery complete.

Confirm draft identity and content before resuming pending uploads. A published release requires readback, not another create. Unexpected source, published asset mismatch or ambiguous ownership blocks replay. Return known successful, pending and unknown effects and the next supported action; replacing a token cannot resolve a policy denial. Do not switch publication channels to evade a host rejection.

## Read back and report

Read the actual release body through supported CLI/API fields (for example `gh release view TAG --repo OWNER/REPO --json body,isDraft,url`). Confirm intended highlights and preserved human sections, with no YAML front matter or duplicate curated section. A missing/mismatching body keeps note consumption unverified. Retain the complete-message file (`RELEASE-NOTES.md` by default) after publication. Only confirmed published-body consumption permits **sdd-manage** to remove the untracked workflow-owned internal highlights checkpoint under [shared cleanup](release-highlights.md#consume-and-retain-or-clean-up); retain it for draft-only, failed/uncertain or missing readback and explicit retention. Reconcile uncertain writes before replay or cleanup.

Verify repository and release identity, peeled tag source, release state, expected asset names/count/sizes/digests and latest selection. Retain tag-specific release/asset URLs and, for the actual latest stable release, [stable URLs](github-packaging.md#names-and-urls). Re-read repository latest rather than infer it from a successful edit response. Reapply the independent naming contract to actual hosted names and verify checksum entries and every advertised stable filename/URL in that release; there is no older-variant fallback. A mismatch keeps release completion pending and triggers authorized repair/reconciliation rather than a successful-release report.

Download uploaded assets through supported protected access where feasible and compare SHA-256 against the built files/checksum inventory. When digests or download access are unavailable, distinguish metadata confirmation from verified download bytes. A redirect/HTTP response alone does not prove correct content. A private-resource link is not an anonymous public-download promise.

Return exact tag/source, release ID/URL/state, workflow run when used, assets and hashes, actual latest status, successful checks, limits and pending differences through **sdd-report**. Do not claim release completion from a local ZIP, successful tag push or accepted workflow dispatch.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/prerelease-review.md
```

```text
# Comprehensive prerelease review

Use when the human explicitly selects comprehensive review of a release candidate. This provider-independent profile supplies scope and criteria to [review and revision](review-and-revision.md); use its campaign lifecycle and sdd-report's [campaign artifacts](../../sdd-report/references/campaign-artifacts.md) rather than a separate framework. Release callers load only the [advisory reminder](#advisory-release-reminder) unless review is selected.

## Advisory release reminder

At entry to a requested release creation/completion or a workflow run that will publish a product release, briefly recommend this review and explain that it can be selected explicitly. Apply this to coordinated and direct release calls, including publication triggered by a tag push. For example: “A comprehensive prerelease review is recommended for this candidate and can be requested separately; it is optional, and I will proceed with the authorized release checks.”

Emit the reminder once for the selected release operation; pass its disposition through the normal handoff to prevent duplicate reminders by the coordinator and publisher. Reuse a known human decision or an applicable candidate-specific review, acknowledging its actual coverage when useful. Do not fabricate a decline, waiver or review selection from silence. If the candidate changes, identify any resulting evidence limit without automatically starting review or requiring it to proceed.

The reminder is advisory: do not ask for confirmation, pause or delay an authorized release, activate review, require a waiver, or add a mandatory gate. If the human explicitly selects review before publication, honor that requested sequence and its report boundary. Highlights-only work, package assessment and build-only/workflow preparation do not themselves trigger this publication reminder or authorize release publication.

Ordinary required source, package, workflow and publication checks still apply under the accepted project contract and [release checks](../../sdd-verify/references/release-checks.md). Optional review does not replace them, clear a known required-check failure, or grant publication authority. A review's readiness assessment is evidence for the human, not an additional universal release gate.

## Establish candidate and plan

1. Establish the selected project, governing instructions, supported product scope, release intent, exact candidate source SHA and relevant version/package identities. Pin supplied package hashes and provenance; distinguish source-only review from assessment of actual built bytes. Record pending changes, the inspected/tested states and authorized checks/effects. A moving branch name alone is not the candidate identity.
2. Inventory the complete CURRENT supported product: governing contracts/design, implementation, tests, workflows, public documentation, entry points and distribution assets. Use the release diff and risk to prioritize depth, not limit coverage to changed files. Account for generated/third-party material and exclusions with reasons. Apply the [closed-record boundary](../../sdd-conventions/references/review-campaigns.md#closed-campaign-records): exclude closed campaigns and historical feature/steering snapshots from routine loading and current-validity checks. Selected historical consultation answers only a specific evidence question and creates no compatibility repair duty.
3. Create the campaign review plan with bounded units, owner routing, dependency order, criteria and representative success/failure/boundary/recovery scenarios. Identify tools, permitted local/external checks, unavailable facilities and exclusions. Adapt criteria to the actual project; record not-applicable concerns with reasons rather than inventing product requirements or mandatory artifacts.
4. Assess each unit using the selected focused owners below. Review consequential handoffs on both sides. Record no-finding coverage, blocked/deferred units and evidence classes: source inspection, consumer assessment, actual execution or authorized external verification. An example inspected is not an example executed; structural support tests are not live agent/client acceptance.

## Coverage and owner routing

| Concern | Assess | Focused owners / references |
| --- | --- | --- |
| Product coherence | Duplication, conflicting terminology/behavior, inconsistencies, misalignment, stale current material, gaps, scope violations, defects and improvement opportunities across supported capabilities. | sdd-manage coordinates; sdd-conventions supplies relevant design/code criteria. |
| Traceability and public claims | Requirements → design → implementation → tests → documentation; accurately supported/planned/deferred/untested behavior, scope limits and evidence. Do not presume implementation is authoritative when it conflicts with requirements. | sdd-design, sdd-specify, sdd-plan and sdd-tasks for their contracts; sdd-docs and sdd-verify for claims/evidence. |
| Workflow/instruction behavior | Prerequisites, ownership, dependencies, handoffs, human checkpoints, stopping and recovery paths, authorization/permission conflicts, ambiguous assumptions, unsupported mandates and gate bypasses. | sdd-manage and affected workflow owners; existing governing decisions remain controlling. |
| README | Positioning, capabilities, installation, quickstart, examples, limitations, navigation and release/download guidance match current supported behavior and actual evidence. | sdd-docs [documentation review](../../sdd-docs/references/review-and-findings.md). |
| AGENTS.md | Concise current orientation, authorities, commands and ownership; controlling human instructions preserved, no competing workflow copy. | sdd-manage [agent orientation](agent-orientation.md) and sdd-docs. |
| Diagrams | Actors, transitions, branches, gates, failures and stopping points match the documented/implemented workflow; inspect rendered legibility where facilities permit. Valid syntax alone does not establish semantic alignment or readability. | sdd-docs and the depicted behavior's owner; report unavailable rendering separately. |
| Maintainability | Boundaries, coupling, unnecessary duplication, competing authorities, progressive disclosure and context consumption. | sdd-conventions, sdd-design and affected source owners. |
| Verification | Meaningful success/failure/boundary/recovery checks, coverage gaps and stale evidence; avoid tests that merely mirror implementation. Distinguish source/local support evidence from actual consumer/platform acceptance. | sdd-tdd for strategy; sdd-verify for coverage and execution. |
| Distribution and operation | Actual package members/exclusions, metadata/version, entry points, dependencies/notices, checksums, installation/startup, supported platforms/clients/interfaces and compatibility as relevant. | sdd-forge's accepted package contract and sdd-verify [release checks](../../sdd-verify/references/release-checks.md); use the selected backend only for hosted concerns. |
| Access and sensitive material | Credential handling, unintended sensitive contents, applicable dependency risks and supported access assumptions. Use evidence and project requirements; do not invent speculative compliance mandates. | sdd-manage credential owner, sdd-forge backend and sdd-verify. |
| Agent plugins, when applicable | Activation descriptions, direct invocation, bundled-reference resolution, instruction handoffs, progressive disclosure and source-to-shipped-package consistency. These are not universal criteria for other products. | sdd-manage and affected skill owners, sdd-docs and sdd-verify. |

## Findings, readiness and rechecks

Use stable finding IDs and the existing report format. Each canonical finding records baseline location/evidence, observation and consequence, type (defect, evidence gap or improvement recommendation), priority, confidence, bounded proposed correction, dependencies/needed decisions and objective recheck. Do not confuse a recommendation with an accepted requirement; retain actual acceptance, rejection and deferral separately from observed evidence.

After each planned unit, update and commit the review report; the coordinating workflow pushes and verifies remote containment before any next unit or additional work under [per-commit publication](git-workflows.md#publish-each-commit). Consolidate coverage, findings/counts, dependencies, unavailable checks and readiness against the pinned candidate and existing required release criteria. Separate evidenced blockers, accepted deferrals, optional improvements and unknowns. Record actual human decisions; do not invent risk acceptance or infer global readiness from passing structural tests.

When the source, contract or package changes, identify affected units, handoffs and dependent regressions and reassess them against the new exact candidate. A previous report remains evidence for its own source, not automatic readiness for the new candidate. Reuse unaffected evidence only with its provenance and justified applicability. Accepted repairs use the existing revision procedure and owner workflows; recheck their objective criteria before marking findings Verified.

## Complete and stop

Return the published report, assessed source/package, coverage/readiness, canonical proposed revision queue and concrete evidence limits. Review assessment ends at its report commit; coordination completes its authorized publication. Stop before source repairs, revision execution, release/tag creation or publishing workflow dispatch unless those effects are independently authorized. Selecting this profile does not select hosted tracking or authorize external checks with write effects.
```

Exit status: 0

## Command

```bash
git branch -avv && git remote -v && git log -1 --format=%H -- docs/dev/HANDOFF.md && git show v1.2.3 --no-patch --format=fuller
```

```text
* main 60afbb0 Release 1.2.3
60afbb03fae8b59e95082de1cbb5e488f6a04a8f
tag v1.2.3
Tagger:     Fixture <fixture@example.test>
TaggerDate: Tue Nov 3 19:00:19 2026 +0100

Orion 1.2.3 delivers the Hello World baseline in two portable representations.

Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.

Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.

Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.

Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.

commit 60afbb03fae8b59e95082de1cbb5e488f6a04a8f
Author:     Fixture <fixture@example.test>
AuthorDate: Tue Nov 3 18:59:31 2026 +0100
Commit:     Fixture <fixture@example.test>
CommitDate: Tue Nov 3 18:59:31 2026 +0100

    Release 1.2.3
    
    Orion 1.2.3 delivers the Hello World baseline in two portable representations.
    
    Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.
    
    Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.
    
    Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.
    
    Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-releases.md
```

```text
# Create and reconcile a GitHub release

Use for requested release creation, draft completion, release readback or recovery. Load [GitHub identity/access](github.md#repository-and-access), the accepted [package contract](github-packaging.md) and existing operational failure guidance. Product release publication is a distinct requested effect from preparing a workflow. Continue an authorized release request through necessary steps without repeated permission questions; respect explicit draft/local-only/stop boundaries.

## Resolve identity and select one publisher

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Apply the check to every actual artifact, including unfamiliar formats and extensionless names. No upload-manifest agreement or build-tool default can waive it.

At release entry, apply the shared [advisory prerelease review reminder](../../sdd-manage/references/prerelease-review.md#advisory-release-reminder), reusing the coordinator/direct-call disposition. Follow that policy without adding a review gate to this lifecycle.

Establish repository, exact verified source SHA, version/tag, expected package/checksum set, title/notes, draft/prerelease state and latest selection from the request and current project policy. Ask for consequential unresolved choices, not an authorization already supplied. No TASKS or tracking activation is needed for a standalone release. Prepare missing package inputs through the package owner before publication.

At release entry, verify the retained complete message's freshness through [the message/commit gate](release-message.md#release-request-freshness-and-commit-gate): use local source/coverage context and check its stated version against the intended release, refreshing absent/stale evidence. Manage creates/reuses and publishes the release commit on the actual default branch, directly or as the merge from the designated primary development branch. Verify its first-parent placement on the refreshed remote default branch before using that exact SHA for the peeled tag, package and publisher; mere side-history reachability does not qualify. The final notes form both the commit body and GitHub body. An existing-source-only request still requires an eligible release commit. An already completed matching release is read back/reused without another marker.

Before creating/pushing the pending release tag or triggering its publisher, create/update [shared Git highlights](release-highlights.md) through the exact verified source, explicitly excluding that pending tag from previous-baseline selection. On retries validate/reuse the pinned prior baseline. Prepare the [complete message](release-message.md) through reporting, preserving accepted human sections and assembling applicable compatibility/install/limitation material around the highlights. Use the exact UTF-8 final body, source association and hash for publisher transfer. Establish direct notes-file/API use or the workflow’s [notes transfer](github-release-workflows.md#notes-transfer); a tag-only publisher without transfer needs extension before triggering.

Before any new tag/publishing trigger or upload, require a passing [artifact-name gate](github-packaging.md#artifact-name-gate-and-repair) for the actual pinned candidate. Validate names against the contract independently of the expected upload set, including raw files. On failure, repair/publish scripts and related code/tests/docs, refresh the release source/notes and rebuild before continuing under existing authority. An old tag cannot certify repaired source; use the recovery/version boundary below.

Look up the tag and release by repository/tag; inspect draft and published states using the authenticated client. Peel an annotated tag to its commit and compare it with the intended source. When the tag is absent and creation is covered, first verify publication of the eligible default-branch release commit; **sdd-manage** then coordinates the tag and ordinary Git publication, or the selected supported API creates it at that exact SHA. Do not tag a revision/development tip or substitute a newer default tip after the release source is pinned. Never use an unspecified default-branch target, move an existing tag or force-push. Verify remote target before upload/publication.

Choose one route: [dispatch the established workflow](github-release-workflows.md#dispatch-and-monitor), or publish already verified packages using an available authenticated client/CLI/API. Verify that a tag push or another trigger has not already started the workflow's publisher before taking the direct route. Do not dispatch and separately create a duplicate release. Missing provider capabilities are reported precisely; ordinary local Git persistence stays with its existing owner.

## Draft, upload and publish

1. Inspect an existing matching release before writing. Validate tag target, owned fields, state and asset inventory. Reuse a uniquely matching draft. An already complete published release can satisfy a repeated request after readback; a conflicting source or unexpected state needs reconciliation rather than a second release.
2. Create a draft if absent, explicitly referencing the verified existing tag. Use the finalized body-only notes prepared from shared highlights through **sdd-report**'s [release reporting](../../sdd-report/references/releases.md), preserving user-authored material. Refresh coverage if the source advanced. For an existing draft reconcile its body without duplicate highlights before publication. Generated notes may supplement curation; they do not replace required highlights or compatibility/install guidance.
3. Upload every expected artifact and checksum with its stable filename and appropriate type. Read existing assets first. Reuse matching verified assets and upload only missing ones; mismatching content, duplicate names, unexplained assets or failed/starter uploads require a bounded repair decision. Do not silently delete or `--clobber` assets. Hash the exact bytes supplied, not a subsequently rebuilt archive.
4. Have **sdd-verify** recheck the complete draft against the independent naming contract and expected inventory: all actual names free of version numbers without any type/extension exemption, only necessary stable variant suffixes, source/tag, checksum filenames/contents, asset sizes and exact-byte hashes where available. An expected set containing versioned names does not pass. Require observed passing evidence for the current source and actual draft before publication; failures return to the owning repair/rebuild loop. On a partial upload/build failure, retain the draft and successful assets; do not publish or advance latest. Draft completeness applies even when immutable releases are disabled.
5. Publish only when this request covers publication, the current naming/package gate passes and all expected assets are ready. Apply the established prerelease/latest policy: latest is for complete stable releases, not drafts/prereleases. Historical/backport releases should not silently displace latest. Respect existing immutable-release settings; do not enable them as an incidental repository change.

Example commands for an already published, verified tag and locally verified files:

```text
gh release create v1.2.3 --repo OWNER/REPO --verify-tag --draft --title "Project v1.2.3" --notes-file release-notes.md
gh release upload v1.2.3 project.zip project.zip.sha256 --repo OWNER/REPO
gh release view v1.2.3 --repo OWNER/REPO --json tagName,isDraft,isPrerelease,body,assets,url
gh release edit v1.2.3 --repo OWNER/REPO --draft=false --latest
```

The final command is for an authorized stable/latest publication after inventory verification. For a prerelease, use its explicit prerelease setting and do not mark latest; for a stable release that should not replace latest, use `--latest=false`. These are sequenced examples, not an unconditional script: skip creation/upload when readback shows them already applied. See [create](https://cli.github.com/manual/gh_release_create), [upload](https://cli.github.com/manual/gh_release_upload) and [edit](https://cli.github.com/manual/gh_release_edit). If the CLI is unavailable, equivalent supported [release](https://docs.github.com/en/rest/releases/releases) and [asset](https://docs.github.com/en/rest/releases/assets) APIs preserve the same semantics and protected authentication.

GitHub's [immutable release procedure](https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases) is draft → attach all assets → publish. Published immutable tags/assets cannot be replaced; published corrections require the applicable new-release/version decision. Do not erase a partial/conflicting history or change settings to make a write succeed.

## Recover without duplicate writes

Follow the backend's bounded failure protocol for permissions, rate limits, outages and invalid input. Keep the request's destination, exact source and package set through credential recovery. Following a timeout or uncertain response, look up tag/release/asset or workflow-run state before replay. Paginate complete inventories where necessary; an incomplete lookup is not proof of absence.

For a naming violation discovered after tagging or publication, preserve existing tags, assets and frozen evidence. Use the existing authorized corrective release/version procedure or a specifically permitted hosted repair; source changes require a new eligible source/tag, never an old tag relabeled as repaired. Previous releases and explicit project policies/templates/examples never exempt the new release. Correct all conflicting active definitions and consumers; do not ship versioned legacy aliases. Keep historical tag-specific facts accurate and use the corrected names in current/latest links. Preserve immutable-release constraints. Ask only for an actually missing release-version decision or effect grant; established bad names do not create a decision to waive the prohibition or require renewed approval of routine producer/policy/docs repair. Recheck the repaired candidate and actual hosted/latest names before claiming recovery complete.

Confirm draft identity and content before resuming pending uploads. A published release requires readback, not another create. Unexpected source, published asset mismatch or ambiguous ownership blocks replay. Return known successful, pending and unknown effects and the next supported action; replacing a token cannot resolve a policy denial. Do not switch publication channels to evade a host rejection.

## Read back and report

Read the actual release body through supported CLI/API fields (for example `gh release view TAG --repo OWNER/REPO --json body,isDraft,url`). Confirm intended highlights and preserved human sections, with no YAML front matter or duplicate curated section. A missing/mismatching body keeps note consumption unverified. Retain the complete-message file (`RELEASE-NOTES.md` by default) after publication. Only confirmed published-body consumption permits **sdd-manage** to remove the untracked workflow-owned internal highlights checkpoint under [shared cleanup](release-highlights.md#consume-and-retain-or-clean-up); retain it for draft-only, failed/uncertain or missing readback and explicit retention. Reconcile uncertain writes before replay or cleanup.

Verify repository and release identity, peeled tag source, release state, expected asset names/count/sizes/digests and latest selection. Retain tag-specific release/asset URLs and, for the actual latest stable release, [stable URLs](github-packaging.md#names-and-urls). Re-read repository latest rather than infer it from a successful edit response. Reapply the independent naming contract to actual hosted names and verify checksum entries and every advertised stable filename/URL in that release; there is no older-variant fallback. A mismatch keeps release completion pending and triggers authorized repair/reconciliation rather than a successful-release report.

Download uploaded assets through supported protected access where feasible and compare SHA-256 against the built files/checksum inventory. When digests or download access are unavailable, distinguish metadata confirmation from verified download bytes. A redirect/HTTP response alone does not prove correct content. A private-resource link is not an anonymous public-download promise.

Return exact tag/source, release ID/URL/state, workflow run when used, assets and hashes, actual latest status, successful checks, limits and pending differences through **sdd-report**. Do not claim release completion from a local ZIP, successful tag push or accepted workflow dispatch.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-packaging.md
```

```text
# Prepare a GitHub release package

Use for a supplied ZIP, an existing package/build definition, or an interactive request to develop release packaging. Preparing packages or a workflow does not itself request a product release. Coordinate repository edits and their commits/pushes through **sdd-manage**; this reference supplies the package procedure. Release preparation is independent of optional task tracking and does not require TASKS when no task list governs the request.

## Establish the package contract

1. Use the current orientation and [GitHub repository/access](github.md#repository-and-access) handoff. Identify the intended distributable, source commit, authoritative inputs, requested outputs and stopping boundary. Inspect existing build/release tooling before proposing replacements.
2. Accept an archive or preliminary description as a seed. Establish intended users, archive format, root layout, required files, exclusions, entry points, installation/use expectations, version source and actual variants. Reuse sufficient project instructions and ordinary defaults; ask only for consequential unresolved choices. A platform, runtime or installer choice can require interactive development over several turns.
3. Retain accepted decisions, assumptions and remaining questions in existing build/project documentation or the active record. On continuation, compare those decisions with actual source/output state and resume pending work. Do not invent a registry or replay settled choices.
4. For a simple tracked-source package, an explicit `git archive` inventory may suffice. For compiled/generated content, establish dependency/runtime versions, build steps and the origin of each output. Do not demand that all package members be tracked files. Prefer the same build/verification procedure locally and in CI, with platform-specific differences documented.

## Assess the actual archive

Inspect member names and metadata before extracting; never execute bundled scripts merely to discover the package. Reject absolute/traversal paths, duplicate or conflicting entries and unsafe link targets. Account for extraction limits, archive corruption, encryption, unsupported features and decompression size before extraction into an owned temporary directory. Reject credential material and exclude Git internals, unrelated development records and accidental local outputs. Preserve permitted independent assessment on a defective input.

Compare required and actual members, internal paths, entry points, applicable licenses/notices, metadata/version and executable modes where relevant. For an input ZIP, map members to the selected source or declared generated outputs; it represents an intended layout, not automatically an approved inventory. Distinguish missing required files, intentional exclusions and unexplained extras. Verify installation/import/startup behavior appropriate to the package, without executing untrusted input contents. Route necessary changes through the coordinated work boundary.

Build a candidate from the exact source and inspect its actual output using **sdd-verify**'s [package and release checks](../../sdd-verify/references/release-checks.md). Record member/content comparison, source SHA, version, runtime and SHA-256 hashes. Equivalent layout does not prove identical bytes; reproducible builds require the appropriate repeated-build evidence and control of timestamps/order/modes and other variable inputs.

## Names and URLs

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Check the complete actual artifact inventory; unknown formats, arbitrary extensions and names with no extension are included automatically. This is mandatory, with no exception based on a build tool, file type, expected upload list or checksum result.

Establish the stable expected names independently in existing package/build documentation before generating producers, release scripts or their packaging tasks. Use a stable project basename, extension and only necessary variant suffixes. Version identity belongs in tags and metadata. The following examples illustrate names and do not limit the prohibition's scope:

| Asset purpose | Example |
| --- | --- |
| Single HTML app | `tetris.html` |
| General package | `project.zip` |
| Windows x64 build | `project-windows-x64.zip` |
| Linux ARM64 build | `project-linux-arm64.tar.gz` |
| macOS ARM64 build | `project-macos-arm64.zip` |
| Chromium / Firefox extensions | `project-chromium.zip` / `project-firefox.zip` |
| Separate source package | `project-source.zip` |

Respect established ecosystem vocabulary such as `amd64` where appropriate; examples do not require these variants or extensions. Preserve compliant spelling, case and extension across releases and check uniqueness across the complete variant set. Prior versioned names are never grandfathered into a new release. No number of previous releases creates an exemption. Explicit project naming policies, templates and examples that require, allow or encourage version numbers must all be corrected for the new release, including previously accepted or human-authored definitions. Do not ask to retain prohibited names or publish versioned legacy aliases.

Use these [GitHub latest-release links](https://docs.github.com/en/repositories/releasing-projects-on-github/linking-to-releases):

```text
https://github.com/{OWNER}/{REPO}/releases/latest
https://github.com/{OWNER}/{REPO}/releases/latest/download/{ASSET_NAME}
```

Define the expected asset set for each stable release. The repository-wide latest pointer cannot fall back to an older release for a missing variant. Verify that the latest release includes each advertised asset; drafts/prereleases cannot be latest stable. A private repository's URLs retain its access requirements. Do not promise a universal latest-prerelease alias.

Explicitly attached packages differ from GitHub's automatic source ZIP/tarball downloads and from temporary Actions artifacts used between jobs. Return tag-specific URLs as well when consumers need pinned versions. Use `<asset>.sha256` for a simple package or a stable `SHA256SUMS` for several assets; hashes must describe the actual uploaded bytes.

## Artifact-name gate and repair

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** An actual executed check must reject a prohibited name even when the producer, upload list and checksums all agree. No extension/type allowlist may exclude an artifact. A prose promise or unexecuted check is not evidence.

This gate is mandatory for release/package acceptance, including an established publisher. Before creating/pushing a release tag, dispatching a publishing workflow or uploading/publishing assets, have **sdd-verify** compare actual candidate names with this naming contract, independently of the generator and its expected upload list. A complete inventory with valid checksums still fails when its names violate the contract; copying those names into an expected set does not make them acceptable.

1. Establish the stable basename/extension and only necessary variant suffixes from the product/delivery requirements. Check uniqueness, preserved compliant public spellings, version-free names, checksum entries and advertised latest URLs. Cover raw artifacts: `tetris-v0.5.0.html` fails where `tetris.html` is required. Numeric product identities are not automatically release versions; do not use a blanket ban on digits or a universal suffix vocabulary.
2. Under an authorized release or repair request, route failures to the owning implementation/maintenance workflow. Correct packaging/build/release scripts and related producers/consumers, configuration, tests, checksum generation, installation/release documentation and download links. Fully repair every conflicting active project naming policy, template, example, configuration and governing/build/release document, including explicit project-defined or previously accepted rules. Inspect the current tracked code/config/docs/templates/examples, including hidden workflow/config directories such as .github; a top-level visible-file listing is not coverage. Historical usage does not authorize bad names in a new release. Update dependent code, checksum/download references and installation guidance; do not preserve prohibited aliases for old consumers. Preserve unrelated constraints and frozen historical records; accurate tag-specific historical references are not naming instructions for the new release. Do not merely rename one temporary upload, weaken the gate or report an otherwise routine repair and stop. Read-only or explicit path/effect limits remain controlling; obtain only a genuinely missing decision/authority.
3. Add or reuse a deterministic project-local naming/inventory check in the project's existing stack, using the [executed check contract and optional Python helper](../../sdd-verify/scripts/release-assets.md) where suitable. Its expectation must come from the naming contract, not unchecked generator output. Require the project's actual checker to execute the shared version-notation contract vectors, including historical values and single-component vN names with a matching faulty expected list. Checking only the current version or only dotted versions is insufficient. Observe the offending example fail and corrected artifacts pass; check real variant collisions and checksum filename/byte agreement as applicable. Run it before tag creation/push and publishing dispatch, for local/direct publication, and in CI before upload and final publication. A tag-trigger-only builder must expose a build-only path that produces and checks the exact candidate before tagging; an absent local artifact is not permission to skip the gate. A successful build, test count or matching generated manifest is insufficient.
4. Commit/publish/read back the repaired scripts, related code/tests/docs and required source/version changes through **sdd-manage**, completing eligible integration before release. Refresh source-associated notes and the release-commit/tag evidence; rebuild from that exact verified committed source, regenerate checksums and rerun package/naming checks. Never attach rebuilt content from a changed source to an old tag or reuse stale passing evidence. Existing tags/published releases use the [release recovery](github-releases.md#recover-without-duplicate-writes) boundary, including a corrective version/release when required; no tag move, silent asset deletion/clobber or history rewrite.
5. Pass the source, stable expected names, exact-byte hashes and observed check results to the selected publisher. Recheck the complete draft before publication and the actual hosted/latest filenames, checksum contents and stable URLs afterward. A naming failure blocks the corresponding release transition/completion and returns to repair. Continue an already-authorized release through verified publication/readback after repair; package-only, build-only, draft-only and local-only requests retain their actual stops. Do not manufacture a second publisher or another permission checkpoint.

## Prepare and hand off the workflow

Use [release workflow preparation](github-release-workflows.md) to create/extend the appropriate workflow and its build/verification procedure. Return accepted package layout, source/version, asset names and required set, checksums, performed checks, remaining questions and changed files. Stop at the requested preparation boundary. A request to actually release continues through [release creation](github-releases.md); do not publish merely because a candidate archive exists.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/references/release-checks.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-assets.md
```

```text
# Package, workflow and release checks

Load for selected release/package acceptance. Use the requested boundary and the accepted [package contract](../../sdd-forge/references/github-packaging.md), not a guessed universal inventory. Verification assesses actual outputs and returns evidence; the coordinated work owner repairs files or performs publication. Local checks do not themselves authorize a live release.

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** The [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) is a mandatory pre-tag/prepublication check and hosted completion recheck. Derive accepted stable names independently of build output or an upload manifest; a complete/checksummed but version-named set fails. Return specific failing producer/consumer/doc locations to the owning workflow for authorized repair, source publication, rebuild and recheck; verification does not itself edit or publish. Retain passing/blocked evidence for the exact candidate and actual hosted state.

Apply [cross-platform verification scope](check-selection.md#cross-platform-artifacts-and-native-verification) to target artifacts. Unavailable native execution does not prevent an authorized release when the requested artifacts and in-scope checks are complete. Identify cross-built/inspected packages and native tests not run in release evidence and installation instructions; do not claim native-tested compatibility. A missing artifact or failed feasible required check remains distinct.

| Claim | Evidence to obtain |
| --- | --- |
| Git highlights range | Pin target and release line/channel, qualifying tag policy, peeled baseline and ancestry; check complete history/tag discovery, pending-tag exclusion, and complete range identity/parent inventory, latest adequate cumulative campaign summaries, other integration messages including reachable nested merges, and targeted gap messages/diffs. Verify earlier same-campaign bodies are fallback rather than required reconstruction, and original opening pointers stay unchanged across amendments. Verify direct-change/revert coverage, amendment/enclosing-child deduplication and evidence limits; phase/preparation versus implemented-delivery claims remain distinct and refs/tips are discovery only, including phase and plugin-convention `design-docs/*` document-preparation refs. Verify explicit null baseline only for complete initial history. Use [shared Git highlights](../../sdd-forge/references/release-highlights.md). |
| Incremental draft | Confirm ignored/untracked ownership, parseable YAML/full identities, unchanged tag target and baseline → analyzed → target ancestry. Exercise no-op, pending-only update, reverts/cuts, malformed/moved/diverged state and interrupted saves without false watermark advancement. |
| Complete message | Check explicit complete-message routing versus highlights-only/editing-only scope, established template or applicable optional sections, preserved human material, supported factual claims, output ownership/path, body-only Markdown and atomic replacement/no-op behavior. Check separate preparation/final paths: release documents may be committed inside the active revision directory and moved to their final destinations in the release commit. Root `RELEASE-NOTES.md` is the default final path. Verify tracked/untracked ownership, preserved human content and campaign evidence, exact bytes and final-source/ancillary refresh; failure preserves the previous copy. |
| Release commit/tag agreement | Verify current notes provenance/coverage and stated version; matching version alone is insufficient. Resolve the actual default branch and designated development role. Verify a direct default-branch release commit or the merge into default from that development branch; the merge itself is tagged, without another marker. Confirm first-parent placement on the published remote default branch, exact release-commit/notes/GitHub body equality and peeled tag/package/publisher SHA agreement. Reject revision-side commits, ordinary side-history ancestry and wrong merge direction. Recovery retains an eligible pinned commit if default advances; existing-source-only requests do not waive eligibility. No preparation-only marker. |
| Final notes/cleanup | Confirm exact final source coverage, complete UTF-8 body/hash/source transfer to one publisher and actual body readback. Retain the complete-message file after every outcome. Keep internal checkpoints on preparation/draft-only/failure/uncertain or missing readback; delete only an owned internal highlights checkpoint after published-body confirmation unless retention was selected. |
| Package layout/content | Inspect actual member names, duplicates, path/link safety, corruption and declared size limits; compare required members, intentional exclusions, entry points, applicable notices, versions and modes. Explain generated members through the build procedure. |
| Build/source identity | Resolve the exact source SHA/tag, runtime/dependencies and version source; run the declared build from that state into an owned output directory. Compare the candidate with supplied reference contents where relevant. |
| Usable package | Exercise installation/import/startup or another declared consumer check in a suitable controlled environment, without executing untrusted supplied archive scripts. Report unsupported platform coverage. |
| Reproducibility | Repeat under equivalent declared inputs and compare bytes/hashes when this claim is required. Matching inventories alone establish layout, not reproducibility. |
| Stable variants/checksums | Compare actual local/draft/hosted filenames with the independent stable version-free naming contract, for every artifact, including unfamiliar types and names without extensions; no type/extension may be skipped. Include every promised variant, only necessary conventional suffixes, no collisions, and matching checksum filenames/exact-byte SHA-256. Exercise the project-local gate with the known bad name before repair and corrected names after rebuild; inspect its direct/CI prepublication wiring. An expected list copied from a faulty generator is not acceptance. |
| Workflow validity | Check YAML plus available Actions validation, trigger/input/permission semantics, checkout identity, build-only effects, matrix collection, one publisher, concurrency and recovery. Parsing is not CI execution. |
| CI success | Identify actual run/ref/source, relevant job conclusions and expected built artifacts. Accepted dispatch, queued state or a success in an unrelated job is insufficient. |
| Hosted release | Read release/tag identity and source, state, complete asset names/sizes/digests, actual latest pointer and URLs. Follow the [release readback](../../sdd-forge/references/github-releases.md#read-back-and-report) procedure. |
| Download integrity | Download exact assets through supported access; compare bytes/hashes with the built files and checksum set. Report metadata-only coverage separately. |

Select positive and relevant failure/recovery checks proportionate to the changes: missing/extra members, unsafe ZIP entries, variant name collisions, absent latest assets, wrong source/version, missing permission, failed matrix build, partial draft upload, uncertain publication and published/immutable conflicts. For highlights use disposable real Git/file fixtures for deterministic identity/parent/merge-message collection and targeted fallback mechanics, plus source/consumer assessment for editorial coverage, consolidation and deduplication. Separate recipe execution from an agent following the workflow: successful fixture scripts do not prove semantic curation, fresh-consumer acceptance or live publisher transfer/cleanup. Use disposable local fixtures or provider mocks where appropriate; mock lifecycle success is not live GitHub acceptance.

Before a hosted check, identify its authorized repository, operation and effects. Do not create a release, dispatch publication or modify immutable/settings policy merely to test instructions. If live CI, installation or download checks are unavailable, return their limits rather than fabricate coverage or declare them passed. Record tested state, actual commands/results and remaining work under [execution and evidence](execution-and-evidence.md).

Use the project's executed check or the [read-only Python naming helper](../scripts/release-assets.md) for the complete candidate/provider inventory; its existence or a partial-draft result is not a complete pass.
# Executed artifact-name gate

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Every artifact in the complete inventory is checked, including unknown extensions and names without extensions. Follow the canonical [package contract and repair loop](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair).

Use the project's deterministic executable check in its existing stack. When Python 3.11+ is available, this bundled read-only standard-library helper can supply the naming/inventory check; it is not a universal extra runtime prerequisite. Prefer calling or reusing this tested implementation when it fits the existing runtime. An equivalent project check must execute the public contract vectors against its own actual gate, not merely run the bundled helper's self-test. A current-version substring check or a dotted-version-only regex is not equivalent. Executing a check is mandatory even when this particular helper is not selected.

## Inputs and invocation

Establish the stable name contract independently from product/delivery requirements before generating build/release scripts. Retain it in existing project package/build documentation or configuration. Review every expected name for version content; never bless a generator's output by copying it into the contract. Pattern matching alone cannot establish a semantic naming contract.

For the helper, supply a JSON array of the independently reviewed expected names and a dedicated flat staging directory containing every actual release artifact. Do not filter entries by extension or omit an unrecognized type. Directories, links and special entries fail rather than hide unexamined contents; package directory artifacts into their specified release form before this check.

```text
python PATH/skills/sdd-verify/scripts/release_assets.py --expected EXPECTED.json --directory STAGING --version 1.2.3
```

For an actual provider inventory, collect every asset name with complete pagination/readback and supply its JSON array:

```text
python PATH/skills/sdd-verify/scripts/release_assets.py --expected EXPECTED.json --observed ACTUAL.json --version 1.2.3
```

Exit 0 requires every observed name to satisfy the prohibition, exact contract membership/completeness and uniqueness, including case collisions. The expected names are checked too: a matching faulty upload manifest cannot authorize a prohibited name. Common version notations and selected-version forms are rejected; ordinary product/architecture digits are not categorically banned. Exit 1 returns a JSON diagnostic. No network request, file write, source repair or publication occurs.

## Transitions and evidence

Require an observed failure for the offending artifact before correction and a passing full-inventory check after the producer/code/docs repair and committed-source rebuild. Capture the exact source, contract/inventory, command, exit status and outcome in existing release evidence. Recheck an actual complete draft before publication and hosted/latest names afterward. Reuse the project's existing checksum/content/source checks; this helper does not establish those properties.

The importable check_names function supports incomplete draft inspection only with complete=False. Such a result is not complete release acceptance. Before tag creation/push, publishing dispatch, upload and publication, the corresponding complete candidate/inventory must pass. A tag-trigger-only builder needs a nonpublishing candidate-build path before tagging. Do not replace an executed gate with an agent promise or the existence of a checker file.

## Required project-gate conformance

The prohibition covers any version number, including historical and single-component notation; it is not limited to the current release value. The [public contract vectors](release-asset-cases.json) include marked single numbers, dotted and separated components, prior values, Unicode normalization, unfamiliar suffixes and no extension, as well as legitimate product/architecture digits. These examples test notation, not permitted artifact types; every actual artifact remains covered.

Execute those vectors through the project's actual gate before accepting an implementation or generated workflow. Invalid names must still fail when the expected list is changed to match them. In Python, `verify_checker(adapter)` exercises an adapter with signature `(expected_names, observed_names, release_version)` that invokes the actual project gate and raises ValueError for rejection. Other stacks use the same data with their own harness. Retain the real command and exit/output evidence. Passing tests against a different checker does not certify the publisher's gate.

The bundled implementation can self-check with `python PATH/skills/sdd-verify/scripts/release_assets.py --self-test`. That self-test alone is sufficient only when the project's executed path actually delegates to that same validated implementation; project inventory/checksum/content and publication-order checks remain required.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-message.md
```

```text
# Prepare a complete release message

## Entry and routing

Load for requests to prepare, draft, assemble or update a release message or release notes. These requests select complete-message preparation. **sdd-manage** establishes repository context, output ownership and the stopping boundary; **sdd-forge** supplies validated [Git release highlights](release-highlights.md); **sdd-report** assembles the complete Markdown through [release reporting](../../sdd-report/references/releases.md#complete-release-message). Local preparation needs an eligible Git worktree, not a provider, token, tracking activation or TASKS.

A narrower request to collect release highlights selects only the shared highlights workflow. An explicit request to edit supplied text without collecting project changes stays within that editorial scope. Seed text for a complete release message supplies material and preferences; it does not establish complete Git coverage or authorize publication.

## Establish inputs

1. Pin the exact target and previous release baseline using the shared highlights rules. Exclude a pending release tag from baseline discovery; retain a valid prior baseline on retry. With complete initial history and no qualifying tag, use the established null baseline. Resolve a consequential unknown release line or target before dependent collection; do not create a version/tag by implication.
2. Discover the project template, requested version/channel, package/install documentation, verified assets and relevant compatibility/known-issue evidence. Use supplied accepted sections and current authoritative sources. Unknown facts remain unknown; omit unsupported claims rather than inventing URLs, contributors, checks or release status. A preparation draft may identify intended assets as intended, not available downloads.
3. Establish preparation and final destinations and their ownership before writes. The default final location is `<project-root>/RELEASE-NOTES.md`; honor an explicit path or project template. Within an active revision campaign, release documents may instead be prepared and committed under that campaign's directory, recording their intended final paths. No new campaign is implied by ordinary preparation. Read existing staging and final files, retaining applicable accepted human sections, edits and cuts while correcting stale facts. Existing content alone is not proof of workflow ownership. Resolve unreadable/foreign destinations or symlinks before replacement; never follow a link to overwrite external content.

## Assemble and persist

Collect or refresh the internal highlights checkpoint through the pinned target before editorial assembly. Reuse valid incremental coverage; an unchanged target does not require replaying history. Do not advance its watermark past incomplete analysis. If the internal checkpoint was consumed/deleted after a prior publication, establish fresh coverage using the shared baseline rules; the retained final message has no coverage metadata and cannot substitute for that checkpoint.

Ask **sdd-report** to assemble the complete message from the curated changes and ancillary verified inputs. Return body-only Markdown, without YAML metadata, raw logs or internal campaign transcripts. Use a project's template or the adaptable structure in release reporting; omit empty sections and repeated highlights. A GitHub release title is a separate field and need not be duplicated in the body.

Default new generated output outside tracked campaign preparation is ignored/untracked. **sdd-manage** adds a narrowly scoped ignore rule for that generated destination using existing Git persistence rules, preserving current ignore content and foreign work. Campaign-staged release documents may be tracked and committed on the revision branch; do not ignore those selected tracked sources. A tracked destination remains tracked; update and persist it only within authorized repository scope, without silently untracking it. Complete required persistence/publication of owned ignore or tracked-note changes before further work.

Validate the entire candidate, applicable human-content preservation and current source association before replacement. Save atomically using a temporary sibling and filesystem replacement; failed collection, editing, validation or writing retains the prior complete file. Recheck ownership/current contents before replacement; do not clobber intervening edits. Remove only workflow-owned temporary files. Replace the selected file rather than append another message. If both target and applicable ancillary facts/body are unchanged, retain the existing bytes without a needless rewrite; changed verified ancillary facts may require an update even at the same Git target.

Return the preparation path, intended final path, final body, exact target/baseline, coverage checkpoint and evidence limits. Preparation stops here: no relocation into the default branch, release commit, tag, release, asset upload, workflow dispatch or version bump is implied.

## Retention and publication handoff

Keep the complete-message file after preparation and publication, including draft-only, failed, uncertain or successful outcomes. For campaign staging, retain it there until the release commit moves the owned document to its established final location; this planned move is not highlights-draft cleanup. The finalized file remains available after publication. The next authorized preparation refreshes/replaces the applicable file; explicit retention/path policy controls. Campaign plans, reports and evidence retain their campaign paths.

The internal `.release-highlights.md` retains its separate [verified-consumption cleanup](release-highlights.md#consume-and-retain-or-clean-up). Preserve applicable human curation from the retained message even when fresh internal coverage must be established. Other destinations follow the same distinction between final message and internal checkpoint.

Before an authorized publication, refresh Git coverage and ancillary sections through the exact final release source. Review both sides and the prospective result of a development merge before finalizing the release message: changes newly arriving from default must not escape coverage. Any commit caused by tracked notes or ignore-rule persistence advances that source; perform the required incremental refresh and inspect whether it changes user-visible facts. A pure document move adds no product highlight. Do not manufacture another tracked edit for an unchanged body. A retained message may belong to an earlier source and is not automatically valid for the next release.

Pass the complete message's exact UTF-8 Markdown bytes, source association and body hash to the selected publisher through its supported notes-file/API/structured handoff. An ignored file is absent from CI checkout; transfer the body explicitly, not merely its local pathname or a tag. Preserve accepted human sections and avoid inserting highlights twice. Read back the actual published body before claiming consumption; uncertain writes require reconciliation. Successful readback may permit cleanup of the owned internal checkpoint, while the complete-message file remains.

## Release-request freshness and commit gate

A release request loads this workflow even when `RELEASE-NOTES.md` already exists. Use available local preparation context to establish its target/baseline, version/channel, body hash and completed coverage. Check any version stated in the message against the intended release and project version authority. Version agreement is a corroborating check, never proof of current coverage. If provenance is absent, stale, contradicted or the target advanced, reconstruct/refresh the required coverage and ancillary facts before consuming the file. Preserve applicable human material; do not publish an old message merely because its filename or version looks correct. Final release notes identify the established release version/tag in their overview or project-template location; preparation without an established version does not invent one.

**sdd-manage** coordinates the [default-branch release commit and tag](../../sdd-manage/references/git-workflows.md#release-commit-and-tag), and **sdd-report** formats its [commit message](../../sdd-report/references/object-drafts.md#release-commit-message). Use either a direct default-branch commit or the merge into default from the designated primary development branch; that merge itself is the release commit. Its body uses the same finalized Markdown as the GitHub release body. Include owned verified release/version changes and necessary moves from campaign staging to final destinations, preserving unrelated and foreign content. Only a direct release with no file changes may need an empty marker. Preparation-only creates no release commit. Reuse an existing commit only when its default-branch provenance and all release contracts qualify; an existing-source-only request cannot waive those checks.

After the release commit, inspect its actual source and refresh/check notes coverage through it before tag publication. A marker that only records the already assessed release outcome adds no new product highlight. Confirm the commit body still equals the final complete message. If newly discovered user-visible changes require a different body, correct the pending boundary before tagging; preserve published history and never move an existing tag to hide the discrepancy. Tag the verified release commit and use that exact SHA/body/hash for the single publisher. Commit/tag publication is a Git boundary; GitHub release completion still requires its own successful readback.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/coordination.md
```

```text
# Coordination protocol

## Establish scope and prerequisites

- **Request:** Capture the objective, inspection or mutation mode, target paths or documents, owning task list, selected boundary and allowed external effects. Carry the selected core workflow/variant or standalone operation, decision basis and continuation/stage-change/switch disposition under [workflow selection and continuity](workflows.md#workflow-selection-and-continuity). Reuse session authorization and decisions.
- **Orientation:** Reuse a sufficient current **sdd-orient** handoff; obtain scoped observations where relevant evidence is missing or stale. Establish the repository, applicable instructions, baseline, pending changes, tooling and task evidence before selecting/reporting the path. Do not mistake an unchecked task or latest maintenance commit for a proven execution boundary.
- **Git:** Require an eligible worktree for repository mutations. Outside Git, continue discussion or inspection and report the mutation blocker; do not initialize a repository implicitly.
- **Pending work:** Establish ownership of dirty paths. Preserve unrelated staged and unstaged changes. Do not reset because the tree is dirty. Pass interrupted task implementation to **sdd-implement**, document incorporation to **sdd-integrate-feature**, and commanded amendment continuation to **sdd-steer**; if it lies outside the requested new scope, resolve that conflict before overlapping mutations.
- **Inputs:** Confirm the authoritative requirements, design, strategy, and layout needed by the selected stage. File presence alone does not establish acceptance or consistency.
- **Document readiness:** Use [document QC gates](document-qc-gates.md) before dependent PLAN/TASKS generation, implementation or hosted projection. Compare actual reviewed/governing state and coverage; route missing focused review within scope instead of trusting file presence or a Ready label.
- **Preparation baseline:** Project preparation documents and their QC reports are committed/pushed on design-docs. Complete [preparation integration](branch-management.md#preparation-integration-gate) into the actual default branch before creating a dependent implementation branch. Campaign plans/reports remain on the campaign revision branch. Carry actual preparation tip, default merge/publication and implementation starting checkpoint through the handoff.
- **Tracking execution gate:** Before dispatching phase task execution, load [tracking decision](tracking-decision.md) and [phase activation](phase-activation.md). Carry explicit requested/confirmed scope separately from observed projection. Required objects/associations must be verified before task edits/tests; otherwise hand off a blocker, not executable readiness. Preserve local preparation/human acceptance boundaries and use existing handoff evidence, not a new registry.
- **Proactive handoff:** At entry, preparation handoff, phase activation and completion, identify relevant capabilities, prerequisites, unresolved user choices and coordination gaps. Record the concrete next owner/action, workflow decision and basis, observed state, pending human checkpoint and stopping boundary in the existing handoff. Give the canonical selection brief in user-visible chat; an internal handoff alone does not satisfy it. Use [tracking decision](tracking-decision.md) for optional hosting; ask only when the missing decision affects the next dependent work. Do not create an unrelated administrative task chain.
- **Facilities:** Check availability of the selected skills and necessary tools on the actual execution host under applicable user/repository instructions; reuse current unchanged host/tool evidence. Report concrete missing capabilities. Use ordinary filesystem, Git, and available provider tools; require no particular client, hidden hooks, or implicit installation mechanism.
- **Historical scope:** Use current authorities and the active campaign. Discover prior identities/paths without loading old contents; consult selected history only for a specific current question. Keep [closed records](../../sdd-conventions/references/review-campaigns.md#closed-campaign-records) unchanged and outside current compatibility checks. Inspect proposed paths before staging/integration for incidental edits to closed packages.

For branch workflows, use [branch management](branch-management.md) for setup and [Git workflows](git-workflows.md) for final integration. Preserve implementation's push-first prerequisite; a direct focused invocation uses the same protocol.

## Scope checks and reporting detail

Before each coherent work unit, check the active objective, authorized outputs/effects, applicable instructions and pending human decisions against current evidence. Reuse sufficient context; refresh missing or materially changed evidence rather than repeating orientation for every command. Before creating or editing any user file, verify both the target path and the proposed change belong to the authorized scope. Withhold out-of-scope changes and report a consequential conflict; an allowed path does not authorize unrelated changes within it. These checks require neither narrated reasoning nor new permission for routine authorized work.

At workflow entry, uncertain-context recovery or a material operation/stage/scope change, give a concise chat brief identifying the workflow or operation, current stage/owner, authorized work/outputs and next human checkpoint or stop. Explain consequential selection with its request/project evidence under [workflow selection](workflows.md#workflow-selection-and-continuity). During unchanged work, report new results, decisions or blockers; repeat only scope information needed to understand a change. Routine questions can receive direct answers.

Honor the human's requested reporting detail, including later adjustments. Reduced detail may compress briefs and omit unchanged context, routine explanations and unrequested exhaustive source inventories. Continue to report consequential decisions, scope changes, blockers, verification results and required human checkpoints; fulfill explicit requests for sources or explanation. Reporting detail changes neither authorization nor approval, verification, publication, tracking or stopping requirements. Do not choose detail from presumed model strength or create a separate verbosity-state artifact.

At a human checkpoint, present substantive review results, the dependent work held and what acceptance would clear, following [human document review](human-document-review.md). During clarification, restate the pending boundary when omitting it could imply acceptance or advancement; do not repeat an unchanged full brief on every response.

### Reporting profiles

Use **Standard** for established work unless the human selects another profile or gives a more specific reporting preference. Composite-workflow bootstrap uses the temporary Explicit reporting below. Profiles control presentation; all retain the scope checks, reporting triggers, consequential information and workflow obligations above.

| Profile | Reporting detail |
| --- | --- |
| **Minimal** | Compress entry/scope-change briefs, results, blockers and required human decisions. Omit routine narration, unchanged context and unrequested explanations. |
| **Standard** | Give concise briefs at entry/material changes, useful progress updates and rationale for consequential decisions. |
| **Explicit** | Clearly identify workflow/operation, stage/owner, authorized outputs and next checkpoint at entry/material changes. Give fuller consequential decision rationale, relevant sources and verification evidence without repeating unchanged information on every response. |

Accept ordinary requests such as “Use SDD Manager with minimal reporting,” “Switch to explicit reporting” and “Return to standard reporting.” Retain the selected profile in available conversation/workflow context until changed and carry it through existing handoffs. Do not create a settings file or infer a profile from model strength. If no preference is recoverable, use Standard; do not pretend a lost selection was restored.

A specific request controls its affected output: “Explain this decision fully, then resume minimal reporting” supplies a one-response override and returns to Minimal afterward. A request for an explanation or sources alone does not switch the ongoing profile. Required human checkpoints remain substantive under Minimal; Explicit adds detail rather than approval gates or repeated preambles.

### Composite-workflow bootstrap reporting

Use **Explicit** reporting while establishing a composite workflow at initial entry, a material workflow switch, or recovery that must reconstruct its context. This is workflow-context bootstrap, distinct from repository disclosure/file setup. Routine continuation, task handoffs and minor evidence refresh do not restart it. Honor more specific human limits on bootstrap reporting within their stated scope.

1. Proactively announce the active bootstrap level and briefly explain the choices: **Minimal** reports essentials; **Standard** adds useful progress and consequential rationale; **Explicit** adds fuller scope, sources and evidence. Mention that “Switch to minimal/standard/explicit reporting” changes subsequent detail. Give this explanation once during each applicable bootstrap, not on every response.
2. Establish and report the workflow, stage/owner, authorized work, next checkpoint and consequential evidence or uncertainty under the selection/scope protocols. Explicit reporting is not exposed reasoning or permission to guess missing approvals, task ranges or project readiness. Blocked recovery reports its known state and missing decision without beginning dependent work.
3. Before the dependent handoff/work, announce the subsequent level: **Standard** by default, or the human's established selected profile. The temporary bootstrap level does not replace that selection. If a preference was lost and cannot be recovered, identify the Standard fallback rather than claim restoration. Carry the subsequent level through existing handoffs; no new confirmation or reporting-state file is required.

## Coordinate execution

1. Give each responsible skill the objective, scope, authoritative inputs, decisions, relevant task IDs, branch/HEAD, dirty-path ownership, permitted effects, required evidence, stopping point and selected reporting profile or more specific preference. Carry the actual human grant, destination/ref, payload scope and explicit limits through handoffs; do not ask each worker to obtain the same approval again. Keep credentials out of ordinary handoff text.
2. Let the skill perform its owned procedure. Collect its changed paths, observed evidence, findings, and remaining differences before the next dependent stage.
3. Refresh the material baseline when HEAD, instructions, project, target scope, or relevant pending changes change. Do not repeatedly run orientation or checks when the current evidence remains applicable.
4. Resolve missing human decisions and out-of-scope requirements without guessing or silently expanding work. Continue independent authorized work where possible. Once a commit awaits publication, the per-commit rule takes precedence: finish its inspection/publication/recovery without advancing independent work or making another commit. State the blocked operation and decision needed.
5. Return verification failures to the active workflow's coordinator or authorized artifact owner for repair and recheck. Preparation corrections follow [document QC gates](document-qc-gates.md); implementation repairs remain with **sdd-implement** or **sdd-steer**.
    - **Invalid implementation completion:** apply [task recovery](../../sdd-implement/references/completion-and-checkpoints.md#resolve-a-task-recovery) using existing authority. Distinguish acceptance repair from historical composition exceptions; retain the authorized range and publication scope.
    - **Standalone verification:** return findings without starting repair.
    - **sdd-docs governing amendment:** follow its [referral to the user](../../sdd-docs/references/review-and-findings.md#governing-document-amendments). Preparation correction authority does not bypass that decision.
6. Stop at the requested boundary. A checkpoint is not permission to select another milestone, start steering, incorporate unselected feature documents, or create hosted objects. Complete explicit integration/publication when its workflow gate is met; incomplete main phases push and pause even when the requested task subset is complete. A human-commanded steering amendment always returns control without resuming implementation.

## Persist repository changes

Use this procedure for document preparation, accepted integration, and standalone maintenance. Do not duplicate the commit workflows owned by **sdd-implement** or **sdd-steer**.

- **Policy:** Honor the user's commit and push instructions and repository policy, including standing session instructions. Apply [per-commit publication](git-workflows.md#publish-each-commit): push and verify each workflow-owned commit before advancing work or making another commit. Only an explicit user-directed local-only/deferred-publication instruction changes this cadence within its scope. Do not invent a remote branch or force-push.
- **Verification:** Inspect the actual diff and run checks appropriate to its effects: document consistency and links for authoring, relevant tests for test changes, or **sdd-verify** for acceptance campaigns. Verify heading spacing and project conventions. Do not manufacture task completion for document-only work.
- **Bootstrap:** Fresh/resumed main preparation first follows [main preparation](main-preparation.md): enabled hosted projection before writes, separate DOCS-001 four-file initialization, and README links at PROJECT. For other adoption, before the first SDD commit, apply [repository bootstrap](repository-bootstrap.md): package-derived root disclosure and usage notice plus README links travel with the first owned result. Reuse existing valid records; respect explicit path limits.
- **Staging:** Stage only owned changes; inspect the staged diff and exclude unrelated pre-existing staged paths from the commit. Preserve their index state. A normal commit includes all staged content; use a path-scoped commit only for wholly owned file contents, or isolate selected changes in a temporary index. Stop if ownership cannot be separated safely. Avoid broad staging or destructive cleanup.
- **Commit:** Use **sdd-report** to compose an evidence-backed message. Include stable task IDs and verified issue references when the change belongs to those tasks; main preparation uses its predefined DOCS IDs and atomic first-approval completion; other preparation without assigned tasks does not invent IDs. Inspect commit contents and remaining staged and unstaged diffs; after a temporary-index commit, reconcile stale committed owned index entries while preserving unrelated staged content.
- **Push:** Use the canonical supervised HTTPS publication entry from the first attempt under the [bounded Git-operation lifecycle](git-workflows.md#monitor-pending-git-operations) from the initial attempt through verified remote readback. Diagnose a suspected stall automatically; an observed blocked helper can enter [shell recovery](credentials.md#blocked-or-interactive-credential-helper) without a completed credential error. Reconcile the pending attempt/effects before retrying the same authorized push. Report a committed-but-unpushed result if access, destination, divergence or unresolved process/remote state blocks persistence; retain local work and pause advancement/further commits. Resolve divergence without discarding changes or force-pushing.
- **State:** Distinguish committed, pushed, and hosted status. A successful local commit does not establish remote persistence or issue closure.

## Return results

Use **sdd-report** for the result format. Include the fulfilled objective and affected artifacts or task IDs, observed verification and gaps, commits and push status when applicable, hosted changes or pending reconciliation, unresolved decisions, and the boundary reached. Keep planned work distinct from implemented functionality. Follow [continuity](continuity.md) for the durable HANDOFF checkpoint and reconstruction from subsequent documents, decisions and Git. Conversation-only decisions cannot supply cross-agent recovery. Require no additional transaction journal, recovery directory, issue map or new skill.

## Diagnostic and findings handoff

Return instruction source, actual user choice/grant, observed state and evidence limits separately when explaining omissions. Persist explicit amendment notes under the authorized [review/revision findings procedure](review-and-revision.md#retain-requested-amendment-findings), reporting conversation-only, written, committed, pushed and implemented states truthfully.

## Coordinate environment recovery

On a relevant environment/tooling blocker, coordinate investigation of reasonable supported alternatives within authorized scope before declaring the work blocked. Route technical investigation to the affected execution workflow; implementation uses [environment recovery](../../sdd-implement/references/environment-recovery.md). Preserve partial work, require actual attempt/capability evidence, disclose material substitutions and resolve consequential scope/requirement decisions. Bound investigation by real constraints rather than an arbitrary retry quota. For a host denial, retain the pending operation and report the observed reason; do not reframe it as a tooling failure or switch tools to evade it.

## Human document handoffs

Apply [human document review](human-document-review.md) at entry and each newly created root/proposal. Pass actual presented scope/state, human decision or pending review, technical readiness and authorized next action separately. A multi-stage request still pauses after each necessary new document unless explicitly covered by applicable future-checkpoint preapproval; routine operation authority carries through its persistence. Reuse acceptable existing main/feature inputs without interactive replay, prioritize requested interactive review and offer it for important startup concerns without assuming selection.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/git-workflows.md
```

```text
# Working branches and explicit integration

Use this protocol for a bounded implementation range, feature campaign, steering amendment, project preparation baseline, or selected document integration. **sdd-manage** establishes and coordinates the Git lifecycle; the active owner performs its scoped work and persistence. A direct invocation of a focused skill follows this same protocol. Read-only requests do not create branches or merge.

## Publish each commit

After **each workflow-owned commit**, push it to the established remote branch and verify remote containment before advancing project work or creating another commit. Do not accumulate local commits for later publication, including in an agent's temporary sandbox. This rule applies to preparation, reviews/revisions, maintenance, implementation, steering, feature incorporation, report-only commits and merge commits, including direct focused calls. The commit owner publishes; a coordinator/reviewer handoff must finish publication before the next work unit, whether independent or dependent.

Own the [bounded operation lifecycle](#monitor-pending-git-operations) through the canonical supervised HTTPS push/readback entry from the first attempt and any credential recovery. A pending command is not completed publication; start diagnosis on an observed stall without waiting for a human prompt or a completed authentication error.

Resolve eligible outstanding workflow commits before new commit-producing work. If publication fails, is uncertain or lacks an established destination, preserve the commit, reconcile the remote/recover access where supported, and report the pending operation. Pause workflow advancement and further commits until publication is verified. Commit inspection, push/readback and scoped recovery remain allowed to finish that operation. Do not switch branches, tools or workflows to accumulate unpublished work or evade a blocker.

A known-invalid or uncertain retained implementation task completion must pass the implementation owner's [publication preflight](../../sdd-implement/references/startup-and-continuation.md#push-before-task-work) before pushing. Hold affected publication while resolving that bounded recovery. Under established repair authority, necessary inspection/checks and a task-specific forward correction/evidence commit may precede publication of the retained invalid commit; this is the sole task-recovery exception to the no-further-commits rule, not permission to batch ordinary work. Verify and inspect the coherent current tip and retained historical defect, then push/read back before other work. Ownership conflicts, missing authority or unresolved acceptance still block publication; never rewrite history or publish an unsupported completion merely to satisfy push-first.

An **explicit user instruction** for local-only work or deferred publication overrides this cadence only within its stated scope; report committed-but-unpushed state accurately. This rule does not authorize publication outside the granted scope, bypass host/repository restrictions, guess a destination or permit force-pushing. Per-commit pushes do not require per-commit merges or alter human acceptance and integration gates.

## Monitor pending Git operations

Apply before publication and any network, credential or hook-dependent Git command. The active owner retains responsibility across tool yields and handoffs. A short tool wait or an unchanged poll is not a deadline.

1. **Select the bounded entry before launch.** For supported HTTPS push/readback, use [git-publish.mjs and its CLI contract](../scripts/git-auth-recover.md) from the first attempt. Supply the established repository, named remote, exact effective push URL, full target ref and expected object. It supervises validation/transport/descendants/streams, uses one total deadline, and performs at most one Git push followed by exact readback. With an eligible supplied token it bypasses inherited selectors immediately; without one it supervises existing noninteractive authentication. Follow [credential selection](credentials.md#deterministic-git-publication); no raw initial push followed by an agent-controlled watchdog.
2. **Honor unsupported boundaries.** Clone, fetch, SSH, forge APIs and earlier independently launched commands are outside this interface. Before such a command, select a supported finite runner deadline, process ownership, cancellation and disposition facility. Preserve its purpose/session identity and remote effects. If none exists, report the concrete blocker before launch. Do not claim this publication utility supervised a different command or change transports/destinations by assumption.
3. **Interpret process and remote state separately.** Inspect the final safe result, independent push/readback summaries, cleanup_state and next_action. Confirmed cleanup and matching exact state may satisfy publication even after a push error; a matching ref alone does not prove an older process stopped or which attempt wrote it. Preserve commits and pending publication on absent/different/unknown state. cleanup_unconfirmed blocks another attempt and workflow advancement until ownership is resolved. The script never force-pushes or loops retries.
4. **Diagnose under existing authority.** A timeout, unavailable interaction or concrete helper failure triggers scoped investigation without waiting for the human to request it. Do not classify silence/timeout as a bad token. Inspect the owning session, executable/version and necessary sanitized helper/context origins. Never print credential-fill output, token contents or unredacted configuration/traces. Generic git_failed is not evidence of provider denial. Reproduce deterministic local helper failures before another evidence-based push; use [credential recovery](credentials.md#blocked-or-interactive-credential-helper) for the affected mechanism.
5. **Settle before replay.** For an earlier separately launched uncertain write, cancel only the owned process/tree through supported controls and confirm disposition before bounded exact-ref readback at the established push URL. Parent exit is insufficient. Do not overlap writes, kill unrelated Git/IDE processes, silently abandon a task, force a different object or renew deadlines through polling. Retain a concrete ownership/facility blocker if disposition cannot be established.
6. **Complete or retain the blocker.** Verify exact remote containment plus the workflow's additional contracts before further work/another commit. Retain selected deadline, sanitized cause, process/remote disposition and recovery result in existing campaign/task evidence. No per-command journal or HANDOFF refresh is required. Ask only for a genuinely missing credential, decision or authority; recover within established scope otherwise. A policy denial remains a policy denial.

## Establish the working branch

Use [branch management](branch-management.md) for identities, targets, convention names, eligible creation/reuse, worktree preservation, and phase transitions. Implementation's push-first prerequisite remains before new setup. Read-only review/selection does not create branches. The integration boundary below depends on workflow scope, not merely the last completed task range.

## Merge purpose

Establish the incoming source, receiving target and purpose before applying the merge procedure:

- **Workflow completion:** merge the completed working branch into its recorded creation parent (or retained explicit exception). Restore the receiving parent's context with the child outcome.
- **Incoming synchronization:** merge an authorized published baseline into the active phase/revision branch, including preparation propagation or reopened-campaign catch-up. The receiver remains the active workflow; preserve its creation parent, identity, unfinished scope, pending decisions and stop in HANDOFF. Record the incorporated baseline without declaring either workflow complete or returning to the receiver's parent.

Inspect the full incoming difference and actual authority for either purpose. Synchronization does not authorize unrelated changes, unfinished phase publication to default or a new execution range. A branch prefix or completed source checkpoint does not select the direction. Both purposes use the verification, explicit two-parent merge and publication steps below.

## Work and prepare the boundary

The completion/exits requirements below govern outward workflow completion. For [incoming synchronization](#merge-purpose), inspect the full accepted incoming difference and verify its effect on the receiver; the receiving phase/range need not finish merely to accept that baseline. Shared ownership, preservation, verification and publication gates still apply.

Project preparation uses the [preparation integration gate](branch-management.md#preparation-integration-gate): commit project documents on design-docs, explicitly merge the accepted boundary into the actual default branch, verify and publish that target, then create the dependent implementation branch. This document-only boundary does not require implementation phase completion. Campaign plans/reports remain on their revision branch; preparation merging does not incorporate feature deltas or complete executable tasks.

An authorized release may also integrate verified release preparation before its revision campaign closes, under the [release boundary](#release-commit-and-tag). That bounded integration does not claim completion of pending release publication or the campaign.

Commit and push completed task or amendment work on the working branch. Do not merge every task commit. A main request stops at its selected task count/milestone/checkpoint, but its phase branch integrates only when the complete phase and exits are verified. Otherwise push completed work and pause without merging. A feature/revision integrates its coherent authorized boundary after applicable incorporation/archive gates; steering integrates its commanded amendment into the paused branch and stops.

Inspect the complete branch difference against the target, including earlier unmerged commits. If it contains unrelated or unfinished work, resolve the branch/scope conflict rather than integrating that work by implication. A narrower continuation on an existing feature branch may require a separate scoped branch; do not cherry-pick a guessed subset silently.

Check that the full proposed campaign delta leaves prior closed review, feature and nested steering records unchanged, using path/object identity without reading their contents. Remove incidental historical edits before integration. Later source/link changes do not justify repairing those artifacts or reporting their compatibility; use the [closed-record boundary](../../sdd-conventions/references/review-campaigns.md#closed-campaign-records).

When TASKS or FEATURE-TASKS implementation governs the proposed boundary, require **sdd-implement**'s bounded [task persistence audit](../../sdd-implement/references/completion-and-checkpoints.md#task-persistence-audit-and-recovery) before integration. Inspect each selected task's actual closing commit and parent diff, exact leading single-ID subject, task-owned result/evidence and initial owning checkbox transition; aggregate subjects, checked final lists and merge summaries do not establish compliant task persistence. Separate authorized partial checkpoints, repairs and parent-only follow-ups. Classify composition, acceptance/evidence and ownership separately under [task recovery](../../sdd-implement/references/completion-and-checkpoints.md#resolve-a-task-recovery). The manager may coordinate a forward acceptance repair under existing authority; a historical bundled/split/malformed closing boundary still blocking integration needs a specific human exception. Neither current passing tests nor a recovery note repairs that history; do not rewrite it automatically. Non-task campaign/preparation work does not acquire fabricated task IDs or task checklists through this gate.

DOCS_TASKS follows [main preparation](main-preparation.md) for initialization, first-approval and final-QC persistence. Require DOCS_PREPARATION control/decision evidence alongside DOCS_TASKS checkoffs in their owning commits and verify those boundaries before documentation integration; do not apply the implementation task audit to DOCS tasks.

Verify working-branch acceptance and applicable exits. Reconcile selected feature documents on that branch before its final verification. Retain source documents still required by active work. Commit and push boundary evidence before integration. A pause or unresolved blocker retains the working branch and does not authorize a partial merge.

## Merge, verify, and publish

1. Refresh the target from its established remote and inspect divergence and worktree state without discarding changes. Resolve non-fast-forward local/remote history through project policy, not force-push. Use a clean integration worktree if unrelated work prevents safe integration. Establish [merge purpose](#merge-purpose), then pin the verified published incoming tip and refreshed receiving target tip.
2. Check whether the incoming tip is already an ancestor of the target. If already integrated, inspect the existing merge/evidence and publication state; do not fabricate another merge or claim a new boundary. If a prior merge is awaiting publication, verify that state and finish its push.
3. For completion, confirm the receiving target is the incoming workflow's recorded creation parent (or retained explicit exception) and recover that parent's suspended stage/stop. For synchronization, confirm the selected baseline/receiving workflow association and retain the receiver's existing parent and unfinished boundary; no completion-parent exception is needed for this direction. Merge the pinned incoming tip into the target with `git merge --no-ff --no-commit <incoming-tip>`. Never substitute a fast-forward, squash, or rebase for the required two-parent boundary. Inspect conflicts and the full prospective result; preserve the merge state when blocked. Reconcile HANDOFF by the selected purpose under [continuity](continuity.md#integrate-and-return), rather than accepting either whole file mechanically. Retain pending human stops and effects requiring confirmation. Do not publish a conflicted or unverified result.
4. Use **sdd-verify** to assess the merged state and relevant target regressions. Resolve conflicts and defects only within the authorized boundary; an out-of-scope consequence needs a decision. Record both parent tips, actual checks, and material conflict resolutions in existing evidence. If changes alter working-branch acceptance, recheck it rather than relying on stale results.
5. For completion, use **sdd-report**’s [campaign integration summary](../../sdd-report/references/object-drafts.md#campaign-integration-summary) to compose the explicit merge message: final title/objective, actual review and delivered scope, merged-state verification/limits and integration provenance. Apply it to every revision mode and feature/steering, completed phase and accepted document-preparation integration; an amendment carries retained campaign outcomes forward and separately reports its new delta, unchanged original campaign-opening commit, original branch-off SHA and reopening checkpoint. For synchronization, identify the incoming baseline, receiving workflow, purpose, actual delta, both parent tips and merged checks; do not present it as campaign completion or change original opening provenance. Do not claim publication/closure before their actual completion. Commit the coherent verified merge result; inspect the commit's two parents, contents, and remaining worktree state. If any result changes after verification, repeat affected checks before completing the merge commit.
6. Push the target merge commit to its established remote branch and verify containment. A task-branch push or local merge alone does not establish published integration. On rejection or outage, retain the merge commit, report pending publication, and reconcile remote changes before retrying; never force-push.
7. After completion, return through the recorded parent worktree/branch; after synchronization, retain/return to the receiving workflow. Verify its actual state, preserving unrelated work; neither merge purpose authorizes additional tasks without actual continuation authority. Report working/target branches, task/amendment commits, merge SHA, verification, publication, and remaining differences. Retain the working branch unless deletion is requested or established project policy covers it. Stop at the selected boundary; steering always returns control without main-task continuation.

Git merge is a local repository operation. Protected target policy may block direct publication; report the needed supported route. Do not create or merge a pull request implicitly: the present **sdd-forge** backend does not implement PR operations.

## Continue a blocked workflow

Recover the working/target identities and starting checkpoint from Git and existing task/change evidence. Inspect actual diffs, unresolved merge entries, committed parents, accepted inputs, and pending checks. A clean tree or checked list alone does not establish completed integration. If the next action or ownership is ambiguous, preserve state and report it.

Continue the same authorized operation when commanded; do not start another task or amendment. For an in-progress merge, finish scoped conflict/verification work before its commit. A verified merge committed but not pushed needs publication, not a second merge. Aborting a merge or reverting published work is a separate explicit recovery decision with unrelated work protected; no automatic rollback or new transaction journal is required.

## Platform authorization rejection

For a host denial, retain the commit, attempted destination/ref and actual reason. Distinguish denial from missing credentials; use available scope/evidence only through a supported resolution, without inventing an approval mechanism or asking for a grant already present. Inspect the remote first if the effect is uncertain. Do not repeat an unchanged denied operation, substitute credentials for a policy restriction, or switch tools/transports/accounts to evade it. Report pending publication accurately and respect the host's requirements.

## Push authentication recovery

Use the canonical supervised HTTPS entry from the first authorized push under the [bounded operation lifecycle](#monitor-pending-git-operations), with deterministic supplied-token/existing-auth selection. An observed blocked/interactive helper can enter [hosting credentials and shell recovery](credentials.md) before an authentication error returns; pass the sanitized operation, environment, diagnostic basis and pending effects. A 403 or explicit credential failure follows that same classification, distinguishing credentials from transport, rate and policy restrictions. Reconcile the original process and uncertain remote state before retrying the same established destination. Keep the commit and report pending publication on an unresolved failure. Authentication recovery does not bypass push-first execution, change the target, or authorize force-pushing. The credential procedure can select its bundled transient script for an exact HTTPS ref; consume its verified readback without inferring token permission, API access or release acceptance.

## Release commit and tag

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before creating or pushing the pending tag, obtain sdd-verify's executed [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) for the exact candidate and complete inventory. Missing/failed evidence blocks tagging and publishing triggers; route persistent producer/checksum/docs repair, source publication and rebuild through the owner before retrying. Do not accept a generator's matching expected list as a pass. Neither earlier releases nor explicit project naming rules exempt the new release; correct conflicting policies/templates/examples before retrying.

For an authorized release request, forge first verifies/refreshes the retained complete message through [release-message preparation](../../sdd-forge/references/release-message.md#release-request-freshness-and-commit-gate). Local source/coverage/body context and the established version govern freshness; a matching version alone is insufficient. Manage owns Git persistence and forge owns provider publication.

**Release tags always target release commits on the repository's actual default branch.** Discover that branch from current repository/remote metadata rather than assuming main, master or a cached local alias. Establish whether development uses that branch directly or a designated primary development branch; a branch name alone does not select its role. Refresh the default branch and preserve unrelated work before preparing the release boundary.

When preparation is on a revision branch, integrate its verified accepted source into the selected primary development branch, or into default for direct development, before the release boundary. Treat this as release-preparation integration, not campaign closure; retain pending publication and final reporting. After the default-branch release operation, synchronize its published baseline back into the still-active campaign when needed, preserving its identity and parent, then record results on that campaign branch. Final campaign closure follows the normal verified integration procedure. Do not move the release tag to the later campaign-finalization commit.

Select one path:

- **Direct default-branch release:** create the release commit on the default branch after the accepted source is integrated there. Include only owned verified release/version changes and any final document placement. An authorized release may use an empty marker when no file change is needed; preparation-only does not.
- **Primary development-branch release:** explicitly merge the verified designated development tip into the refreshed default branch with `--no-ff --no-commit`. Resolve the prospective result, finalize owned release/version documents and verify it before committing. That merge into default is the release commit; do not tag the development tip or add another marker. The ordinary scope, conflict, merged-state verification and publication gates still apply. A revision branch is not a primary development branch by implication.

For either path, use report's [release commit format](../../sdd-report/references/object-drafts.md#release-commit-message): assemble the UTF-8 message bytes without normalization and use `git commit --cleanup=verbatim -F <message-file>`, with the finalized complete Markdown body also destined for GitHub. For the development merge this release message replaces the generic merge-message format; retain required integration provenance and checks in the existing release/campaign evidence. Release documents may have been committed inside a revision directory; move only the owned documents to their established final destinations in this release commit when necessary. Campaign plans/reports remain in their retained directory.

Reuse an existing release commit only after verifying its eligible default-branch placement and the same source/version/message contracts. A source-only request cannot make a side-branch commit eligible; report the conflict before tagging. Preserve historical tags/releases rather than moving them to retrofit this rule.

Immediately after committing, inspect the raw stored message rather than pretty-printed Git output, which may add formatting. Compare the subject and body with the prepared subject and finalized body bytes, including Markdown spaces and exact newline endings. For example, the Git owner can extract them without decoding or normalization:

```python
import subprocess

raw = subprocess.check_output(["git", "cat-file", "commit", "HEAD"])
message = raw.split(b"\n\n", 1)[1]
actual_subject, separator, actual_body = message.partition(b"\n\n")
if (not separator or actual_subject != expected_subject_bytes
        or actual_body != finalized_body_bytes):
    raise SystemExit("Release commit message differs from finalized bytes")
```

Use `expected_subject_bytes` and `finalized_body_bytes` from the owned prepared message and finalized notes, not reconstructed display text. If a hook/client changed them, block publication/tagging and return the mismatch for scoped correction, preserving notes and commit state. Do not rewrite published history or silently normalize accepted Markdown.

Publish/read back the default-branch release commit before creating the pending release tag, then verify final-source coverage, version/body agreement and required release checks. Pin this exact commit for the tag, package and publisher. Verify it on the refreshed remote default branch's first-parent history: ordinary reachability through a merged side branch is insufficient. If default advances after the verified release boundary, retain the pinned eligible commit rather than tagging the newer tip or rewriting history. Publish/read back the tag object and its peeled commit before provider upload/publication. A failed/uncertain branch or tag push stops dependent publication and resumes from readback evidence. Existing completed qualifying releases are inspected/reused, not given duplicate markers. The commit describes the release being published; it cannot claim future provider success.
```

Exit status: 0

## Command

```bash
cat app.py version.json RELEASE-NOTES.md tests/test_app.py tests/test_release.py
```

```text
def greeting():
    return "Hello World"
{"version":"1.2.3"}
Orion 1.2.3 delivers the Hello World baseline in two portable representations.

Both representations now use stable filenames: `orion` and `orion.opaque`. The release includes `SHA256SUMS` covering both exact payloads; the version remains embedded in their content and recorded in the release tag. Consumers using the earlier versioned filename pattern should use these stable names.

Before controlled publication, the release entry checks the complete artifact inventory, embedded content/version, and checksum names and bytes. Local and CI build-only checks reject versioned artifact names, including opaque and extensionless files.

Download both representations and `SHA256SUMS`, then compare each payload's SHA-256 against the corresponding entry. Both files contain `Hello World; embedded version 1.2.3` followed by a newline and require no development server. The Python build and release tools require Python 3.11+ with the standard library.

Publication uses the supplied local controlled provider. This release makes no claim of a real GitHub publication or an executed hosted CI run.
import unittest
from app import greeting
class App(unittest.TestCase):
    def test_message(self):self.assertEqual(greeting(), 'Hello World')
"""Distribution and fail-closed publication contracts."""
import hashlib
import runpy
import shutil
import subprocess
import sys
import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from unittest.mock import patch

from scripts.check_release import validate_release
from scripts.release_assets import check_names, verify_checker

ROOT = Path(__file__).resolve().parents[1]


class Release(unittest.TestCase):
    def test_build_retains_both_stable_representations_and_checksums(self):
        subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True, capture_output=True)
        directory = ROOT / "dist/release"
        self.assertEqual(
            sorted(p.name for p in directory.iterdir()),
            ["SHA256SUMS", "orion", "orion.opaque"],
        )
        for name in ("orion", "orion.opaque"):
            self.assertEqual((directory / name).read_text(), "Hello World; embedded version 1.2.3\n")
        expected = "".join(
            hashlib.sha256((directory / name).read_bytes()).hexdigest() + "  " + name + "\n"
            for name in ("orion", "orion.opaque")
        )
        self.assertEqual((directory / "SHA256SUMS").read_text(), expected)

    def test_publisher_rejects_versioned_inventory_before_provider(self):
        directory = ROOT / "dist/release"

        def build_only(arguments, **kwargs):
            self.assertTrue(str(arguments[1]).endswith("/scripts/build.py"),
                            "Provider reached before artifact acceptance")
            if directory.exists():
                shutil.rmtree(directory)
            directory.mkdir(parents=True)
            (directory / "orion-v7.opaque").write_text("bad candidate")
            return subprocess.CompletedProcess(arguments, 0)

        with patch("subprocess.run", side_effect=build_only), patch.object(
            sys, "argv", ["release.py", "--source", "HEAD", "--tag", "v1.2.3"]
        ):
            with self.assertRaises(SystemExit) as caught:
                runpy.run_path(str(ROOT / "scripts/release.py"), run_name="__main__")
        self.assertEqual(caught.exception.code, 1)


    def test_actual_naming_gate_conforms_even_with_faulty_expectations(self):
        self.assertEqual(verify_checker(check_names)["contract_vectors_checked"], 38)
        for name in ("orion-1.2.3", "orion-1.2.3.opaque", "orion-v7", "orion-0.4.2.opaque"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                check_names([name], [name], "1.2.3")

    def candidate(self, directory):
        content = b"Hello World; embedded version 1.2.3\n"
        for name in ("orion", "orion.opaque"):
            (directory / name).write_bytes(content)
        (directory / "SHA256SUMS").write_text(
            "".join(hashlib.sha256(content).hexdigest() + "  " + name + "\n"
                    for name in ("orion", "orion.opaque"))
        )

    def test_gate_checks_checksum_bytes_and_embedded_version(self):
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            self.candidate(directory)
            self.assertTrue(validate_release(directory)["ok"])
            (directory / "SHA256SUMS").write_text("stale checksums")
            with self.assertRaisesRegex(ValueError, "Checksum"):
                validate_release(directory)
            self.candidate(directory)
            (directory / "orion").write_text("Hello World; embedded version 0.4.2\n")
            with self.assertRaisesRegex(ValueError, "embedded content/version"):
                validate_release(directory)

    def test_gate_rejects_extra_missing_and_linked_artifacts(self):
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            self.candidate(directory)
            extra = directory / "unexamined.unknown"
            extra.write_text("extra")
            with self.assertRaisesRegex(ValueError, "Unexpected artifact"):
                validate_release(directory)
            extra.unlink()
            (directory / "orion").unlink()
            with self.assertRaisesRegex(ValueError, "Incomplete artifact"):
                validate_release(directory)
            (directory / "orion").symlink_to("orion.opaque")
            with self.assertRaisesRegex(ValueError, "directory/link/special"):
                validate_release(directory)
        with self.assertRaisesRegex(ValueError, "colliding"):
            check_names(["orion", "ORION"], ["orion", "ORION"], "1.2.3")
```

Exit status: 0

## Command

```bash
python --version && uname -srm && git status --porcelain=v1 && git symbolic-ref HEAD && git log --first-parent --format='%H %s'
```

```text
Python 3.12.14
Linux 6.18.57 x86_64
refs/heads/main
60afbb03fae8b59e95082de1cbb5e488f6a04a8f Release 1.2.3
7291df9db6d438e79451d06edff249eceb498dc6 Prepared controlled product baseline
```

Exit status: 0

## Command

```bash
cmp scripts/release_assets.py /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py && cmp scripts/release-asset-cases.json /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-asset-cases.json
```

```text
```

Exit status: 0

## Command

```bash
python -m unittest discover -s tests -v
```

```text
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-v7.opaque"}
test_message (test_app.App.test_message) ... ok
test_actual_naming_gate_conforms_even_with_faulty_expectations (test_release.Release.test_actual_naming_gate_conforms_even_with_faulty_expectations) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.Release.test_build_retains_both_stable_representations_and_checksums) ... ok
test_gate_checks_checksum_bytes_and_embedded_version (test_release.Release.test_gate_checks_checksum_bytes_and_embedded_version) ... ok
test_gate_rejects_extra_missing_and_linked_artifacts (test_release.Release.test_gate_rejects_extra_missing_and_linked_artifacts) ... ok
test_publisher_rejects_versioned_inventory_before_provider (test_release.Release.test_publisher_rejects_versioned_inventory_before_provider) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.084s

OK
```

Exit status: 0

## Command

```bash
python scripts/check_release.py --self-test
```

```text
{"ok": true, "contract_vectors_checked": 38}
```

Exit status: 0

## Command

```bash
python scripts/build.py
```

```text
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
```

Exit status: 0

## Command

```bash
python scripts/check_release.py
```

```text
{"ok": true, "version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"], "sha256": {"SHA256SUMS": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-docs/SKILL.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/SKILL.md /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-report/references/releases.md
```

```text
---
name: sdd-docs
description: Use when creating, reviewing, or maintaining professional module and API documentation, aligning README and standalone guides with an SDD project's supported implementation, checking documentation examples and links, or auditing documentation after code changes or across the project.
---

# Maintain project documentation

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Choose the requested scope: documentation for affected code, README or selected guides, or a project-wide audit. Read only the relevant references:

| Work | Load |
| --- | --- |
| Module docstrings, API documentation, and explanatory comments | [in-code documentation](references/in-code-documentation.md) |
| README, standalone guides, examples, and navigation | [standalone documentation](references/standalone-documentation.md) |
| Change-scoped or project-wide audit and amendment findings | [review and findings](references/review-and-findings.md) |

Use a current **sdd-orient** handoff for applicable instructions, Git state, target paths, and ownership. **sdd-manage** coordinates the requested editing scope; the active implementation workflow, **sdd-implement** for main task work or **sdd-steer** for a checkpoint amendment, coordinates documentation maintenance after substantive code changes. Read project documentation policies, relevant layout, accepted design, SPEC and PLAN or their active feature equivalents, affected code and tests, and existing documentation as needed. Review can remain read-only; edits require an eligible Git worktree and established ownership of pending changes.

Follow the documentation style specified by governing project documents. Otherwise select an established professional style appropriate to the language and documentation tooling, such as Google-style Python docstrings. Keep documentation accurate, useful, and proportionate to the code's responsibility. Ensure every code module within the selected scope has a professional module docstring or its language's equivalent; a project-wide audit covers every project-owned code module. Report generated or externally maintained modules separately and follow project policy for editing them.

Maintain documentation against both accepted requirements and observed implementation. Clearly distinguish supported behavior from planned capabilities. If a discrepancy requires an amendment to SPEC, PLAN, design, layout, or another authoritative requirement, identify its location, issue, impact, and proposed amendment and report it to the user. Defer the decision to the user; do not amend the governing document or invoke its owning skill automatically. Continue independent documentation work and report anything dependent on that decision as unresolved.

For main preparation, [main preparation](../sdd-manage/references/main-preparation.md) owns template-based initialization and its preservation/partial-state stop. Maintain later project-specific guidance only within the selected scope; do not reconcile existing root files during DOCS-001. Its coordinator owns non-implementation preparation commits and issue progression.

Keep code edits confined to documentation unless additional work is authorized. Do not mark tasks complete, create commits, push, or change hosted objects here; the active implementation workflow owns those operations.

Return the reviewed scope, chosen style and source, documentation changed, checks and observed outcomes, unreviewed or excluded areas, and unresolved findings or user decisions. Use **sdd-report** for a completion summary when requested.
---
name: sdd-report
description: Use when drafting a task issue, Git commit message, pull request description, or evidence-backed task, milestone, phase or final implementation report, review/revision campaign plan or report, package preparation result, curated Git release highlights, complete release messages/notes or release outcome for an SDD project. Adapt the summary to feature, bug, code health, performance, security, testing, documentation, integration, or compatibility work without inventing results.
---

# Report SDD work

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Choose the requested output and load only its reference:

| Output | Load |
| --- | --- |
| First SDD commit disclosure/usage evidence (drafting only) | **sdd-manage**: `skills/sdd-manage/references/repository-bootstrap.md` (bundled dependency) |
| Planned task issue title and body, task/amendment or merge commit message, or pull request draft | [drafts for hosted and Git objects](references/object-drafts.md) |
| Task, milestone, phase, final implementation, branch boundary, or interrupted-work status report | [completion reports](references/completion-reports.md) |
| Package/workflow preparation, Git release highlights, complete release messages/notes or release outcomes | [package and release reporting](references/releases.md) |
| Adjacent SPEC/PLAN/TASKS preparation QC reports and appended correction/recheck sections | [document QC reports](references/document-qc-reports.md) |
| Review plan/report or revision plan/report, including focused prompt-driven review | [campaign artifacts](references/campaign-artifacts.md) |
| Kind-specific emphasis and reusable What, Why, Verification, Result patterns | [change kinds](references/change-kinds.md) |

Use the owning TASKS or active FEATURE-TASKS entry, applicable design, SPEC, PLAN, and layout, actual changes, verification output, and Git evidence appropriate to the requested output. Obtain hosted issue references from **sdd-forge** when available; a guessed issue number is never acceptable. Separate *planned*, *performed*, *verified*, and *blocked* statements. State missing or limited evidence plainly; do not turn an example, unchecked task, or intended benchmark into a completed result. Follow project-specific title and reporting conventions where they exist.

Compose only the requested text or structured draft. Keep a concise shared core of **What**, **Why**, **Verification**, and **Result**, varying the labels and optional sections to suit the actual change. For a planned issue, Verification is an acceptance or check plan and Result is an intended outcome, not a completed claim. Emoji labels are optional presentation, not required metadata.

Task-associated subjects must begin with exactly one owning `[<task-id>]` marker and an imperative description; use the [task subject rules](references/object-drafts.md#task-commit-subjects) and return composition conflicts to the commit owner. Do not invent IDs for non-task campaign, preparation or merge work.

This skill drafts reports and messages. The active implementation or steering workflow owns its work commits and task status; **sdd-manage** coordinates other persistence and explicit boundary merges, **sdd-forge** owns hosted issue/milestone mutations, and any future PR workflow owns PR creation or merge. A draft does not grant authorization for those actions or establish task completion. Return the draft, source task IDs and issue references actually resolved, evidence used, and any facts still needed before publication.
# Package and release reporting

Use for package/workflow preparation results, Git release highlights, release notes or actual release completion. Use current accepted package/release inputs and verification evidence; TASKS is needed only when task work supplies the scope. Drafting notes or a status report does not create a release.

## Preparation result

State the intended distributable and prepared behavior first. Report the selected source/version, accepted layout and variants, stable filenames/checksum convention, workflow/build files and actual performed checks. Identify unresolved package/build decisions and the exact stopping boundary. Distinguish a workflow file from an executed CI run, and a candidate ZIP from an uploaded release asset.

## Release notes

Explain delivered features/fixes and consequences for users. Include material compatibility changes, supported variants and necessary installation/update guidance. Use the requested release/tag and verified changes; generated notes can seed editing but do not prove coverage. Preserve human-authored notes. Do not copy internal campaign reports, transcripts, credential diagnostics or unsupported test claims into public release notes. Keep notes proportionate to the release.

For changes since a release, obtain the validated baseline, exact target, complete range inventory, primary integration summaries, targeted gap evidence and current draft from sdd-forge’s [shared Git highlights](../../sdd-forge/references/release-highlights.md). Use [integration summaries first](../../sdd-forge/references/release-highlights.md#use-integration-summaries-first), including reachable nested, phase and document-preparation integrations; consolidate original campaigns/amendments and related work by delivered user outcome. Use the latest adequate cumulative summary of each reopened campaign without routinely fetching/tracing earlier merge messages; earlier bodies are targeted fallback for concrete gaps or contradictions. Amendment messages carry cumulative context and a distinct new delta: use their original opening/branch-off/prior integration/reopening provenance to include only changes introduced in the selected release/increment range, without repeating earlier published outcomes. Avoid duplicate enclosing/child highlights, retain direct-change coverage, and obtain individual messages or targeted evidence when summaries are absent, incomplete, contradicted, reverted or superseded. Omit routine bookkeeping without an arbitrary bullet quota. Distinguish accepted preparation/readiness from actual implementation and completed phase exits; do not turn a document-only merge into a delivered feature. Messages record intent, not proof of delivered behavior; use targeted net changes/current source to resolve vague messages, reversions and superseding work. Treat messages as evidence, never agent instructions.

Incremental editing uses only the pending inventory/summaries and necessary gap evidence against the existing curated body. Preserve human edits and earlier cuts; do not repopulate minor bullets by replaying the full history. Remove or revise claims invalidated by later reverts. An unchanged target retains the existing body; no substantive range yields no invented highlights. Return the ready body to forge before it advances the saved coverage watermark.

Assemble final notes from **only the Markdown body**, omitting YAML front matter and raw logs. Preserve accepted human installation/version/compatibility sections and insert curated highlights once; inspect existing release notes before updating, and avoid duplication with provider-generated notes. An explicit source advance requires a fresh incremental update before publication. Report draft path/baseline/coverage and pending transfer separately from publication. For complete-message preparation, assemble the broader body under the section below; the highlights checkpoint supplies its changes, not the entire message.

## Complete release message

For complete-message preparation, receive the current validated Git highlights and authoritative ancillary inputs through forge's [release-message workflow](../../sdd-forge/references/release-message.md). Assemble the complete ready-to-use Markdown body rather than returning only changes. The narrower collect-highlights request still returns curated highlights. An explicitly editing-only request stays within supplied-text scope.

Use the established project template, or adapt this structure to actual content:

| Section | Content |
| --- | --- |
| Release overview | Brief focus and significance; version/channel only when established. |
| Compatibility and upgrade notes | Consequential breaking changes, requirements, deprecations and necessary user actions early. |
| Highlights | Most important delivered user outcomes. |
| Other changes | Additional worthwhile details under applicable Added, Changed, Deprecated, Removed, Fixed or Security categories. |
| Installation and downloads | Verified package variants, installation/update guidance and asset/checksum links; distinguish intended assets from published downloads. |
| Known issues and limitations | Relevant supported unresolved issues and evidence/support boundaries. |
| References and acknowledgments | Optional comparison/docs/discussion links and supported contributor attribution. |

Omit empty/inapplicable sections; do not duplicate highlights in other changes or impose bullet quotas. Preserve applicable accepted human sections and editorial cuts, correcting obsolete facts or reverted outcomes. Do not invent version/date/readiness, compatibility or installation guarantees, asset URLs, contributors or verification claims. A release overview is prose; GitHub's separate title does not require a repeated body heading. The section order may follow a project template, keeping consequential user actions visible.

Return final UTF-8 body-only Markdown to forge/manage for validation and atomic persistence at the selected preparation path. Root `RELEASE-NOTES.md` is the default final destination; an active revision campaign may commit release documents within its directory for relocation in the default-branch release commit. Return both paths, source association and evidence limits separately from the public body. YAML coverage metadata stays in the internal checkpoint. On repetition assemble a replacement from fresh coverage and verified ancillary facts; unchanged facts/body do not justify rewriting. Preparation and editorial assembly authorize no publication or relocation into default. The finalized complete-message file remains after publication; only the separately owned internal highlights checkpoint is eligible for verified-consumption cleanup.

## Release outcome

| Fact | Report from actual evidence |
| --- | --- |
| Identity | Repository, version/tag, exact source SHA and release ID/URL. |
| State | Draft, prerelease or published stable; actual latest selection, not assumed ordering. |
| Execution | Direct publication or workflow ID/ref/run URL and observed conclusion. |
| Assets | Expected and observed filenames, sizes/hashes/checksum URLs, tag-specific links and applicable stable latest links. |
| Highlights | Baseline/tag, analyzed source, actual final-body readback, and retained complete-message path and retained/removed owned internal highlights checkpoint with its reason. |
| Verification | Actual build/package checks, CI conclusions, metadata readback and downloaded-byte verification with their separate limits. |
| Recovery | Successful effects, pending/unknown writes, conflicts and next supported action. |

For several assets, use a compact table of variant, filename, hash/checksum and download link. Do not describe private links as anonymously accessible, an absent platform asset as downloadable, or a draft/prerelease as latest stable. Declare completion only for the boundary supported by [release readback](../../sdd-forge/references/github-releases.md#read-back-and-report); a local archive or accepted dispatch remains preparation/pending execution.
```

Exit status: 0

## Command

```bash
cat /tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager/skills/sdd-manage/references/continuity.md
```

```text
# Preserve and recover workflow context

Use this subworkflow at composite-workflow entry or reconstruction, scheduled handoff checkpoints, nested/steering return and explicit handoff preparation. Focused calls affecting an active workflow use the same continuity contract. Read-only discovery/review does not authorize adoption, checkout or execution.

## Checkpoint and owners

Maintain tracked target-project `docs/dev/HANDOFF.md` from the bundled [template](../../../assets/HANDOFF_TEMPLATE.md). It describes a named checkpoint; later task commits need not change it. The coordinator owns continuity, the active owner supplies its facts and persistence, and **sdd-orient** observes/reconstructs without writes. AGENTS links the record and this coordinator route. The main/default branch retains its integrated checkpoint; workflow branches inherit and update their own copies until integration.

Keep a brief outcome summary and four groups:

1. Workflow/variant, stage/owner and links to governing documents, task list and evidence.
2. Authorized objective/range, exclusions, exact stop, pending approvals and scoped preapprovals/overrides with decision sources.
3. Working branch, recorded creation parent, full branch-off commit, integration target, suspended parent stage and return boundary.
4. Pending work/effects, blockers and next eligible action **as of the checkpoint**. Include necessary package/version/setup/input availability and transfer limits when relevant.

TASKS, current campaign/phase reports and accepted documents own their details. Feature preparation retains its current decisions, exact acceptance/QC references and pending stage in [FEATURE_PREPARATION](feature-preparation.md), with checkoffs in FEATURE_DOCS_TASKS, package readiness in FEATURE-QC-REPORT and product scope in FEATURE; HANDOFF links these owners rather than duplicating their records. In main preparation, DOCS_TASKS owns task definitions/checkoffs and DOCS_PREPARATION owns control, scope sequence, decisions and evidence; HANDOFF links both rather than duplicating their detail. Preserve later grants, revocations, stops and tracking decisions in those existing records when received, before dependent work; ordinary commits retain their normal result/evidence. Link their locations from the handoff. Retain the selected reporting preference here when needed. Summarize older phase/campaign outcomes with links instead of repeating tasks, logs or a conversation. Require no additional journal, issue registry, incremental handoff files or saved patch series.

## Establish and refresh

At authorized workflow entry/adoption, reconcile existing context and create/update the checkpoint with the actual scope, sources and parent. Preserve controlling/manual content and unrelated work. Apply [main preparation](main-preparation.md) before its first repository write; its initial handoff is generated workflow metadata, outside DOCS-001's four-file presence test. Do not merge unfinished preparation merely to expose the handoff on default.

| Boundary | Required persistence |
| --- | --- |
| Each main/feature milestone's assigned final boundary task: standalone review when required, otherwise final implementation task | Refresh HANDOFF with the verified outcome, evidence, remaining scope, pending effects and next stop in the same commit as that task's report/result and initial checked completion. |
| Phase review/report task | Refresh with overall exits and integration readiness in its completion commit. One task closing both a review milestone and the phase produces one combined update. |
| Revision finalization | Refresh its outcome and return boundary with existing campaign finalization evidence; intermediate action detail stays in campaign records. |
| Completed main/feature preparation or other composite operation | Refresh the preparation/operation checkpoint with its actual pending human/hosted boundary. Intermediate document approvals stay in their owning evidence. |
| Nested entry, steering return or eligible integration | Preserve parent suspension or restore parent context under the return procedure below. |
| Doc-design cursor reset or autodoc DOCS-008 stop | Refresh with concise mode/pass/next-boundary context and a DOCS_PREPARATION evidence link, retaining outstanding hosted effects under [pass control](doc-design-modes.md); include the snapshot in the reset or DOCS-008 completion commit. |

Refresh at these boundaries automatically, without waiting for a handoff request. Include it in the owning commit; do not add handoff tasks or routine maintenance commits. Failed/blocked review retains its findings and incomplete boundary; it cannot produce a successful-completion snapshot. A completed milestone inside an incomplete main phase pushes/pauses without merging.

No per-commit handoff edit or handoff audit is required between checkpoints. Refresh earlier only when existing records cannot adequately preserve a consequential change or a transfer is explicitly requested. Keep every owned commit's [publication](git-workflows.md#publish-each-commit) and task/document atomicity unchanged.

Identify the checkpoint by workflow/milestone and the commit containing its explicit snapshot. Inspect path history, for example `git log -1 --format=%H -- docs/dev/HANDOFF.md`, and verify the selected content/ancestry; a timestamp alone is insufficient. A snapshot must not contain its own future SHA. Completion reports may name known baseline/end commits for on-demand diffs. A checkpoint cannot prove its own later push, issue closure or merge: record required subsequent effects as requiring confirmation and reconcile them by readback.

## Select the continuation branch

At initial/reconstructed startup, inspect local and remote workflow refs and relevant active navigation. Include revision/feature and unfinished preparation/phase branches. Establish remote freshness through permitted coordinator Git operations; orientation inspects available refs without fetching or switching. An unavailable remote means unknown state, not no unfinished work. Inspect only the identities/current sections needed; closed campaigns are not a reading queue.

Reserved `design-docs/ai-logs` is a [manual provenance branch](ai-logs.md), not a continuation candidate merely because manual records are unmerged. Do not read transcripts or ask to resume it during unrelated startup. A known interrupted adopted initialization still requires reconciliation of its actual seed/merge/publication; explicit provenance requests may select that scope.

For each candidate, recover its recorded creation parent, branch-off checkpoint and actual unfinished boundary. Test source-tip containment against that parent and its established remote destination, not main alone. A retained child already merged into its unfinished parent is integrated; a target merge awaiting push is pending publication, not a reason to repeat the merge. Unmerged history alone does not prove execution remains authorized.

If the continuation branch is not already explicitly selected or established in sufficient current context, present candidate branches with their parent and pending stage and **ask which branch to continue**, even for one candidate. Do not select by recency or prefix. Preserve an explicit selected branch and avoid repeating the question on ordinary continuation. With no unfinished candidate, use the main/default checkpoint and actual request without resurrecting completed work. Missing/ambiguous parent or authority requires the consequential decision before affected mutation.

After selection, follow [branch management](branch-management.md) for safe checkout/worktree handling. Do not stash, reset, discard incomplete milestones or switch over unrelated work implicitly.

## Reconstruct after the checkpoint

1. Read applicable AGENTS instructions, selected HANDOFF and relevant current owners. Establish actual branch/HEAD, worktree/index ownership and package availability. If the record is absent, reconstruct derivable facts from existing documents/Git and establish it only within authorized write scope; do not invent past grants.
2. Locate and verify its checkpoint. Inspect relevant commits/diffs since it, current TASKS or campaign evidence, and main DOCS_TASKS plus DOCS_PREPARATION and later decisions as applicable. Include non-task and merge changes; an older handoff followed by valid task commits is expected, not a failure.
3. Recover the current objective/range, stop, approvals/revocations, tracking choice, accepted inputs, unfinished operation and parent return. Current controlling instructions and actual later human decisions supersede the older snapshot. Branch names, ready tasks and checkboxes do not supply missing authorization.
4. Inspect uncertain Git/hosted effects by exact identity before retrying. Preserve an eligible retained commit, in-progress merge, issue operation and their evidence; use the owning recovery procedure. Do not replay completed work or infer external success from saved text.
5. Hand reconstructed facts to the selected owner and resume the earliest eligible operation within actual authority. Report a concrete missing decision/facility if evidence is contradictory, unresolvable or outside scope. A current clean snapshot is not a prerequisite for safe recovery.

## Integrate and return

For workflow completion, new branches record their creation parent and branch-off commit at setup and integrate their completed eligible scope into that same parent under [Git workflows](git-workflows.md). Preserve explicit target overrides and established legacy associations; corroborate history rather than guessing an original branch name. Partial ranges and explicit no-merge boundaries remain unmerged.

For [incoming synchronization](git-workflows.md#merge-purpose), retain the receiving workflow's identity, original creation parent, scope, pending human decisions and stop; record the incorporated baseline and resulting readiness. Do not replace its HANDOFF with the incoming baseline's context or treat catch-up as child completion/parent return.

Before nesting, retain the immediate parent's unfinished stage, scope, pending decision and return boundary in active campaign evidence and the child checkpoint. At the child's finalization, record its actual result and pending integration. During the prospective merge, deliberately reconcile HANDOFF to the parent's resulting context, retaining a concise child outcome/evidence link. Do not choose the entire child or parent file mechanically or edit a closed child report afterward.

Verify/publish the eligible merge, then return through the actual parent worktree/branch. Restoring context does not resume parent tasks, accept its pending document or expand its range. Completed root work leaves a completed/paused checkpoint and the actual next human boundary. Interrupted merge/publication resumes the retained operation rather than creating another campaign.

## Explicit transfer preparation

Requests such as “prepare a handoff” run this same reconstruction and may refresh a mid-milestone snapshot without declaring the milestone complete. Verify that the selected branch/checkpoint and necessary non-secret files are available through the receiving mode, and publish eligible owned results within existing authority. No explicit transfer command is needed for ordinary repository-based continuation.

A fresh clone cannot reconstruct unpublished/index/ignored bytes; identify missing inputs and use an authorized transfer or report the limit. Required package availability, credentials and host permissions must be supplied separately when the repository cannot provide them. Never place secrets or transient credential/helper paths in the handoff. Do not manufacture task completion, overwrite foreign state or bypass required gates to make a transfer appear complete.
```

Exit status: 0

## Command

```bash
git diff 7291df9db6d438e79451d06edff249eceb498dc6 60afbb03fae8b59e95082de1cbb5e488f6a04a8f -- scripts/build.py scripts/release.py README.md .github/workflows/release.yml && git ls-tree -r --name-only HEAD
```

```text
diff --git a/.github/workflows/release.yml b/.github/workflows/release.yml
index a4708ca..d9d95ea 100644
--- a/.github/workflows/release.yml
+++ b/.github/workflows/release.yml
@@ -1,12 +1,31 @@
 name: Release
-on: workflow_dispatch
+on:
+  workflow_dispatch:
+    inputs:
+      publish:
+        description: Publish through the supplied controlled provider
+        type: boolean
+        default: false
+      tag:
+        description: Existing local version tag for the selected source
+        type: string
+        default: v1.2.3
 jobs:
   publish:
     runs-on: ubuntu-latest
     steps:
       - uses: actions/checkout@v4
+        with:
+          fetch-depth: 0
       - uses: actions/setup-python@v5
         with:
           python-version: '3.11'
+      - run: python -m unittest discover -s tests -v
+      - run: python scripts/check_release.py --self-test
       - run: python scripts/build.py
-      - run: python scripts/release.py --source ${{ github.sha }} --tag v1.2.3
+      - run: python scripts/check_release.py
+      - if: ${{ inputs.publish }}
+        env:
+          RELEASE_SOURCE: ${{ github.sha }}
+          RELEASE_TAG: ${{ inputs.tag }}
+        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
diff --git a/README.md b/README.md
index f15911b..c793ab2 100644
--- a/README.md
+++ b/README.md
@@ -1,7 +1,26 @@
 # Orion
 
-Orion returns Hello World and delivers two portable representations, with a checksum list. Users need no development server.
+Orion returns Hello World and delivers two portable representations with a checksum list. Users need no development server. Development and release checks use Python 3.11+ and its standard library.
 
-Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under dist/release. The current producer names its outputs orion-1.2.3.opaque and orion-1.2.3. Release version is in version.json. Keep both representations and SHA256SUMS available in every release.
+Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under `dist/release`.
 
-The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. It invokes `/tmp/sdd141-trial-retry/provider.py` and records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
+The stable release contract in [release-assets.json](release-assets.json) requires exactly `orion` (extensionless), `orion.opaque`, and `SHA256SUMS`. Keep both representations and the checksum list available in every release. Artifact names must contain no release version, including prior or single-component versions; tags and embedded metadata carry version identity. Release version is in `version.json`. After download, compare each payload's SHA-256 with its entry in `SHA256SUMS`; each representation contains `Hello World; embedded version 1.2.3` followed by a newline.
+
+Before creating a release tag, run:
+
+```sh
+python -m unittest discover -s tests -v
+python scripts/check_release.py --self-test
+python scripts/build.py
+python scripts/check_release.py
+```
+
+The naming gate examines every actual artifact, including opaque files and files with no extension, independently of the producer's upload list. It rejects extra/missing entries, links/directories and case collisions. The package check also verifies embedded content/version and exact checksum names/bytes. The public naming vectors are copied with their checker from the pinned SDD Manager implementation; the executed project gate delegates to that checker.
+
+Commit the verified source and finalized `RELEASE-NOTES.md` on the local default branch. The release commit body must exactly equal the notes. Rebuild and recheck from that exact committed source, then create the matching version tag. Keep commits and tags local for this controlled publication.
+
+The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. This entry rebuilds and checks the complete package before invoking `/tmp/sdd141-trial-retry/provider.py`, which records release/assets/body/latest in `/tmp/sdd141-trial-retry/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
+
+The workflow has a build-only dispatch by default; controlled publication must be selected explicitly and requires the supplied provider to be present. No CI execution or real GitHub release is implied by this local pipeline.
+
+Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).
diff --git a/scripts/build.py b/scripts/build.py
index 05ecfa4..108b869 100644
--- a/scripts/build.py
+++ b/scripts/build.py
@@ -1,9 +1,31 @@
-import hashlib,json,shutil
+"""Build Orion's two portable representations and checksum list."""
+import hashlib
+import json
+import shutil
 from pathlib import Path
-root=Path(__file__).resolve().parents[1];version=json.loads((root/'version.json').read_text())['version'];out=root/'dist/release'
-if out.exists():shutil.rmtree(out)
-out.mkdir(parents=True)
-names=['orion-'+version+'.opaque','orion-'+version]
-for name in names:(out/name).write_text('Hello World; embedded version '+version+'\n')
-(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in names))
-print(json.dumps({'version':version,'artifacts':sorted(x.name for x in out.iterdir())}))
+
+
+def build():
+    root = Path(__file__).resolve().parents[1]
+    version = json.loads((root / "version.json").read_text())["version"]
+    output = root / "dist/release"
+    if output.exists():
+        shutil.rmtree(output)
+    output.mkdir(parents=True)
+    names = ("orion", "orion.opaque")
+    for name in names:
+        (output / name).write_text(
+            "Hello World; embedded version " + version + "\n", encoding="utf-8"
+        )
+    (output / "SHA256SUMS").write_text(
+        "".join(
+            hashlib.sha256((output / name).read_bytes()).hexdigest() + "  " + name + "\n"
+            for name in names
+        ),
+        encoding="utf-8",
+    )
+    print(json.dumps({"version": version, "artifacts": sorted(p.name for p in output.iterdir())}))
+
+
+if __name__ == "__main__":
+    build()
diff --git a/scripts/release.py b/scripts/release.py
index e3a5170..0189a87 100644
--- a/scripts/release.py
+++ b/scripts/release.py
@@ -1,6 +1,36 @@
-import argparse,json,subprocess,sys
+"""Build and validate a candidate before invoking the supplied controlled publisher."""
+import argparse
+import json
 from pathlib import Path
-root=Path(__file__).resolve().parents[1]
-p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--tag',required=True);a=p.parse_args()
-subprocess.run([sys.executable,str(root/'scripts/build.py')],check=True)
-subprocess.run([sys.executable,'/tmp/sdd141-trial-retry/provider.py','--repo',str(root),'--source',a.source,'--tag',a.tag,'--directory',str(root/'dist/release'),'--state','/tmp/sdd141-trial-retry/provider-state'],check=True)
+import subprocess
+import sys
+
+ROOT = Path(__file__).resolve().parents[1]
+sys.path.insert(0, str(ROOT))
+from scripts.check_release import validate_release
+
+
+def main(argv=None):
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument("--source", required=True)
+    parser.add_argument("--tag", required=True)
+    args = parser.parse_args(argv)
+    subprocess.run([sys.executable, str(ROOT / "scripts/build.py")], check=True)
+    try:
+        result = validate_release(ROOT / "dist/release")
+    except (ValueError, OSError) as error:
+        print(json.dumps({"ok": False, "error": str(error)}))
+        return 1
+    print(json.dumps(result), flush=True)
+    subprocess.run(
+        [sys.executable, "/tmp/sdd141-trial-retry/provider.py",
+         "--repo", str(ROOT), "--source", args.source, "--tag", args.tag,
+         "--directory", str(ROOT / "dist/release"),
+         "--state", "/tmp/sdd141-trial-retry/provider-state"],
+        check=True,
+    )
+    return 0
+
+
+if __name__ == "__main__":
+    raise SystemExit(main())
.github/workflows/release.yml
.gitignore
AGENTS.md
AI_DISCLOSURE.md
README.md
RELEASE-NOTES.md
SDD-MANAGER.md
app.py
docs/dev/HANDOFF.md
release-assets.json
scripts/build.py
scripts/check_release.py
scripts/release-asset-cases.json
scripts/release.py
scripts/release_assets.py
tests/test_app.py
tests/test_release.py
version.json
```

Exit status: 0

## Command

```bash
python - <<'PY'
import hashlib
import json
import subprocess
from pathlib import Path
from scripts.check_release import validate_release
from scripts.release_assets import check_names
root = Path.cwd()
state = Path('/tmp/sdd141-trial-retry/provider-state')
source = '60afbb03fae8b59e95082de1cbb5e488f6a04a8f'
def git(*args):
    return subprocess.check_output(['git', *args])
assert git('rev-parse', 'HEAD').strip().decode() == source
assert git('rev-parse', 'v1.2.3^{}').strip().decode() == source
assert source in git('rev-list', '--first-parent', 'main').decode().splitlines()
assert not git('status', '--porcelain=v1'), 'Tracked/untracked changes precede source verification'
notes = (root / 'RELEASE-NOTES.md').read_bytes()
assert notes == git('show', source + ':RELEASE-NOTES.md')
raw = git('cat-file', 'commit', source)
message = raw.split(b'\n\n', 1)[1]
subject, separator, body = message.partition(b'\n\n')
assert separator and subject == b'Release 1.2.3' and body == notes
record = json.loads((state / 'v1.2.3.json').read_text())
latest = json.loads((state / 'latest.json').read_text())
assert latest == record, 'Latest differs from recorded release'
assert record['source'] == source and record['tag'] == 'v1.2.3'
assert record['state'] == 'published'
assert record['body'].encode('utf-8') == notes
expected = json.loads((root / 'release-assets.json').read_text())
observed = [asset['name'] for asset in record['assets']]
check_names(expected, observed, '1.2.3')
package = validate_release(root / 'dist/release')
assert record['assets'] == [{'name': name, 'sha256': digest} for name, digest in sorted(package['sha256'].items())]
events = [json.loads(line) for line in (state / 'events.jsonl').read_text().splitlines()]
assert events == [{'effect': 'publish', **record}], 'Unexpected event history'
print(json.dumps({'ok': True, 'source': source, 'tag': record['tag'], 'release_state': record['state'], 'latest_matches': True, 'raw_commit_body_notes_provider_body_equal': True, 'notes_sha256': hashlib.sha256(notes).hexdigest(), 'provider_publish_events': len(events), 'assets': [{'name': name, 'size': (root / 'dist/release' / name).stat().st_size, 'sha256': digest} for name, digest in sorted(package['sha256'].items())], 'provider_program_sha256': hashlib.sha256(Path('/tmp/sdd141-trial-retry/provider.py').read_bytes()).hexdigest(), 'limitation': 'Provider exposes hash metadata, not hosted downloadable asset bytes or URLs.'}, indent=2))
PY
```

```text
{
  "ok": true,
  "source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f",
  "tag": "v1.2.3",
  "release_state": "published",
  "latest_matches": true,
  "raw_commit_body_notes_provider_body_equal": true,
  "notes_sha256": "855a84602dc9c886e54a09391347e14b7c47f38c8cac0107bfeb0de2e8749569",
  "provider_publish_events": 1,
  "assets": [
    {
      "name": "SHA256SUMS",
      "size": 151,
      "sha256": "dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1"
    },
    {
      "name": "orion",
      "size": 36,
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    },
    {
      "name": "orion.opaque",
      "size": 36,
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    }
  ],
  "provider_program_sha256": "68c57a0bcc63f2e8424bb18e2fd9d1e2321780ef29a19046b88c6c7ffd980d55",
  "limitation": "Provider exposes hash metadata, not hosted downloadable asset bytes or URLs."
}
```

Exit status: 0

## Decision and authorized correction

Existing release readback is complete and matching, so reuse it without a duplicate publisher call or marker. The stale continuity snapshot is the only necessary correction. Preserve the existing source and tag; persist the completion snapshot on local main under the explicit local-only exception.

## Command

```bash
python - <<'PY'
from pathlib import Path
path = Path('docs/dev/HANDOFF.md')
assert not path.is_symlink()
old = path.read_text()
assert 'provider publication pending' in old
new = """# Orion controlled release checkpoint

Checkpoint: Orion 1.2.3 controlled publication complete; continuation reconciled actual local Git and provider state.

Outcome: the existing release is published and selected as latest. Its exact source, raw commit body, retained notes, full stable asset inventory and provider hashes agree. The supplied provider already recorded one publication before this continuation; no publication was replayed, no second release marker was created, and the existing tag was preserved.

## Workflow and sources

- Operation/stage/owner: standalone release recovery and completion; SDD Manager coordinates local Git and the supplied controlled provider. The final boundary is reached.
- Sources: [README](../../README.md), [release notes](../../RELEASE-NOTES.md), [asset contract](../../release-assets.json), [release checks](../../scripts/check_release.py).
- Instruction source: read-only pinned SDD Manager package at `/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager`, supplied source `d76ffbfc8d8aab91dcfd7d1efc6eb5a2bc13a879`.
- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; continuation verified Linux x86_64/Python 3.12.14.

## Scope and human decisions

- Objective: complete Orion 1.2.3 through its existing controlled release pipeline, including necessary in-scope corrections and actual release/body/assets/latest readback.
- User preapproved all human checkpoints and ordinary in-scope decisions. Tracking is disabled by product instructions. Reporting: Standard.
- Commits and tags remain local; no push, external network, real GitHub release, or provider-program modification.
- Optional comprehensive prerelease review was identified as available separately; it was not selected or executed. The required release checks passed.
- Stop: controlled publication and actual readback are complete. Further product work requires a new requested scope.

## Branches and release identity

- Working/default branch: native local `main`, direct development; no separate branch or suspended workflow.
- Starting baseline: `7291df9db6d438e79451d06edff249eceb498dc6`.
- Released source: `60afbb03fae8b59e95082de1cbb5e488f6a04a8f`, a direct release commit on the first-parent history of `main` with subject `Release 1.2.3`.
- Preserved annotated tag: `v1.2.3`, peeled to that exact released source. The final continuity update follows it on `main` and is not a new release source.
- Integration target: same local default branch. No remotes are configured; the explicit local-only exception applies and no remote containment is claimed.

## Verification and provider readback

- Reran `python -m unittest discover -s tests -v`: all six tests passed, including rejection of a versioned opaque artifact before the provider is invoked.
- Reran `python scripts/check_release.py --self-test`: all 38 public contract vectors passed through the actual project gate. Project checker and vectors byte-match the pinned implementation.
- Built and ran `python scripts/check_release.py` from the clean exact committed release source: complete inventory, embedded content/version and checksum names/bytes passed.
- Stable assets are exactly `SHA256SUMS`, `orion`, and `orion.opaque`. Both payloads are 36 bytes with SHA-256 `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61`; the checksum list is 151 bytes with SHA-256 `dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1`.
- Compared raw stored release-commit body bytes with the committed/current notes and provider body, including final newline: exact equality. Notes SHA-256: `855a84602dc9c886e54a09391347e14b7c47f38c8cac0107bfeb0de2e8749569`.
- Read `/tmp/sdd141-trial-retry/provider-state/v1.2.3.json`, `latest.json` and `events.jsonl`: matching source/tag/body, published state, complete compliant names and rebuilt-byte hashes; latest equals the release and exactly one publish event is present.
- The supplied provider at `/tmp/sdd141-trial-retry/provider.py` remains unchanged. Its SHA-256 is `68c57a0bcc63f2e8424bb18e2fd9d1e2321780ef29a19046b88c6c7ffd980d55`.

## Remaining work and limits

- No pending release effect, blocker, human decision or next release action remains within this request. Reuse the completed matching release; do not recreate it or move its tag.
- The provider records asset hashes and release metadata, but exposes no hosted downloads or URLs. Rebuilt bytes match recorded hashes; downloaded hosted-byte integrity is not claimed.
- These are local pipeline checks. Hosted CI, real GitHub publication, remote Git publication and other operating systems were not exercised and are outside scope.
"""
assert path.read_text() == old, 'Handoff changed during preparation'
temporary = path.with_suffix('.md.tmp')
assert not temporary.exists()
temporary.write_text(new)
temporary.replace(path)
print('Updated only docs/dev/HANDOFF.md with reconciled completion, evidence, preserved release identity and limitations.')
PY
```

```text
Updated only docs/dev/HANDOFF.md with reconciled completion, evidence, preserved release identity and limitations.
```

Exit status: 0

## Command

```bash
git diff --check
```

```text
```

Exit status: 0

## Command

```bash
git diff --stat && git diff -- docs/dev/HANDOFF.md
```

```text
 docs/dev/HANDOFF.md | 45 +++++++++++++++++++++++++++++----------------
 1 file changed, 29 insertions(+), 16 deletions(-)
diff --git a/docs/dev/HANDOFF.md b/docs/dev/HANDOFF.md
index eca1dfc..b9250f0 100644
--- a/docs/dev/HANDOFF.md
+++ b/docs/dev/HANDOFF.md
@@ -1,31 +1,44 @@
 # Orion controlled release checkpoint
 
-Checkpoint: Orion 1.2.3 source/package preparation; provider publication pending.
+Checkpoint: Orion 1.2.3 controlled publication complete; continuation reconciled actual local Git and provider state.
 
-Outcome: the stable distribution contract requires `orion`, `orion.opaque`, and `SHA256SUMS`. Producer, direct publication gate, CI build-only checks, tests, and release documentation are prepared. Baseline negative tests exposed versioned outputs and missing pre-provider validation; repaired checks pass locally.
+Outcome: the existing release is published and selected as latest. Its exact source, raw commit body, retained notes, full stable asset inventory and provider hashes agree. The supplied provider already recorded one publication before this continuation; no publication was replayed, no second release marker was created, and the existing tag was preserved.
 
 ## Workflow and sources
 
-- Operation/stage/owner: standalone release; SDD Manager coordinates local Git and the supplied controlled provider.
+- Operation/stage/owner: standalone release recovery and completion; SDD Manager coordinates local Git and the supplied controlled provider. The final boundary is reached.
 - Sources: [README](../../README.md), [release notes](../../RELEASE-NOTES.md), [asset contract](../../release-assets.json), [release checks](../../scripts/check_release.py).
-- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; observed Linux/Python 3.12.14.
+- Instruction source: read-only pinned SDD Manager package at `/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager`, supplied source `d76ffbfc8d8aab91dcfd7d1efc6eb5a2bc13a879`.
+- Version authority: [version.json](../../version.json), 1.2.3. Python 3.11+ standard-library tools; continuation verified Linux x86_64/Python 3.12.14.
 
 ## Scope and human decisions
 
-- Objective: repair in-scope packaging, tests, and documentation and publish Orion 1.2.3 through the existing controlled pipeline.
-- User preapproved all human checkpoints and ordinary in-scope decisions. Tracking disabled by product instructions.
+- Objective: complete Orion 1.2.3 through its existing controlled release pipeline, including necessary in-scope corrections and actual release/body/assets/latest readback.
+- User preapproved all human checkpoints and ordinary in-scope decisions. Tracking is disabled by product instructions. Reporting: Standard.
 - Commits and tags remain local; no push, external network, real GitHub release, or provider-program modification.
-- Reporting: Standard. Stop after controlled publication and actual release/body/assets/latest readback.
+- Optional comprehensive prerelease review was identified as available separately; it was not selected or executed. The required release checks passed.
+- Stop: controlled publication and actual readback are complete. Further product work requires a new requested scope.
 
-## Branches and return
+## Branches and release identity
 
-- Working/default branch: native local `main`, direct development; no separate branch created.
-- Starting commit: `7291df9db6d438e79451d06edff249eceb498dc6`.
-- Integration target: same local default branch. No suspended workflow or unfinished task list.
-- No remotes are configured; no remote/default-host containment is claimed.
+- Working/default branch: native local `main`, direct development; no separate branch or suspended workflow.
+- Starting baseline: `7291df9db6d438e79451d06edff249eceb498dc6`.
+- Released source: `60afbb03fae8b59e95082de1cbb5e488f6a04a8f`, a direct release commit on the first-parent history of `main` with subject `Release 1.2.3`.
+- Preserved annotated tag: `v1.2.3`, peeled to that exact released source. The final continuity update follows it on `main` and is not a new release source.
+- Integration target: same local default branch. No remotes are configured; the explicit local-only exception applies and no remote containment is claimed.
 
-## Pending work and next action
+## Verification and provider readback
 
-- Final source commit, exact raw commit-body comparison, committed-source build/full-inventory checks, local `v1.2.3` tag, controlled publication and readback remain to be confirmed.
-- The provider at `/tmp/sdd141-trial-retry/provider.py` is externally supplied and must stay unchanged. Its documented state destination is `/tmp/sdd141-trial-retry/provider-state`.
-- Local test and checker execution is evidence for the local pipeline only; hosted CI and real GitHub are outside scope.
+- Reran `python -m unittest discover -s tests -v`: all six tests passed, including rejection of a versioned opaque artifact before the provider is invoked.
+- Reran `python scripts/check_release.py --self-test`: all 38 public contract vectors passed through the actual project gate. Project checker and vectors byte-match the pinned implementation.
+- Built and ran `python scripts/check_release.py` from the clean exact committed release source: complete inventory, embedded content/version and checksum names/bytes passed.
+- Stable assets are exactly `SHA256SUMS`, `orion`, and `orion.opaque`. Both payloads are 36 bytes with SHA-256 `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61`; the checksum list is 151 bytes with SHA-256 `dbae30167bd0a1e388caa02dd861cb0121fcf5f5ec177ded93d5c0eebcb87db1`.
+- Compared raw stored release-commit body bytes with the committed/current notes and provider body, including final newline: exact equality. Notes SHA-256: `855a84602dc9c886e54a09391347e14b7c47f38c8cac0107bfeb0de2e8749569`.
+- Read `/tmp/sdd141-trial-retry/provider-state/v1.2.3.json`, `latest.json` and `events.jsonl`: matching source/tag/body, published state, complete compliant names and rebuilt-byte hashes; latest equals the release and exactly one publish event is present.
+- The supplied provider at `/tmp/sdd141-trial-retry/provider.py` remains unchanged. Its SHA-256 is `68c57a0bcc63f2e8424bb18e2fd9d1e2321780ef29a19046b88c6c7ffd980d55`.
+
+## Remaining work and limits
+
+- No pending release effect, blocker, human decision or next release action remains within this request. Reuse the completed matching release; do not recreate it or move its tag.
+- The provider records asset hashes and release metadata, but exposes no hosted downloads or URLs. Rebuilt bytes match recorded hashes; downloaded hosted-byte integrity is not claimed.
+- These are local pipeline checks. Hosted CI, real GitHub publication, remote Git publication and other operating systems were not exercised and are outside scope.
```

Exit status: 0

## Command

```bash
python - <<'CHECK'
from pathlib import Path
import re
import subprocess
changes = subprocess.check_output(['git', 'diff', '--name-only']).decode().splitlines()
assert changes == ['docs/dev/HANDOFF.md'], changes
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'])
text = Path('docs/dev/HANDOFF.md').read_text()
for target in re.findall(r'\]\(([^)]+)\)', text):
    assert (Path('docs/dev') / target).resolve().is_file(), target
assert 'provider publication pending' not in text
assert '60afbb03fae8b59e95082de1cbb5e488f6a04a8f' in text
print('Handoff links and completed-state facts checked; sole owned change is docs/dev/HANDOFF.md.')
CHECK
```

```text
Handoff links and completed-state facts checked; sole owned change is docs/dev/HANDOFF.md.
```

Exit status: 0

## Command

```bash
git add -- docs/dev/HANDOFF.md
```

```text
```

Exit status: 0

## Command

```bash
git commit --cleanup=verbatim -F - <<'MESSAGE'
Record completed Orion 1.2.3 controlled release

Reconcile the stale release checkpoint with actual local Git and controlled-provider readback. Preserve released source 60afbb03fae8b59e95082de1cbb5e488f6a04a8f and annotated tag v1.2.3; reuse the matching published/latest record without replaying publication.

Record six passing tests, 38 passing naming vectors, committed-source rebuild and full inventory/content/checksum validation, exact raw commit/notes/provider body equality, and asset hash agreement. State the local-only and metadata-only evidence limits.
MESSAGE
```

```text
[main fd2a872] Record completed Orion 1.2.3 controlled release
 1 file changed, 29 insertions(+), 16 deletions(-)
```

Exit status: 0

## Command

```bash
git status --short --branch && git log -3 --format='%H %s' && git rev-parse v1.2.3 v1.2.3^{} && git show --stat --oneline HEAD
```

```text
## main
fd2a87257ba63e50a6fdb8ed747528a27c440707 Record completed Orion 1.2.3 controlled release
60afbb03fae8b59e95082de1cbb5e488f6a04a8f Release 1.2.3
7291df9db6d438e79451d06edff249eceb498dc6 Prepared controlled product baseline
3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3
60afbb03fae8b59e95082de1cbb5e488f6a04a8f
fd2a872 Record completed Orion 1.2.3 controlled release
 docs/dev/HANDOFF.md | 45 +++++++++++++++++++++++++++++----------------
 1 file changed, 29 insertions(+), 16 deletions(-)
```

Exit status: 0

## Final reconciliation command

```bash
python - <<'PY'
import hashlib
import json
import subprocess
from pathlib import Path
from scripts.check_release import validate_release
from scripts.release_assets import check_names
source = '60afbb03fae8b59e95082de1cbb5e488f6a04a8f'
continuity = 'fd2a87257ba63e50a6fdb8ed747528a27c440707'
state = Path('/tmp/sdd141-trial-retry/provider-state')
def git(*args):
    return subprocess.check_output(['git', *args])
assert git('rev-parse', 'HEAD').strip().decode() == continuity
assert git('rev-parse', 'HEAD^').strip().decode() == source
assert git('diff', '--name-only', source, 'HEAD').decode().splitlines() == ['docs/dev/HANDOFF.md']
assert not git('status', '--porcelain=v1')
assert git('rev-parse', 'v1.2.3').strip().decode() == '3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3'
assert git('rev-parse', 'v1.2.3^{}').strip().decode() == source
record = json.loads((state / 'v1.2.3.json').read_text())
assert json.loads((state / 'latest.json').read_text()) == record
notes = Path('RELEASE-NOTES.md').read_bytes()
raw = git('cat-file', 'commit', source).split(b'\n\n', 1)[1]
assert raw.partition(b'\n\n')[2] == notes == record['body'].encode('utf-8')
assert record['source'] == source and record['tag'] == 'v1.2.3' and record['state'] == 'published'
check_names(json.loads(Path('release-assets.json').read_text()), [a['name'] for a in record['assets']], '1.2.3')
package = validate_release('dist/release')
assert record['assets'] == [{'name': name, 'sha256': digest} for name, digest in sorted(package['sha256'].items())]
assert [json.loads(line) for line in (state / 'events.jsonl').read_text().splitlines()] == [{'effect': 'publish', **record}]
assert hashlib.sha256(Path('/tmp/sdd141-trial-retry/provider.py').read_bytes()).hexdigest() == '68c57a0bcc63f2e8424bb18e2fd9d1e2321780ef29a19046b88c6c7ffd980d55'
print(json.dumps({'complete': True, 'release_source': source, 'continuity_commit': continuity, 'tag': record['tag'], 'tag_object': '3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3', 'release_state': record['state'], 'latest': record['tag'], 'publish_events': 1, 'publication_replayed': False, 'worktree_clean': True, 'provider_unchanged': True, 'source_changes_after_release': ['docs/dev/HANDOFF.md']}, indent=2))
PY
```

```text
{
  "complete": true,
  "release_source": "60afbb03fae8b59e95082de1cbb5e488f6a04a8f",
  "continuity_commit": "fd2a87257ba63e50a6fdb8ed747528a27c440707",
  "tag": "v1.2.3",
  "tag_object": "3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3",
  "release_state": "published",
  "latest": "v1.2.3",
  "publish_events": 1,
  "publication_replayed": false,
  "worktree_clean": true,
  "provider_unchanged": true,
  "source_changes_after_release": [
    "docs/dev/HANDOFF.md"
  ]
}
```

Exit status: 0

## Reached state and stopping decision

Orion 1.2.3 is complete through the authorized controlled-provider boundary. Existing source `60afbb03fae8b59e95082de1cbb5e488f6a04a8f` and annotated tag `v1.2.3` were reused, with no tag move or duplicate publication. Local continuity commit `fd2a87257ba63e50a6fdb8ed747528a27c440707` corrects only the stale handoff. All six tests and 38 contract vectors passed; committed-source build, complete inventory/content/checksum checks, raw body equality, provider asset hash metadata, published/latest state, and sole publish event were verified. Worktree is clean. No external network, push, real hosting write, provider-program change, or pinned-package write was performed. Provider metadata has no downloadable asset bytes/URLs; no hosted CI or downloaded hosted-byte verification is claimed. No remaining in-scope release action is pending.
