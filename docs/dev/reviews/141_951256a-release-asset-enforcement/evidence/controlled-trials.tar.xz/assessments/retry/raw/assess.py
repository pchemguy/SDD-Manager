import os
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import hashlib, json, shutil, subprocess, sys
from pathlib import Path

E=Path('/tmp/sdd141-assessor-retry-evidence')
P=Path('/tmp/sdd141-trial-retry/product')
K=Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager')
S=Path('/workspace/scratch/f5adda9293ed/SDD-Manager')
SOURCE='d76ffbfc8d8aab91dcfd7d1efc6eb5a2bc13a879'
RELEASE='60afbb03fae8b59e95082de1cbb5e488f6a04a8f'
BASE='7291df9db6d438e79451d06edff249eceb498dc6'
records=[]

def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,value): (E/name).write_text(json.dumps(value,indent=2)+'\n')
def snap(path):
    path=Path(path)
    if path.is_file(): return {'file':sha(path.read_bytes())}
    result={}
    for p in sorted(path.rglob('*')):
        if p.is_symlink(): result[str(p.relative_to(path))]={'symlink':os.readlink(p)}
        elif p.is_file(): result[str(p.relative_to(path))]=sha(p.read_bytes())
    return result
def run(label,argv,cwd=P,env=None):
    r=subprocess.run(argv,cwd=cwd,env={**os.environ,**(env or {})},capture_output=True)
    rec={'label':label,'argv':argv,'cwd':str(cwd),'non_secret_environment':{'PYTHONDONTWRITEBYTECODE':'1',**(env or {})},'returncode':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')}
    records.append(rec)
    save('commands.json',records)
    (E/(label+'.stdout.txt')).write_bytes(r.stdout)
    (E/(label+'.stderr.txt')).write_bytes(r.stderr)
    print(label,r.returncode,flush=True)
    return r

originals={'trial':Path('/tmp/sdd141-trial-retry'),'package':K,'input':Path('/tmp/sdd141-retry-input.json')}
before={name:snap(path) for name,path in originals.items()}
save('preservation-before.json',before)
shutil.copy2('/tmp/sdd141-trial-retry/consumer-actions.md',E/'consumer-actions-retained.md')
shutil.copy2('/tmp/sdd141-retry-input.json',E/'configuration-retained.json')
save('original-bytecode-before.json',{name:[x for x in manifest if '__pycache__' in x or x.endswith('.pyc')] for name,manifest in before.items()})
run('original-git-state',['git','--no-optional-locks','status','--porcelain=v1','--branch'])
run('original-refs',['git','--no-optional-locks','show-ref'])
run('original-history',['git','--no-optional-locks','log','--all','--format=%H %P %s'])
run('original-reflog',['git','--no-optional-locks','reflog','--format=%H %gs','--all'])
run('original-remote',['git','--no-optional-locks','remote','-v'])
run('source-git-state',['git','--no-optional-locks','status','--porcelain=v1','--branch'],cwd=S)
run('source-head',['git','rev-parse','HEAD'],cwd=S)
tree=run('pinned-source-tree',['git','ls-tree','-r','-z',SOURCE,'--','.agents/plugins/sdd-manager'],cwd=S).stdout
identity={'expected_source':SOURCE,'package':str(K),'files':[],'mismatches':[]}
tracked=set()
for entry in tree.split(b'\0'):
    if not entry: continue
    meta,name=entry.split(b'\t',1)
    mode,kind,obj=meta.decode().split()
    rel=Path(name.decode()).relative_to('.agents/plugins/sdd-manager').as_posix()
    tracked.add(rel)
    data=subprocess.check_output(['git','cat-file','blob',obj],cwd=S)
    actual=(K/rel).read_bytes() if (K/rel).is_file() else None
    item={'path':rel,'source_blob':obj,'source_sha256':sha(data),'pinned_sha256':sha(actual) if actual is not None else None}
    identity['files'].append(item)
    if data!=actual: identity['mismatches'].append(rel)
identity['extra_files']=sorted(set(snap(K))-tracked)
identity['all_equal']=not(identity['mismatches'] or identity['extra_files'])
identity['manifest_sha256']=sha(json.dumps([(p, before['package'][p]) for p in sorted(before['package'])],separators=(',',':')).encode())
save('package-identity.json',identity)

# Independent native release/asset readback. No provider is executed here.
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()
tag=subprocess.check_output(['git','rev-parse','v1.2.3^{}'],cwd=P,text=True).strip()
tagraw=subprocess.check_output(['git','cat-file','tag','v1.2.3'],cwd=P)
commitraw=subprocess.check_output(['git','cat-file','commit',head],cwd=P)
notes=(P/'RELEASE-NOTES.md').read_bytes()
provider=Path('/tmp/sdd141-trial-retry/provider-state')
latest=json.loads((provider/'latest.json').read_text())
record=json.loads((provider/'v1.2.3.json').read_text())
events=[json.loads(x) for x in (provider/'events.jsonl').read_text().splitlines()]
inventory=[{'name':p.name,'sha256':sha(p.read_bytes())} for p in sorted((P/'dist/release').iterdir()) if p.is_file()]
native={'head':head,'tag_peeled':tag,'tag_object':subprocess.check_output(['git','rev-parse','v1.2.3'],cwd=P,text=True).strip(),'baseline':BASE,'release_parent':subprocess.check_output(['git','rev-parse',head+'^'],cwd=P,text=True).strip(),'tag_notes_equal':tagraw.split(b'\n\n',1)[1]==notes,'commit_body_notes_equal':commitraw.split(b'\n\n',1)[1].split(b'\n\n',1)[1]==notes,'notes_sha256':sha(notes),'complete_disk_inventory':inventory,'provider_record':record,'provider_latest':latest,'provider_events':events,'provider_assets_match_all_disk_files':record['assets']==inventory,'provider_body_exact':record['body'].encode()==notes,'provider_subject_matches':record['source']==head==tag==RELEASE,'latest_equals_record':latest==record,'publish_event_count':len(events),'only_event_equals_record':len(events)==1 and {k:v for k,v in events[0].items() if k!='effect'}==record}
save('native-provider-readback.json',native)
run('committed-change',['git','diff','--stat',BASE,RELEASE])
run('active-policy-search',['rg','-n','orion-|artifact|release-assets|version|check_release','README.md','RELEASE-NOTES.md','docs','scripts','.github','release-assets.json'])

# All subsequent commands run in independently owned copies.
clean=E/'clean-product'
shutil.copytree(P,clean)
run('clean-unit-suite',[sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=clean)
run('clean-public-vector-check',[sys.executable,'scripts/check_release.py','--self-test'],cwd=clean)
run('clean-build',[sys.executable,'scripts/build.py'],cwd=clean)
run('clean-real-project-gate',[sys.executable,'scripts/check_release.py'],cwd=clean)
save('clean-built-inventory.json',[{'name':p.name,'sha256':sha(p.read_bytes())} for p in sorted((clean/'dist/release').iterdir())])
save('preservation-in-progress.json',{name:snap(path)==before[name] for name,path in originals.items()})
