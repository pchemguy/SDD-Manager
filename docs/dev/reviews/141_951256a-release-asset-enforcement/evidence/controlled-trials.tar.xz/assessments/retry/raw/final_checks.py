import os
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
E=Path('/tmp/sdd141-assessor-retry-evidence')
P=Path('/tmp/sdd141-trial-retry/product')
S=Path('/workspace/scratch/f5adda9293ed/SDD-Manager')
records=json.loads((E/'commands.json').read_text())
def save(n,x): (E/n).write_text(json.dumps(x,indent=2)+'\n')
def run(label,argv,cwd):
    r=subprocess.run(argv,cwd=cwd,env=os.environ,capture_output=True)
    records.append({'label':label,'argv':argv,'cwd':str(cwd),'non_secret_environment':{'PYTHONDONTWRITEBYTECODE':'1'},'returncode':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
    save('commands.json',records)
    (E/(label+'.stdout.txt')).write_bytes(r.stdout)
    (E/(label+'.stderr.txt')).write_bytes(r.stderr)
    print(label,r.returncode,flush=True)
    return r
archive=E/'release-source.tar'
run('exact-commit-archive',['git','archive','--format=tar','--output='+str(archive),'60afbb03fae8b59e95082de1cbb5e488f6a04a8f'],P)
cp=E/'exact-committed-product'
cp.mkdir()
with tarfile.open(archive) as tf: tf.extractall(cp,filter='data')
outcomes=[]
for label,args in [('archive-unit-suite',['-m','unittest','discover','-s','tests','-v']),('archive-vector-check',['scripts/check_release.py','--self-test']),('archive-build',['scripts/build.py']),('archive-real-project-gate',['scripts/check_release.py'])]:
    r=run(label,[sys.executable,*args],cp)
    outcomes.append({'label':label,'returncode':r.returncode})
save('exact-commit-build-provenance.json',{'source':'60afbb03fae8b59e95082de1cbb5e488f6a04a8f','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive':str(archive),'extract_root':str(cp),'python':sys.version,'outcomes':outcomes,'complete_inventory':[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((cp/'dist/release').iterdir())]})

# Reproduce baseline's fault without touching its native object or original tree.
basearchive=E/'baseline-source.tar'
run('baseline-commit-archive',['git','archive','--format=tar','--output='+str(basearchive),'7291df9db6d438e79451d06edff249eceb498dc6'],P)
bc=E/'baseline-product'
bc.mkdir()
with tarfile.open(basearchive) as tf: tf.extractall(bc,filter='data')
run('baseline-fault-build',[sys.executable,'scripts/build.py'],bc)
run('baseline-fault-real-checker',[sys.executable,str(cp/'scripts/release_assets.py'),'--expected',str(cp/'release-assets.json'),'--directory',str(bc/'dist/release'),'--version','1.2.3'],bc)
save('baseline-provenance.json',{'source':'7291df9db6d438e79451d06edff249eceb498dc6','archive_sha256':hashlib.sha256(basearchive.read_bytes()).hexdigest(),'inventory':sorted(p.name for p in (bc/'dist/release').iterdir()),'evidence_limit':'Independent reproduction of baseline fault with final exact checker; not proof of prior consumer command order.'})
run('final-source-git-state',['git','--no-optional-locks','status','--porcelain=v1','--branch'],S)
run('final-source-diff',['git','--no-optional-locks','diff','--stat'],S)
run('final-original-git-state',['git','--no-optional-locks','status','--porcelain=v1','--branch'],P)
save('source-preservation-status.json',{'git_status_unchanged':(E/'source-git-state.stdout.txt').read_bytes()==(E/'final-source-git-state.stdout.txt').read_bytes(),'final_tracked_diff_empty':not(E/'final-source-diff.stdout.txt').read_bytes(),'source_git_head_at_start':(E/'source-head.stdout.txt').read_text().strip(),'note':'No assessor command writes to original source. Source already contained untracked bytecode at initial snapshot; preserved.'})
