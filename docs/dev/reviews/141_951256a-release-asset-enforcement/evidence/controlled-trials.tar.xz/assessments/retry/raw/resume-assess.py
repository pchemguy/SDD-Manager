import os
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import hashlib,json,re,shutil,subprocess,sys,tarfile
from pathlib import Path
E=Path('/tmp/sdd141-assessor-retry-evidence')
R=E/'resume-readback'
R.mkdir()
P=Path('/tmp/sdd141-trial-retry/product')
K=Path('/tmp/sdd141-pinned-retry/.agents/plugins/sdd-manager')
T=Path('/tmp/sdd141-trial-retry')
RELEASE='60afbb03fae8b59e95082de1cbb5e488f6a04a8f'
FINAL='fd2a87257ba63e50a6fdb8ed747528a27c440707'
TAG='3dab03b05821c2e237b8d8a9d7d5fd9e5258c1f3'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,v): (R/n).write_text(json.dumps(v,indent=2)+'\n')
def snap(path):
    return {str(p.relative_to(path)):({'symlink':os.readlink(p)} if p.is_symlink() else sha(p.read_bytes())) for p in sorted(path.rglob('*')) if p.is_file() or p.is_symlink()}
old_evidence={str(p.relative_to(E)):sha(p.read_bytes()) for p in sorted(E.rglob('*')) if p.is_file() and not p.relative_to(E).parts[0].startswith('resume-')}
save('original-assessment-files-before.json',old_evidence)
before_trial=snap(T)
before_package=snap(K)
save('original-trial-before-assessor.json',before_trial)
save('pinned-package-before-assessor.json',before_package)
for source,name in [(Path('/tmp/sdd141-retry-resume-dispatch.txt'),'exact-dispatch.txt'),(Path('/tmp/sdd141-retry-resume-before.json'),'pre-dispatch-state.json'),(T/'resume-consumer-actions.md','consumer-journal.md')]:shutil.copy2(source,R/name)
pre=json.loads((R/'pre-dispatch-state.json').read_text())
journal=(R/'consumer-journal.md').read_text()
commands=[]
def run(label,args,cwd=P):
    r=subprocess.run(args,cwd=cwd,capture_output=True,env=os.environ)
    commands.append({'label':label,'argv':args,'cwd':str(cwd),'non_secret_environment':{'PYTHONDONTWRITEBYTECODE':'1'},'returncode':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
    save('commands.json',commands)
    (R/(label+'.stdout.txt')).write_bytes(r.stdout)
    (R/(label+'.stderr.txt')).write_bytes(r.stderr)
    print(label,r.returncode,flush=True)
    return r
def git(label,*args):return run(label,['git','--no-optional-locks',*args]).stdout
head=git('native-head','rev-parse','HEAD').decode().strip()
parent=git('native-parent','rev-parse','HEAD^').decode().strip()
refs=git('native-refs','show-ref').decode()
status=git('native-status','status','--porcelain=v1').decode()
branch=git('native-branch','symbolic-ref','--short','HEAD').decode().strip()
remote=git('native-remotes','remote','-v').decode()
diff=git('exact-continuation-diff','diff',RELEASE,FINAL,'--').decode()
changed=git('exact-continuation-changed-paths','diff','--name-only',RELEASE,FINAL).decode().splitlines()
git('native-history','log','-3','--format=%H %P %s')
run('continuation-whitespace-check',['git','diff','--check',RELEASE,FINAL])
tag=git('preserved-tag-object','rev-parse','v1.2.3').decode().strip()
peeled=git('preserved-tag-source','rev-parse','v1.2.3^{}').decode().strip()
tagraw=git('release-tag-raw','cat-file','tag','v1.2.3')
raw=git('release-commit-raw','cat-file','commit',RELEASE)
release_notes=git('release-source-notes','show',RELEASE+':RELEASE-NOTES.md')
notes=(P/'RELEASE-NOTES.md').read_bytes()
body=raw.split(b'\n\n',1)[1].partition(b'\n\n')[2]
provider_hashes={p.name:sha(p.read_bytes()) for p in sorted((T/'provider-state').iterdir()) if p.is_file()}
record=json.loads((T/'provider-state/v1.2.3.json').read_text())
latest=json.loads((T/'provider-state/latest.json').read_text())
events=[json.loads(x) for x in (T/'provider-state/events.jsonl').read_text().splitlines()]
for p in (T/'provider-state').iterdir():
    if p.is_file():shutil.copy2(p,R/('provider-'+p.name))
readback={'head':head,'parent':parent,'branch':branch,'status':status,'remote':remote,'changed_paths':changed,'tag_object':tag,'tag_source':peeled,'tag_object_preserved_from_pre_dispatch':TAG in pre['refs'] and tag==TAG,'release_source_preserved':parent==peeled==RELEASE,'final_commit_expected':head==FINAL,'commit_notes_provider_tag_body_exact':body==release_notes==notes==record['body'].encode()==tagraw.split(b'\n\n',1)[1],'notes_sha256':sha(notes),'provider_record':record,'latest_equals_record':latest==record,'sole_publish_event_equals_record':events==[{'effect':'publish',**record}],'event_count':len(events),'provider_hashes':provider_hashes,'provider_files_exactly_unchanged_from_pre_dispatch':provider_hashes==pre['provider'],'provider_client_unchanged_from_pre_dispatch':sha((T/'provider.py').read_bytes())==pre['provider_program_sha256'],'original_journal_unchanged_from_pre_dispatch':sha((T/'consumer-actions.md').read_bytes())==pre['original_journal_sha256'],'exact_dispatch_matches_pre_dispatch_hash':sha((R/'exact-dispatch.txt').read_bytes())==pre['dispatch_sha256']}

identity=json.loads((E/'package-identity.json').read_text())
package_expected={x['path']:x['source_sha256'] for x in identity['files']}
readback['pinned_source']=identity['expected_source']
readback['pinned_package_exact_source_files']=before_package==package_expected
readback['pinned_package_file_count']=len(before_package)
readback['pinned_package_unchanged_from_original_retry_snapshot']=before_package==json.loads((E/'preservation-before.json').read_text())['package']

# Extract the full literal journal commands/results with line references. Do not
# execute consumer journal code or invoke a provider.
literal=[]
blocks=list(re.finditer(r'```bash\n(.*?)\n```',journal,re.S))
for i,m in enumerate(blocks):
    tail=journal[m.end():blocks[i+1].start() if i+1<len(blocks) else len(journal)]
    output=re.search(r'```text\n(.*?)```',tail,re.S)
    status_match=re.search(r'Exit status: (\d+)',tail)
    if not output or not status_match:
        raise ValueError('Incomplete literal journal block at '+str(m.start()))
    literal.append({'journal_line':journal.count('\n',0,m.start())+1,'command':m.group(1),'literal_combined_output':output.group(1).removesuffix('\n'),'exit_status':int(status_match.group(1))})
save('literal-consumer-commands.json',literal)
checks={item['command']:item for item in literal}
requested_checks=['python -m unittest discover -s tests -v','python scripts/check_release.py --self-test','python scripts/build.py','python scripts/check_release.py']
readback['retained_consumer_check_results']=[{'command':cmd,'journal_line':checks[cmd]['journal_line'],'exit_status':checks[cmd]['exit_status'],'output':checks[cmd]['literal_combined_output']} for cmd in requested_checks]
readback['journal_provider_publication_entry_invoked']=any(re.search(r'^\s*(?:python\S*\s+scripts/release\.py|python\S*\s+/tmp/sdd141-trial-retry/provider\.py(?!\s+--help))',x['command'],re.M) for x in literal)
readback['journal_provider_help_only']=any(x['command']=='python3 /tmp/sdd141-trial-retry/provider.py --help' for x in literal)
readback['journal_reached_final_completion']='## Reached state and stopping decision' in journal
readback['instruction_loading']=[{'journal_line':x['journal_line'],'command':x['command'],'exit_status':x['exit_status']} for x in literal if x['command'].startswith('cat ') and ('.agents/plugins/sdd-manager/' in x['command'] or 'cat AGENTS.md ' in x['command'])]

# Limited independent gate verification from native tagged source, in owned
# scratch only. Previous matrix/test suites are unchanged and not repeated.
archive=R/'tagged-release-source.tar'
run('archive-tagged-source',['git','archive','--format=tar','--output='+str(archive),RELEASE])
cp=R/'tagged-release-product'
cp.mkdir()
with tarfile.open(archive) as tf:tf.extractall(cp,filter='data')
build=run('independent-owned-release-build',[sys.executable,'scripts/build.py'],cp)
gate=run('independent-owned-complete-gate',[sys.executable,'scripts/check_release.py'],cp)
inventory=[{'name':p.name,'sha256':sha(p.read_bytes())} for p in sorted((cp/'dist/release').iterdir())]
readback['independent_build_exit']=build.returncode
readback['independent_gate_exit']=gate.returncode
readback['rebuilt_inventory']=inventory
readback['rebuilt_inventory_matches_all_provider_assets']=inventory==record['assets']
readback['current_disk_inventory_matches_rebuilt']=[{'name':p.name,'sha256':sha(p.read_bytes())} for p in sorted((P/'dist/release').iterdir())]==inventory
handoff=(P/'docs/dev/HANDOFF.md').read_text()
readback['handoff_completed_state']='controlled publication complete' in handoff and 'No pending release effect' in handoff and 'provider publication pending' not in handoff
readback['handoff_preserves_release_identity']=RELEASE in handoff and 'not a new release source' in handoff
readback['handoff_local_links_valid']=all((P/'docs/dev'/target).resolve().is_file() for target in re.findall(r'\]\(([^)]+)\)',handoff))
save('independent-readback.json',readback)

after_trial=snap(T)
after_package=snap(K)
pres={'trial_unchanged_during_assessor':before_trial==after_trial,'package_unchanged_during_assessor':before_package==after_package,'all_original_assessment_files_unchanged':all((E/name).is_file() and sha((E/name).read_bytes())==digest for name,digest in old_evidence.items()),'bytecode_before':[p for p in before_trial if '__pycache__' in p or p.endswith('.pyc')],'bytecode_after':[p for p in after_trial if '__pycache__' in p or p.endswith('.pyc')],'assessor_no_new_or_changed_bytecode':{k:v for k,v in before_trial.items() if '__pycache__' in k or k.endswith('.pyc')}=={k:v for k,v in after_trial.items() if '__pycache__' in k or k.endswith('.pyc')}}
save('preservation.json',pres)

required=[head==FINAL,parent==RELEASE,branch=='main',status=='',changed==['docs/dev/HANDOFF.md'],tag==TAG,peeled==RELEASE,readback['commit_notes_provider_tag_body_exact'],readback['provider_files_exactly_unchanged_from_pre_dispatch'],readback['provider_client_unchanged_from_pre_dispatch'],readback['original_journal_unchanged_from_pre_dispatch'],readback['exact_dispatch_matches_pre_dispatch_hash'],readback['pinned_package_exact_source_files'],readback['sole_publish_event_equals_record'],readback['latest_equals_record'],readback['rebuilt_inventory_matches_all_provider_assets'],readback['handoff_completed_state'],readback['handoff_preserves_release_identity'],readback['handoff_local_links_valid'],build.returncode==gate.returncode==0,all(x['exit_status']==0 for x in readback['retained_consumer_check_results']),not readback['journal_provider_publication_entry_invoked'],all(pres[k] for k in ['trial_unchanged_during_assessor','package_unchanged_during_assessor','all_original_assessment_files_unchanged','assessor_no_new_or_changed_bytecode'])]
result={'schema_version':1,'campaign':'141','case_id':'ARTIFACT-NAMES-CONTINUATION','status':'Passed' if all(required) else 'Failed','scope':'Separately dispatched fresh continuation completion and existing-release reconciliation only. Prior runtime matrix remains separate.','agent_behavior_assessed':True,'fresh_context_provenance':'Coordinator reports /root/consumer_resume was launched fork_turns=none with only the retained exact ordinary dispatch; hash verified against pre-dispatch record. Recorded commands stay within bounded product/package/provider scope. This is reported dispatch provenance, not an OS sandbox claim.','dispatch_sha256':pre['dispatch_sha256'],'pinned_source':identity['expected_source'],'checkpoint_refs':{'start':RELEASE,'product_commit':FINAL,'release_source':RELEASE,'tag':'v1.2.3','tag_object':TAG,'branch':'main'},'observed_agent_facts':['Loaded product AGENTS/continuity/README, pinned PLUGIN/manage/orient/forge/verify, release/continuity/Git references; then docs/report owners before handoff correction.','Actual journal records six passing tests, 38 vector pass, build and complete package gate pass while HEAD was still exact tagged source.','Compared native commit/notes/provider bodies, source/tag, full inventory/hashes, published/latest state and sole event before deciding existing release already complete.','Did not invoke publication entry again in retained command journal; provider help was the only direct provider invocation.','Corrected only stale HANDOFF and committed final reconciled state, keeping original release source/tag unchanged.','Final reconciliation and stopping statement are retained.'],'independent_facts':readback,'preservation':pres,'limits':['Original retry assessment/disposition and missing original dispatch remain unchanged; this continuation does not retroactively certify them.','Unchanged hashes prove no persistent provider mutation/duplicate event. Non-replay is supported by retained command journal; there is no separate process audit.','Controlled provider stores metadata/hashes, not downloadable hosted bytes.','No hosted CI, real GitHub, remote publication, installed-client or full catalog acceptance is claimed.','Assessor repeated only owned tagged-source build and actual complete gate; previous broader runtime matrix was not repeated.'],'raw_evidence':str(R),'raw_commands':str(R/'commands.json')}
(E/'resume-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
(E/'resume-assessment.md').write_text(f'''# Campaign 141: separately observed continuation

**Disposition: {result['status']} for continuation completion and existing-release reconciliation.** The original retry assessment remains unchanged, including its missing-dispatch limitation.

The exact ordinary continuation dispatch is retained and matches pre-dispatch SHA-256 `{pre['dispatch_sha256']}`. Coordinator reports the consumer was launched with `fork_turns=none` and only that message; its recorded commands remain within product, pinned package and supplied controlled interface. This establishes reported separate-context dispatch provenance, not OS-enforced isolation. The journal records product and pinned PLUGIN/manage/orient/forge/verify loading, required release/continuity/Git references and docs/report loading before the handoff correction.

Native main is clean at `{FINAL}`, whose sole parent is released source `{RELEASE}`. The exact continuation diff changes only `docs/dev/HANDOFF.md`; it corrects stale pending state to completed publication, records the actual identities/checks and retains appropriate local/provider limitations. Annotated `v1.2.3` remains object `{TAG}`, peeling to the original release, without a new release marker.

The continuation journal records six passing tests, 38 passing vectors, the real build and complete gate while HEAD still equaled the exact release source; it then checks raw commit/notes/provider bodies, source/tag, all assets/hashes, latest/published state and the sole event. Independent readback confirms these facts. An assessor-owned archive rebuild and actual complete gate pass, and every rebuilt artifact hash matches provider metadata. The unchanged 171-file package still exactly matches source `{identity['expected_source']}`.

All provider state files, supplied client and original consumer journal exactly match the pre-dispatch hashes. There is still one publish event and latest equals the existing release. The recorded commands contain no publication-entry invocation; the only direct provider invocation is `--help`. This supports reconciliation without replay or duplicate effects; unchanged hashes alone do not establish process nonexecution. Final reconciliation and completion/stopping statement are retained.

Original assessment files are byte-preserved. Trial/package bytes, Git state and bytecode are unchanged during this assessor follow-up; no provider or original product/package write was performed. Previous negative/runtime matrix remains separate and was not repeated. Hosted CI, live GitHub, remote publication, installed clients, downloadable hosted bytes and full catalog acceptance remain outside this assessment.

Raw evidence is in `resume-readback/`: exact dispatch, pre-dispatch snapshot, full journal, extracted literal commands/results, native diff/objects, provider snapshots, independent readback, owned-source build/gate output and preservation results. `resume-assessment.json` contains exact refs and detailed comparisons.
''')
print(result['status'],flush=True)
