import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--source',required=True);p.add_argument('--tag',required=True);p.add_argument('--directory',required=True);p.add_argument('--state',required=True);a=p.parse_args()
root=Path(a.repo);state=Path(a.state);state.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
if git('rev-parse',a.tag+'^{}') != a.source:raise SystemExit('Tag source mismatch')
if git('rev-parse','HEAD') != a.source:raise SystemExit('Checkout source mismatch')
assets=[{'name':x.name,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sorted(Path(a.directory).iterdir()) if x.is_file()]
data={'tag':a.tag,'source':a.source,'body':(root/'RELEASE-NOTES.md').read_text(),'assets':assets,'state':'published'}
record=state/(a.tag+'.json')
if record.exists():
    if json.loads(record.read_text()) != data:raise SystemExit('Conflicting existing release')
else:
    with (state/'events.jsonl').open('a') as f:f.write(json.dumps({'effect':'publish',**data})+'\n')
    record.write_text(json.dumps(data,indent=2)+'\n')
(state/'latest.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data))
