# Consumer action journal

Initial scope: Orion product only; pinned SDD Manager package read-only; supplied controlled provider only. Human checkpoints preapproved. No push, external hosting, external network, or provider modification.

```bash
pwd; cat AGENTS.md; git status --short --branch; rg --files -g 'AGENTS.md' -g '*RELEASE*' -g '*release*' -g '*TASKS*' -g '*PROJECT*' -g '*PLAN*' -g 'README*' -g 'pyproject.toml' -g 'package.json' -g 'Makefile' -g 'SKILL.md' .
```

```text
/tmp/sdd141-trial-direct/product
# Product instructions

Use SDD Manager from `/tmp/sdd141-pinned/.agents/plugins/sdd-manager/PLUGIN.md` and its coordinator. This pinned package is the instruction source for this trial.

Work only in this product and use the documented controlled provider. No external network, real hosting writes or access to other trial products is authorized. Git commits/tags stay local: this is an explicit local-only publication exception. All human checkpoints and ordinary repair decisions within the request are preapproved. Preserve the provider program at `/tmp/sdd141-trial-direct/provider.py`; it is an external supplied client, not product implementation. Its writes to `/tmp/sdd141-trial-direct/provider-state` through the documented release entry are authorized. Do not inspect coordinator/assessor material outside the product/package/client interface.

Tracking is disabled. Use the existing Python standard-library toolchain. Preserve unrelated work. Source/package preparation and local controlled release are authorized within the user's requested range.
## main
./RELEASE-NOTES.md
./AGENTS.md
./README.md
./scripts/release.py

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/PLUGIN.md; rg --files /tmp/sdd141-pinned/.agents/plugins/sdd-manager | sort; rg --files . | sort
```

```text
---
name: sdd-manager
displayName: SDD Manager
---

# SDD Manager

SDD Manager provides specification-driven development workflows for Git projects through focused skills. This entry orients the agent and routes workflow and capability requests. Each skill's `SKILL.md` owns its procedure; `references/*.md` supply selectively loaded sub-workflows. The [README](README.md) explains capabilities and workflows to humans.

**`sdd-manage` is SDD Manager’s workflow coordinator. Generally load its [entry](skills/sdd-manage/SKILL.md) alongside `PLUGIN.md` before other skills at workflow entry.**

Read an available `PLUGIN.md` explicitly when the client has not loaded it and entry guidance is needed. If it is unavailable, use the coordinator and skill entries directly. This is a non-standard entry convention, not a guarantee of automatic discovery. Bundled skills use relative Markdown links and named handoffs; load only relevant entries and references.

## Establish the request and context

Identify the actual execution host and available tools at startup, following applicable user and repository instructions. Orientation observes read-only.

For a new development, functionality, review or revision request without sufficient workflow context, use `sdd-manage` to establish project state and select the path. Use [sdd-orient](skills/sdd-orient/SKILL.md) when current repository evidence is insufficient. Select by purpose; new, existing or interrupted state determines the eligible stage, not the workflow by itself.

| Core workflow | Purpose |
| --- | --- |
| Main development | Define and deliver the whole project, reusing sufficient accepted inputs. |
| Feature | Add a bounded capability to an existing system. |
| Revision | Correct, simplify or improve defined or implemented work. Steering is its focused variant at a paused implementation checkpoint. |

Follow the coordinator's [selection and continuity](skills/sdd-manage/references/workflows.md#workflow-selection-and-continuity). At entry or a material routing/boundary change, explain the selected workflow or standalone operation, its request/project evidence, current stage/owner, authorized outputs and next checkpoint in chat.

A request to read/explain a workflow before development uses the coordinator's [workflow-loading operation](skills/sdd-manage/references/workflows.md#workflow-loading): report actual sources, stages/checkpoints, scope and next step in chat, then stop without project changes.

Check scope before work and both the path and proposed change before writes. Honor requested reporting detail: omit unchanged context and routine explanation when brevity is requested, while preserving consequential decisions, blockers, verification and human checkpoints. Use Standard reporting by default; “minimal reporting” or “explicit reporting” selects the corresponding [profile](skills/sdd-manage/references/coordination.md#reporting-profiles). Follow [scope checks and reporting detail](skills/sdd-manage/references/coordination.md#scope-checks-and-reporting-detail); an unchanged turn needs no repeated full brief.

At composite-workflow entry, material switching or context reconstruction, the coordinator uses [Explicit bootstrap reporting](skills/sdd-manage/references/coordination.md#composite-workflow-bootstrap-reporting), briefly explains the profiles and announces Standard for subsequent work unless a human preference is established. Routine continuation does not repeat this introduction.

**Established workflow and skill context normally resolves follow-ups.** A request to implement through a milestone belongs to `sdd-implement` in that context; it does not require plugin re-entry or a repeated selection brief. If context cannot identify a clear workflow/owner, use `sdd-manage` to recover it. Recover discoverable state; ask only for consequential missing decisions. Do not guess lost approvals, ranges or integration authority, or require the user to name lower-level skills.

Preserve narrow direct/standalone requests, pending decisions and unfinished work. Read-only discussion/inspection may proceed without Git; repository mutations require an eligible worktree and do not implicitly initialize Git.

**Product development documents must describe the project, not their preparation workflow.** Apply the [development-document content boundary](skills/sdd-manage/references/human-document-review.md#development-document-content-boundary) to every main/feature root and focused child, in every mode. Keep documentation-pass sequencing, cursor and approval/reset state in DOCS_PREPARATION for main preparation, in FEATURE_PREPARATION for new feature preparation, or revision evidence. DOCS_TASKS holds tasks/checkoffs only. Check these boundaries during authoring and review.

## Human checkpoints and Git publication

**Push every workflow-owned commit and verify remote containment before further work or another commit.** This includes completed documents, tasks, review reports, revision actions and merges. A failed push blocks progression. A retained implementation task completion with known failure or uncertain eligibility first follows [publication preflight](skills/sdd-implement/references/startup-and-continuation.md#push-before-task-work); only bounded authorized recovery/corrective persistence may precede its safe publication. Follow [per-commit publication](skills/sdd-manage/references/git-workflows.md#publish-each-commit); preserve explicit human-directed local-only or deferred-publication exceptions.

**At each necessary document checkpoint, publish the reviewable proposal and its selected artifacts, present substantive results and pause for human acceptance before dependent work unless applicable preapproval covers it.** Model/API-design artifacts share the DECOMPOSITION checkpoint; contract artifacts share SPEC, without extra DOCS/FDOCS tasks or approval rounds. The same checkpoints apply to necessary feature documents/proposals. Reuse sufficient existing inputs rather than creating optional documents to fill the sequence.

For main or feature document preparation, select or recover the [doc-design mode](#doc-design-modes) before applying the document checkpoints below. The selected mode determines which approvals remain active and where its preparation pass stops.

| Human checkpoint | Hold before |
| --- | --- |
| PROJECT / FEATURE | Dependent project/feature design or specification, unless mapped mode/preapproval covers the checkpoint |
| ARCHITECTURE | DECOMPOSITION or contract work |
| DECOMPOSITION | SPEC |
| SPEC | PLAN |
| PLAN | New layout or TASKS |
| layout | TASKS |
| TASKS | Implementation or hosted task projection |
| Requested implementation range completed | Any task beyond the requested count, milestone, phase or named checkpoint |
| Steering amendment completed | Resuming implementation |
| Assessment-only review completed | Repairs or revision execution |

**The human defines the implementation range and decides what follows it.** Commit each task’s verified result, evidence and initial completion checkbox together, then push and verify remote containment. At the end of the requested range, report the boundary results and stop. Do not add ready tasks, review tasks or another phase beyond the selected range. The human may request continuation or steering; start neither automatically. Partial main phases push and pause without merging. A complete phase or feature integrates only when its established verification and scope gates are met.

**The human may preapprove future checkpoints at any point, individually or as a scoped set.** Retain that decision through interruptions; report covered results without repeated approval pauses. Preapproval preserves QC, publication/tracking gates and the authorized implementation range. See [future-checkpoint preapproval](skills/sdd-manage/references/human-document-review.md#future-checkpoint-preapproval).

Clarification, agent QC, passing tests and commits/pushes do not constitute human acceptance. Broad development authority does not preaccept unseen documents or expand a selected implementation range. Preserve pending decisions after interruption. See [document review](skills/sdd-manage/references/human-document-review.md) and [implementation checkpoints](skills/sdd-implement/references/completion-and-checkpoints.md#parent-completion-and-stopping).

## Requested backend tracking

**For fresh/resumed main preparation, enabled tracking precedes repository modifications:** use [main preparation](skills/sdd-manage/references/main-preparation.md) for the native `sdd-docs-main` milestone and all nine issues defined in bundled JSON before writes. DOCS_TASKS holds the nine task definitions/checkoffs; DOCS_PREPARATION owns mode/pass, decisions and evidence. Publish each accepted-document/preparation-evidence/checked-task commit before issue closure; ordinary later edits retain completion, while an explicit cursor reset reopens DOCS-002–009 for a new pass. Final QC issue closure → verified/published docs merge → milestone closure → final preimplementation checkpoint. This is separate from implementation phase activation.

Feature preparation tracking uses a separate campaign milestone and nine FDOCS issues before writes, under [its preparation contract](skills/sdd-manage/references/feature-preparation.md); it does not reuse main DOCS objects or product phase labels.

### Implementation tracking

**When tracking is requested, prepare and maintain hosted objects throughout task-list-based implementation.** Use `sdd-manage` to coordinate and `sdd-forge` for GitHub issues, labels and milestones, or supported provider equivalents.

- **Before execution:** create/reconcile the eligible phase's phase label, all milestones and all task issues, including review/report tasks. On GitHub, use milestone objects and verify each issue's phase label and milestone association. Use milestone labels only where the provider lacks native milestones and its backend defines equivalent completion/reconciliation semantics. Missing or unverified objects block affected implementation. Activate later phases only when eligible.
- **During execution:** project added tasks and update changed associations before their execution. After each task is verified, committed and pushed, close its issue with evidence. Close milestones only after all constituent issues, required reviews and exit conditions are complete.
- **After amendments or interruption:** reconcile actual hosted state, reuse existing identities, finish pending operations and reopen affected issues/milestones when acceptance is invalidated.
- **At each implementation checkpoint:** report tracking status and unresolved operations. Provider failures preserve local results but do not waive required projection or dependent closure gates.

Follow [phase activation](skills/sdd-manage/references/phase-activation.md) and the [tracking lifecycle](skills/sdd-conventions/references/backend-object-lifecycle.md).

## Skill routing

This capability directory identifies owners, including skills normally activated within a workflow. It does not replace their procedures or interpret every contextual follow-up.

| Capability | Owner and entry |
| --- | --- |
| Workflow selection, coordination, branches, credentials and transitions | [sdd-manage](skills/sdd-manage/SKILL.md) |
| Read-only repository/instruction state and interruption inspection | [sdd-orient](skills/sdd-orient/SKILL.md) |
| Modularity, design review, task hierarchy and shared conventions | [sdd-conventions](skills/sdd-conventions/SKILL.md) |
| Project brief, architecture, component APIs and model design | [sdd-design](skills/sdd-design/SKILL.md) |
| Behavior, interfaces, contracts and acceptance requirements | [sdd-specify](skills/sdd-specify/SKILL.md) |
| Delivery strategy, milestones, dependencies and physical layout | [sdd-plan](skills/sdd-plan/SKILL.md) |
| Executable tasks, dependencies and task-list review | [sdd-tasks](skills/sdd-tasks/SKILL.md) |
| Bounded task-range selection, implementation and resumption | [sdd-implement](skills/sdd-implement/SKILL.md) |
| Human-directed amendment at a paused implementation checkpoint | [sdd-steer](skills/sdd-steer/SKILL.md) |
| Accepted feature incorporation and task-ownership reconciliation | [sdd-integrate-feature](skills/sdd-integrate-feature/SKILL.md) |
| Test strategy, scenarios and test changes | [sdd-tdd](skills/sdd-tdd/SKILL.md) |
| Checks, failures, acceptance coverage and boundary code review | [sdd-verify](skills/sdd-verify/SKILL.md) |
| README, guides and module/API documentation | [sdd-docs](skills/sdd-docs/SKILL.md) |
| Issues, commit/merge messages and evidence-backed reports | [sdd-report](skills/sdd-report/SKILL.md) |
| Git highlights, release messages/packages and hosted tracking/releases | [sdd-forge](skills/sdd-forge/SKILL.md) |

Name the next owner and preserve accepted inputs, actual context and the stopping boundary; use its handoff procedure. A sibling reference supplies shared guidance without selecting that skill's entire workflow. Execution handoffs depend on client facilities.

## Composite workflows

The [canonical catalog](skills/sdd-manage/references/workflows.md) owns definitions and transitions. These summaries show principal stages, owners, outputs and stops; implementation and release operations can also be selected independently within scope.

### Doc-design modes

Main and feature document preparation support the following mapped selections. Load [mode and pass control](skills/sdd-manage/references/doc-design-modes.md) before applying a selection or handling a cursor reset; it owns approval/delegation, retained-document revision, reset and recovery rules.

| Selection | Approval and pass boundary |
| --- | --- |
| **interactive/onepass** (default) | Each necessary document checkpoint remains active unless explicitly preapproved; follow the selected preparation range. |
| **autodoc/onepass** | Approve PROJECT or FEATURE; later applicable document checkpoints through TASKS/FEATURE-TASKS are preapproved. Stop at DOCS-008/FDOCS-008 before package QC. |
| **autodoc with human-controlled multipass** | Approve the mapped brief each pass; later applicable document checkpoints are preapproved. After the document pass, wait for reset or advance direction. |
| **autodoc/autoloop** | Use predefined scope passes: first mapped brief approval remains active; announce that later brief approvals are waived. Run the agreed passes, then stop after final DOCS-008/FDOCS-008 before package QC. |

Predefined autodoc scope sequences default to autoloop unless human-controlled multipass is requested. New material autoloop decisions are delegated to agent judgment with visible rationale while proceeding. A cursor reset retains documents and reopens mapped DOCS-002–009 or FDOCS-002–009 and their existing issues; mode selection preserves required QC, publication and tracking gates.

Multipass delivery is **strict by default**: later passes preserve earlier phase/task ranges. **Explicitly permitted flexible multipass** may integrate small changes fitting an earlier pass's scope into its corresponding range. This choice is independent of approval/loop control; [mode details](skills/sdd-manage/references/doc-design-modes.md#multipass-delivery-modes) govern selection, retention and planning/task review.

### Project preparation and bounded delivery

`PROJECT.md` is the concise project brief: purpose, users, outcomes, scope/non-goals and consequential constraints, with material assumptions/questions identified. Use `sdd-design`'s [brief contract](skills/sdd-design/references/project-brief.md); PROJECT supplies context rather than architecture or exact SPEC behavior.

[Main preparation](skills/sdd-manage/references/main-preparation.md) starts with DOCS-001: preserve existing root guidance/disclosure/discovery files, copy missing ones and publish initialization. Mixed initial presence requires a named retained/copied warning and a continuation pause unless explicitly preapproved; none/all present adds no pause.

Main preparation routes `sdd-manage`/`sdd-orient` → `sdd-design` (PROJECT, ARCHITECTURE, DECOMPOSITION) → `sdd-specify` (SPEC) → `sdd-plan` (PLAN, layout) → `sdd-tasks` (TASKS), with `sdd-conventions` as needed. Existing work enters at the next eligible stage; requested interactive review comes first. Apply the [human checkpoints](#human-checkpoints-and-git-publication) and [document QC](skills/sdd-manage/references/document-qc-gates.md).

Completed main preparation includes DOCS-009 whole-package QC and published documentation integration, then `sdd-docs-main` milestone closure and the final implementation checkpoint. Autodoc stops earlier at DOCS-008; advancing to package QC is separate. Otherwise completed preparation-only stops at that final checkpoint; an authorized implementation handoff requires accepted preparation to be integrated, verified and published to the actual default branch before creating the dependent branch; see [preparation integration](skills/sdd-manage/references/branch-management.md#preparation-integration-gate).

### Task implementation and continuation

`sdd-implement` selects and executes the authorized range, composing `sdd-tdd`, `sdd-docs` and `sdd-verify`, with `sdd-report` for evidence/messages. `sdd-manage` establishes the [tracking decision](skills/sdd-manage/references/tracking-decision.md) and [phase activation](skills/sdd-manage/references/phase-activation.md); `sdd-forge` maintains confirmed hosted effects.

Follow [task completion and recovery](skills/sdd-implement/references/completion-and-checkpoints.md) and the prominent [publication/range stops](#human-checkpoints-and-git-publication). Finish pending work before advancing. Requested tracking and unresolved dependent effects retain their gates; partial main phases push and pause, while complete verified phases use eligible integration.

### Feature preparation, execution and incorporation

`sdd-manage`/`sdd-orient` establish the bounded addition and accepted main inputs. Feature preparation follows the shared interactive/autodoc/multipass policy mapped through [FEATURE, task-only FEATURE_DOCS_TASKS and FEATURE_PREPARATION](skills/sdd-manage/references/feature-preparation.md). First FEATURE approval precedes dependent stages unless preapproved; assess unchanged design/layout for reuse. Autodoc stops after FDOCS-008 before FEATURE-QC-REPORT/package QC. Completed preparation passes FDOCS-009, verified/published preparation integration and selected preparation milestone closure before its implementation checkpoint. Design/specification/planning/task owners produce only necessary deltas, with human checkpoints and QC. Accepted preparation integrates before the dependent implementation branch; FEATURE-TASKS drives its authorized range through `sdd-implement`.

Use [feature phase delivery](skills/sdd-manage/references/feature-delivery.md) for the retained campaign branch, complete-phase integration and continued later scope. Incomplete phases pause; completed phases incorporate only their selected delivered delta and verify/publish the receiving target. Final campaign completion alone permits eligible final archive. Before final feature verification, `sdd-integrate-feature` incorporates accepted deltas within the selected scope. Task transfer needs both owning lists in scope; document-only incorporation does not authorize execution. A complete coherent feature verifies/integrates/publishes its established target, then stops. Follow [feature incorporation](skills/sdd-integrate-feature/SKILL.md).

### Review and accepted revision

`sdd-manage` establishes source, concerns, evidence mode and boundary; selected owners assess, with `sdd-report` retaining located findings. Systematic reviews plan units; focused reviews may use prompt-defined criteria. Publish authorized report checkpoints and stop before repairs unless execution is included.

Accepted revisions route bounded changes to owners and `sdd-verify` for rechecks. Integrate only the complete authorized verified boundary. [Review/revision](skills/sdd-manage/references/review-and-revision.md) owns the procedure; [nested/reopened modes](skills/sdd-manage/references/revision-modes.md) preserve parent/return context and opening provenance. Do not automatically resume a suspended parent.

### Checkpoint steering

At a paused implementation checkpoint, `sdd-manage` routes the human-defined amendment to [sdd-steer](skills/sdd-steer/SKILL.md). Assessment-only returns impact. Commanded execution reconciles existing documents, code, tests and documentation without feature overlays or an obligatory formal campaign; verify/commit/push and integrate/verify/publish into the paused target. Return control without resuming `sdd-implement`.

### Release preparation and publication

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before any release tag, publishing trigger, upload or publication, require an executed [artifact-name check](skills/sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) over the complete actual inventory. No type/extension may be skipped. Failures require persistent producer/code/docs repair, source publication, rebuild and recheck before continuing the authorized release.

`sdd-manage` routes [highlights-only](skills/sdd-forge/references/release-highlights.md) versus [complete messages](skills/sdd-forge/references/release-message.md) through `sdd-forge` and `sdd-report`. Complete preparation refreshes retained notes, preserving human curation and explicit template/path or supplied-text scope. Root RELEASE-NOTES.md is the default final destination; release documents may be committed within the active revision directory and moved in the release commit. Complete required Git persistence of owned ignore/tracked-note changes; stop before tagging or hosted release publication.

An authorized release verifies notes coverage/context and version; version match alone is insufficient. The tag targets a verified release commit on the actual default branch: either a direct commit or the merge from its designated primary development branch. Its body and GitHub body use the exact finalized Markdown. Follow [release Git boundaries](skills/sdd-manage/references/git-workflows.md#release-commit-and-tag) and the [GitHub release owner](skills/sdd-forge/references/github.md). `sdd-verify` checks actual release evidence; reports distinguish prepared, Git-published and hosted-complete states. Package preparation alone does not authorize a release; prerelease review requires explicit selection.

### Focused maintenance and optional hosting

Select independent work through its owner and preserve its narrow outputs. Assessment/checks/drafts do not authorize repairs, task completion, PR creation or release publication. Persist reports or owned changes only within established repository authority; required Git publication still applies.

Hosted-only requests stop after their selected effects. Local work needs no provider credential. Accept supported supplied credentials through [protected handling](skills/sdd-manage/references/credentials.md); do not echo values into generated prompts, source, reports, diagnostics or normal handoffs. Authentication recovery preserves scope and does not bypass policy.

## Branches, integration and continuity

Use the coordinator's [continuity subworkflow](skills/sdd-manage/references/continuity.md) for `docs/dev/HANDOFF.md` and recovery from later records/Git. Milestone/phase review tasks refresh it in their completion commits; revision finalization and parent return refresh their boundaries. Ordinary task commits need no handoff update. At reconstructed startup, inspect unfinished branches against their recorded parents and request the continuation branch unless already selected.

Establish actual working/source/target identities, creation parent and branch-off checkpoint; completed new workflows integrate into that parent and restore its context without automatic task resumption. Preparation uses `design-docs`, main execution uses phase branches, and feature/revision identities follow [branch management](skills/sdd-manage/references/branch-management.md). Prefixes do not establish acceptance or authorize a merge.

For invalid implementation task completions, the manager resolves [forward recovery](skills/sdd-implement/references/completion-and-checkpoints.md#resolve-a-task-recovery) under existing authority; a repaired verification failure alone does not require renewed approval of the original range. Historical composition exceptions remain human decisions. For TASKS/FEATURE-TASKS, follow the [task commit contract and audit](skills/sdd-implement/references/completion-and-checkpoints.md#task-commit-contract): one executable task closes per commit with result/evidence and initial checkbox; exactly one owning task ID leads its subject. DOCS/FDOCS preparation persistence belongs to the coordinator's mapped [main](skills/sdd-manage/references/main-preparation.md) or [feature preparation](skills/sdd-manage/references/feature-preparation.md), not the product implementation audit. Non-task work invents no task ID. Preserve pending/unrelated work; a dirty tree does not authorize reset.

Eligible integration uses an explicit two-parent merge, merged verification and target publication. Partial ranges do not imply complete integration. On conflict, denied publication or uncertain effects, preserve work and reconcile state through [Git recovery](skills/sdd-manage/references/git-workflows.md); never reset or force-push unrelated work. Hosted state follows verified local evidence and the [backend lifecycle](skills/sdd-conventions/references/backend-object-lifecycle.md).

## Campaign records and shared conventions

Use the [campaign convention](skills/sdd-conventions/references/review-campaigns.md) for records and `sdd-report` for evidence/integration summaries. Preserve original opening provenance, accepted scope and return boundaries. Campaign records stay on their revision branch; no preliminary default/design-docs merge is required.

Current owners and active records guide routine work. Closed packages are frozen history: do not load without a specific need, edit or assess later compatibility. Eligible reopening uses the selected coordinator mode.

Apply [Markdown conventions](skills/sdd-conventions/references/markdown-style.md): heading/list/block separation, four-space indentation and one space after list markers. Preserve literals and closed records. Git provides checkpoints; no transaction journal is required.
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/LICENSE
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/PLUGIN.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/README.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/AGENTS_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/AI_DISCLOSURE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/BROWSER_DEV_POLICY.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/DOCS_PREPARATION_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/DOCS_TASKS_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/DOCS_TRACKING_TEMPLATE.json
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/FEATURE_DOCS_TASKS_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/FEATURE_PREPARATION_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/Greenfield Project Prompt Template.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/HANDOFF_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/SDD-MANAGER.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/SKILL_DISCOVERY_PROTOCOL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/WINDOWS_SHELL_POLICY.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/ai-logs/AGENTS_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/ai-logs/EXPLORE_DRIVE_TEMPLATE.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/icon.png
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/logo.png
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/logo.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/playwright.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/vite-worker-loading.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/plugin.json
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/backend-object-lifecycle.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/design-heuristics.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/development-document-qc.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/hosting-tokens.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/markdown-style.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/modularity.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/review-campaigns.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/task-hierarchy.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-conventions/references/workflow-identity.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/references/architecture.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/references/decomposition.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/references/exploration.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/references/feature-brief.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-design/references/project-brief.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/references/in-code-documentation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/references/review-and-findings.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/references/standalone-documentation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-docs-preparation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-feature-preparation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-issue-lifecycle.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-milestone-lifecycle.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-packaging.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-projection.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-release-workflows.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-releases.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-highlights.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-message.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-close.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-close.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project-draft.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project-input.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-project.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/forge-runtime.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/github-client.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/scripts/projection-input.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/references/completion-and-checkpoints.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/references/environment-recovery.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/references/range-selection.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/references/startup-and-continuation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-implement/references/task-execution.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-integrate-feature/references/feature-incorporation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/agent-orientation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/ai-logs.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/branch-management.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/continuity.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/coordination.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/credentials.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/doc-design-modes.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/document-qc-gates.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/examples.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/feature-delivery.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/feature-preparation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/git-workflows.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/human-document-review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/main-preparation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/phase-activation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/prerelease-review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/repository-bootstrap.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/review-and-revision.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/revision-modes.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/tracking-decision.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/workflows.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-auth-recover.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-auth-recover.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-process-supervisor.py
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/git-publish.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/scripts/protected-token.mjs
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-orient/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-orient/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-orient/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-orient/references/inspection-and-handoff.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/references/delivery-plan.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/references/physical-layout.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-plan/references/review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/campaign-artifacts.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/change-kinds.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/completion-reports.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/document-qc-reports.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/object-drafts.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/releases.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/references/change-specification.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/references/review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-specify/references/system-specification.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/references/amendment-execution.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/references/objective-and-impact.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-steer/references/verification-and-stop.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/references/conformance-review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/references/progress-review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tasks/references/task-derivation.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/LICENSE
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/test-first-cycle.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/testing-strategy.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/upstream-provenance.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/writing-good-tests.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/SKILL.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/agents/openai.yaml
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/assets/icon.svg
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/boundary-review.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/check-selection.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/execution-and-evidence.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/failure-assessment.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/release-checks.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-assets.md
/tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py
./AGENTS.md
./README.md
./RELEASE-NOTES.md
./app.py
./scripts/build.py
./scripts/release.py
./tests/test_app.py
./version.json

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/SKILL.md; cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/workflows.md; cat README.md RELEASE-NOTES.md version.json app.py scripts/build.py scripts/release.py tests/test_app.py; git log --oneline --decorate -8; git branch -avv; git remote -v; git ls-files
```

```text
---
name: sdd-manage
description: Coordinate SDD project development, document-design modes, feature preparation, bounded or resumed task implementation, checkpoint amendments, review/revision and accepted feature integration. Use for multi-stage requests, workflow selection or switching, shared prerequisites, branch and phase transitions, human decisions, stopping boundaries and hosted task synchronization. Also coordinate complete release-message preparation, Git release highlights, release package/workflow preparation and GitHub releases, plus hosting credentials and shell authentication recovery.
---

# Coordinate specification-driven development

## Role and scope

Translate the user's objective into a scoped workflow and coordinate the responsible skills. Establish context, select or recover the path, check shared readiness, pass work to its focused owner and return the reached boundary. These instructions support direct coordinator entry without requiring PLUGIN.md; load only the relevant skills and references.

Proactively identify relevant capabilities, unresolved decisions, coordination gaps and blockers at entry, preparation handoff, phase activation and completion. Apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md) to authored or reviewed Markdown, including direct calls.

## Shared gates

- **Authority:** Use the request and established decisions as authorization; proceed with routine work within that scope without repeated confirmation. Discussion, assessment or review alone does not authorize repairs. Check scope/instructions/pending decisions before each work unit and both path and proposed change before a user-file write under [scope checks](references/coordination.md#scope-checks-and-reporting-detail). Enter at the requested eligible stage and preserve the human's actual stopping boundary.
- **Execution host/tools:** Identify the actual execution OS and required tools under applicable user/repository instructions. Reuse sufficient current evidence, preserve orientation's read-only role and report concrete readiness blockers before dependent work. Apply [cross-platform verification scope](../sdd-verify/references/check-selection.md#cross-platform-artifacts-and-native-verification): unavailable target-native execution is out of scope by default, not a blocker to requested artifact delivery or remaining implementation.
- **Git and pending work:** Repository mutations require an eligible worktree and established change ownership. Read-only discussion/inspection can proceed outside Git. Preserve valid and unrelated work; dirty state alone does not justify reset. Apply [coordination prerequisites](references/coordination.md#establish-scope-and-prerequisites).
- **Continuity:** Load [checkpoint and recovery](references/continuity.md) at composite entry/reconstruction, milestone/phase review, revision finalization and nested/steering return, including focused calls affecting an active workflow. Maintain `docs/dev/HANDOFF.md` at those boundaries; recover later work from owning records and Git, without per-commit handoff updates.
- **Document content:** Enforce the [development-document content boundary](references/human-document-review.md#development-document-content-boundary) for every main/feature root and child, in every mode. Documents describe the project; DOCS_PREPARATION owns main-preparation mode/pass/cursor, decisions and evidence, while DOCS_TASKS contains tasks/checkoffs only. Other workflows retain their existing evidence owners. Carry this condition into author/reviewer handoffs.
- **Doc-design mode/pass control:** Before main or feature document preparation, select or recover **interactive/onepass** (default), **autodoc/onepass**, **autodoc with human-controlled multipass**, or **autodoc/autoloop**. Load [mode and pass control](references/doc-design-modes.md) at that selection and carry its approval/delegation basis, current scope/pass and stop into the document-owner handoff. Multipass delivery is **strict by default**, preserving earlier phase/task ranges; only explicit human permission selects **flexible** integration of small, fitting changes. Retain and hand off this independent choice. Predefined autodoc scope sequences default to autoloop unless human-controlled multipass is requested; do not infer future scopes.
- **Human document review:** Apply the selected mode and explicit scoped preapproval; otherwise pause after each necessary new FEATURE, PROJECT, ARCHITECTURE, DECOMPOSITION, SPEC, PLAN, layout and TASKS proposal under [human document review](references/human-document-review.md). Broad workflow authority does not preaccept new documents. Reuse acceptable existing inputs without mandatory interactive replay.
- **Release artifact names:** **Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** For an authorized release, require the executed [naming gate](../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) over every actual artifact before tagging, dispatch, upload or publication. Missing/failed evidence returns to producer repair and rebuild; an expected list or checksum pass cannot waive this gate.
- **Publication:** [Push/read back every owned commit](references/git-workflows.md#publish-each-commit) before further work or another commit, including direct focused calls. Use the [supervised HTTPS publication entry](references/git-workflows.md#monitor-pending-git-operations) from the first attempt, with deterministic supplied-token/existing-auth selection; diagnose a stall without waiting for a human prompt. Unresolved publication blocks progression; the linked task-recovery exception permits only necessary correction/check/evidence work for an unsafe retained completion. Explicit scoped local-only/deferred instructions remain exceptions.
- **Task closure:** For TASKS/FEATURE-TASKS implementation, enforce the [task commit contract](../sdd-implement/references/completion-and-checkpoints.md#task-commit-contract): one executable task's verified result, evidence and initial owning checkbox close together. The implementation owner performs closure and the bounded [audit](../sdd-implement/references/completion-and-checkpoints.md#task-persistence-audit-and-recovery) on continuation and before applicable integration; resolve violations only within actual recovery authority. DOCS_TASKS initialization, first approvals and package QC follow [main preparation](references/main-preparation.md) under coordinator ownership.
- **Requested tracking:** Before implementation handoff, establish the [tracking decision](references/tracking-decision.md) and [phase activation](references/phase-activation.md). An explicit request is confirmation. Required objects/associations must be verified; pending or unknown projection blocks dependent execution. Pass the actual decision/readiness or blocker to the owner.
- **Preparation:** [Merge, verify and publish accepted preparation](references/branch-management.md#preparation-integration-gate) into the actual default branch before dependent implementation branching. Campaign plans/reports retain their revision branch.
- **Integration and stops:** Use the [eligible Git boundary](references/git-workflows.md): incomplete main phases push/pause; integrate only complete authorized boundaries. Human-requested implementation ranges define stops. Steering returns without task resumption; a completed child does not authorize parent continuation.
- **History:** Preserve [closed campaign records](../sdd-conventions/references/review-campaigns.md#closed-campaign-records) outside routine loading and validation; consult selected history only for a specific need. Load [revision modes](references/revision-modes.md) before nested work or selected eligible reopening, preserving suspension/return and actual authority.
- **Main preparation:** Load [main preparation](references/main-preparation.md) before any fresh/resumed main documentation repository write: enabled `sdd-docs-main` projection precedes writes; DOCS_TASKS owns the task definitions/checkoffs and DOCS_PREPARATION their control/decision evidence; published documentation integration precedes milestone closure and the final implementation checkpoint.
- **Bootstrap:** Load [repository bootstrap](references/repository-bootstrap.md) before greenfield exploration or the first SDD persistence operation; reuse valid disclosure/usage records and respect selected path limits.

## Coordination cycle

1. **Establish or recover the baseline.** Identify the project, objective, requested operation, authoritative inputs and stop. Reuse sufficient current evidence; obtain **sdd-orient**'s scoped repository/instruction/Git/pending-work observations where missing or stale. Establish that evidence before selecting and announcing the path. Refresh it only when material state or scope changes.
2. **Select, load and explain the path.** Apply [workflow selection and continuity](references/workflows.md#workflow-selection-and-continuity): choose the core workflow/variant or standalone operation, assess continuation, stage/range change or switching, and load its governing instructions before the definitive evidence-backed decision in chat or dependent work. Honor requested reporting detail and [profile](references/coordination.md#reporting-profiles) (Standard by default) while keeping consequential decisions and checkpoints visible under [reporting guidance](references/coordination.md#scope-checks-and-reporting-detail). At composite-workflow entry/switch or context reconstruction, use [Explicit bootstrap reporting](references/coordination.md#composite-workflow-bootstrap-reporting), explain available profiles and announce the subsequent level. Preserve narrow requests and ask only for consequential missing decisions. Routine unchanged continuation reuses its selection.
3. **Establish readiness and hand off.** Follow the [coordination protocol](references/coordination.md), applying the shared gates before dependent authoring/execution. Carry the actual scope, authority, accepted inputs, readiness, unresolved decisions and stop; load the selected owner's instructions. **sdd-implement** owns range selection, task execution and persistence; **sdd-steer** owns checkpoint amendments; **sdd-integrate-feature** owns accepted feature reconciliation. Report unavailable capabilities rather than claim they ran.
4. **Assess results and blockers.** Collect actual outputs, evidence, changed state and remaining differences under [coordination execution](references/coordination.md#coordinate-execution). Return repairs and unresolved decisions to their proper owner; governing-document amendments raised by **sdd-docs** remain with the human before authoring. A standalone verification/review does not start implementation.
5. **Persist, integrate and return.** Coordinate non-task repository persistence and eligible integration through [Git workflows](references/git-workflows.md); implementation/steering retain their own commit procedures. Use **sdd-report** and [return results](references/coordination.md#return-results) to distinguish planned, implemented, verified, committed, pushed and hosted states, report limits/pending decisions and stop at the authorized boundary.

## Reference routing

Use each reference's scope and load conditions below to select it before reading its contents.

### Context and coordination

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [workflows.md](references/workflows.md) | Core workflow/variant selection, read-only workflow loading, continuity, supporting operations and release dispatch | Workflow context is insufficient, a workflow explanation/loading is requested, a request may change the path/stage/stop, or highlights, complete messages, packaging or release publication is requested |
| [coordination.md](references/coordination.md) | Shared prerequisites, scope checks/reporting profiles, handoff payload, execution/persistence, results and environment recovery; focused skills retain their procedures | Coordinating scope/reporting, readiness, a handoff, blockers, non-task persistence or returned results |
| [examples.md](references/examples.md) | Representative requests and expected boundaries; examples do not grant authority | Checking a request interpretation or workflow boundary against a representative case |

### Preparation and adoption

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [agent-orientation.md](references/agent-orientation.md) | Root AGENTS.md maintenance preserving governing instructions | Creating/maintaining target-project orientation or updating affected instruction links |
| [feature-delivery.md](references/feature-delivery.md) | Feature phase/campaign branch mapping, incremental incorporation, phase integration/release and continuation | Selecting feature execution or crossing a feature phase/final integration boundary |
| [feature-preparation.md](references/feature-preparation.md) | Feature brief/records, FDOCS progression, mapped modes/reset, package QC, tracking and preparation handoff | Opening/resuming feature preparation or recording its decisions/acceptance |
| [main-preparation.md](references/main-preparation.md) | Main-only pre-write tracking, task/preparation-record ownership and adoption, initialization, approval persistence, package QC and final integration/checkpoint; document owners retain authoring | Entering/resuming main preparation, before its first repository write or a document completion/integration handoff |
| [repository-bootstrap.md](references/repository-bootstrap.md) | Initial exploration and disclosure/usage records; no implicit Git initialization | Before greenfield exploration or the first target-repository SDD commit |
| [ai-logs.md](references/ai-logs.md) | Manual-provenance scaffold setup and recovery; conversation recording remains manual | Before default provenance setup within DOCS-001, an explicit provenance request or recovery of an adopted scaffold |
| [human-document-review.md](references/human-document-review.md) | Development-document content boundary, entry review choice, new-document HIL and acceptable existing inputs | Authoring/reviewing development documents in any mode, entering/resuming preparation or resolving a pending/requested human review |
| [doc-design-modes.md](references/doc-design-modes.md) | Approval/loop selection, strict/flexible delivery preservation, stops, reset and pass recovery; main preparation retains task/QC ownership | Selecting/resuming main doc-design, revising prior-pass delivery ranges, reaching DOCS-008, or handling reset, predefined scope passes or mode steering |
| [document-qc-gates.md](references/document-qc-gates.md) | Technical SPEC/PLAN/layout/TASKS readiness, distinct from human acceptance | Before dependent preparation, implementation or hosted projection, or when affected inputs need reassessment |

### Execution and continuity

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [continuity.md](references/continuity.md) | Repository checkpoint, branch selection, recovery since checkpoint and parent return; focused owners retain their procedures | Entering/reconstructing a composite workflow, refreshing its checkpoint, returning from child/steering work or preparing a transfer |
| [branch-management.md](references/branch-management.md) | Actual branch identities, setup, preparation integration and phase transitions | Creating/reusing workflow branches or changing an integration/phase boundary |
| [git-workflows.md](references/git-workflows.md) | Per-commit publication, bounded operation monitoring, verified integration/recovery and release commit/tag persistence | Before publication/readback, when a pending Git operation needs diagnosis, or for eligible integration, Git/host recovery or release persistence |
| [credentials.md](references/credentials.md) | Deterministic Git credentials, repository token handling and helper/Git/API recovery; authentication is not operation authority | Before supervised HTTPS publication or credential handling/recovery; routes the bundled Node/Python publication utility and preserves pre-write gates |
| [tracking-decision.md](references/tracking-decision.md) | Optional hosting recommendation/confirmation and retained scope; separate from projection readiness | Establishing/recovering tracking choice before implementation handoff or handling an omitted requested gate |
| [phase-activation.md](references/phase-activation.md) | Eligible-phase hosted object/association verification and transition gates | Activating or reassessing required projection before task execution or a phase transition |

### Review and revision

| Reference | Scope and boundary | Load when |
| --- | --- | --- |
| [prerelease-review.md](references/prerelease-review.md) | Explicit comprehensive prerelease review and advisory reminder; reminder does not activate review | A comprehensive prerelease review is selected or its release-readiness reminder is due |
| [revision-modes.md](references/revision-modes.md) | Nested parent suspension/return and authorized eligible reopening; ordinary history stays frozen | Opening work within an active campaign or selecting a closed-campaign amendment |
| [review-and-revision.md](references/review-and-revision.md) | Scoped review, accepted revision planning/execution and campaign evidence; assessment is distinct from repair | Planning/coordinating a review or accepted revision campaign, including direct focused amendments |
# Available workflows

Select by the user's objective, not by which documents happen to be missing. A scoped request may enter any stage whose required inputs are established. A combined request may authorize preparation and implementation together; retain its explicit implementation boundary. Do not require fresh approval for a transition already covered by that request.

## Workflow selection and continuity

Apply at a development/functionality/review/revision request when no sufficient workflow context exists, and when a later request may change the active objective, scope or stopping boundary. The human need not name a skill or core workflow.

1. **Recover context.** At initial/reconstructed composite entry, apply [continuity](continuity.md) for branch discovery/selection and recovery from HANDOFF plus later records/Git; reuse an explicit or established branch choice. Use the request and established decisions; obtain `sdd-orient` evidence only where current project state is missing or stale. Distinguish a new project from existing or interrupted work, and recover the active workflow, stage, accepted inputs, pending human decisions, task range and unfinished owned work. Greenfield/brownfield is starting context, not a compulsory workflow choice.
2. **Select the path.** Apply the core definitions below. Whole-project definition/delivery uses main development; a bounded capability addition uses feature; review/correction/improvement uses revision. For main or feature document preparation, select or recover [doc-design mode/pass control](doc-design-modes.md) before routing document work; retain that selection when determining approvals and stops. A human-directed amendment at a paused implementation checkpoint uses revision's steering variant. Preserve a narrow standalone operation or direct owner request when a full workflow is unnecessary. Treat explicit user selection as controlling within supported scope; ask only for a consequential ambiguity that prevents a sound selection.
3. **Assess continuity.** Determine whether the request continues the workflow, changes its stage/range, or switches workflows. A correction during preparation can remain with its current owner; a bounded addition does not require restarting main development. Do not switch from filenames, branch prefixes or missing documents alone. Before a switch, preserve pending work, authority and human checkpoints; apply the relevant branch/revision-mode procedure, including parent suspension/return where applicable. A switch cannot accept pending documents, widen scope or resume paused implementation.
4. **Load, report and route.** Load the selected workflow or operation instructions and relevant dependencies before stating its definitive procedure/checkpoints or beginning dependent work. Preserve a provisional selection as such while resolving instruction availability. Before dependent authoring/execution, give a concise user-visible chat brief: workflow/variant (or standalone operation), continuation/stage-change/switch decision and its request/project evidence, current stage and owner, authorized outputs and next human checkpoint/stop. Cite relevant paths or observed state; distinguish facts from uncertainty. At composite-workflow entry, material switching or context reconstruction, apply [bootstrap reporting](coordination.md#composite-workflow-bootstrap-reporting): announce Explicit, briefly explain profiles and state the subsequent level before dependent work. Visible progress commentary may carry the brief; hidden reasoning does not. Use only the selected owners and needed references, then act within the established boundary without another routine approval question.

Reuse an applicable selection and sufficient evidence on routine continuation; repeat the brief when the routing decision or authorized boundary materially changes. Use [scope checks and reporting detail](coordination.md#scope-checks-and-reporting-detail) for operational checks and adaptable event-based reporting; no per-response preamble, new journal or mandatory selection file is required.

## Core development workflows

Choose among three core workflows by the intended change. They describe purpose and overall path; focused skills and the operation catalog below supply reusable stages. A workflow name grants no authorization or branch destination. Apply **sdd-conventions**' **Workflow identity** and [branch management](branch-management.md) for actual names and target context.

| Workflow | Purpose | Typical path |
| --- | --- | --- |
| Main development | Define and deliver the complete intended project, reusing sufficient accepted inputs when available. | Exploration → PROJECT → ARCHITECTURE → DECOMPOSITION → SPEC → PLAN/layout → TASKS → bounded implementation and verification. |
| Revision | Correct, simplify, or improve previously defined or implemented work. | Review plan when needed → review → review report → revision plan → revision → revision report. |
| Feature | Add a scoped capability to an existing system. | FEATURE + FEATURE_PREPARATION → necessary feature design/specification/plan documents → FEATURE-TASKS → implementation → accepted document incorporation and verification. |

- **Entry:** Main development covers both new and existing projects: greenfield starts with sdd-design's [guided exploration](../../sdd-design/references/exploration.md) before PROJECT, proactively assessing the seed and consequential choices; an existing project may enter at an established stage. Reuse accepted inputs rather than replaying stages.
- **Scope selection:** Main development addresses whole-project definition and delivery. Feature is the usual route for a bounded addition to an existing project; an existing project needing whole-system specification/planning can use main development. Revision addresses corrections to defined or implemented work. Greenfield/brownfield describes starting context, not a separate workflow or compulsory routing rule.
- **Revision scope:** Use [review and revision](review-and-revision.md) for formal campaigns. Use [revision modes](revision-modes.md) for a nested revision’s suspended parent/default return target or a human-authorized eligible reopened campaign amendment. A focused prompt may define review scope or an accepted revision directly; do not invent a preceding review or mandatory artifact stage when it adds no needed evidence.
- **Feature preparation:** Establish the [feature brief and preparation record](feature-preparation.md), with sdd-design owning FEATURE and its first acceptance checkpoint before dependent deltas. Use sdd-design's [exploration](../../sdd-design/references/exploration.md) for consequential uncertainty in the feature delta, reusing accepted project decisions. Return later design questions to that same bounded procedure without replaying initial discovery. Define the scoped feature package on a dedicated design-docs branch before dependent implementation, using only the design, specification, and planning deltas it needs. Explicitly merge accepted project preparation into the default branch before creating the feature implementation branch. FEATURE-TASKS governs active task-list feature work. Reuse sufficient existing design/layout; not every correction needs a feature package.
- **Shared execution:** Implement only the authorized bounded scope. Apply relevant verification and commit/push checkpoints under [Git workflows](git-workflows.md). Main development uses phase branches: partial ranges pause after pushes, complete phases explicitly integrate, and an authorized next phase starts from updated main. Revision/feature and steering use their applicable integration gates. Preparation, assessment, and review stop before implementation unless it is authorized. A narrow task request does not authorize unrelated incorporation or a whole-project campaign.

### Steering as lightweight revision

**sdd-steer** is the focused human-directed revision path at a paused task-list checkpoint, especially for reducing implemented functionality. The human supplies the amendment objective and commands execution. Steering directly updates affected existing documents, code, tests, and documentation; it creates no feature-document layer and requires no feature-document integration step or obligatory formal review/revision campaign.

Steering still verifies, commits/pushes, explicitly integrates into the paused implementation branch, verifies/publishes that target, and reports. It returns control without handing off to or resuming sdd-implement; the human separately resumes the task list. A broader revision may use the formal campaign instead. Steering is a revision variant, not a fourth core workflow.

## Operation catalog

These entries select stages or supporting operations within a core workflow; they can also be requested independently within their stated boundaries.

| Operation | Entry and coordination | Outputs and stop |
| --- | --- | --- |
| Read and explain a workflow before project work | Use the [workflow-loading procedure](#workflow-loading) for the requested main, feature, revision or supporting operation; load only relevant instructions and dependencies. | Chat-only sources actually read, stages/checkpoints, authorized scope and next step. No project preparation or mutation by implication. |
| Prepare initial development | Load [main preparation](main-preparation.md) before any fresh/resumed repository writes: enabled `sdd-docs-main` and all nine issues first, then task-only DOCS_TASKS, the DOCS_PREPARATION control/evidence record and initialization. Apply [doc-design mode/pass control](doc-design-modes.md) to the seven document approvals, cursor reset and DOCS-008 stop before eligible package QC, published integration and milestone closure. Enforce [document QC gates](document-qc-gates.md) between dependent stages, including scoped corrections/rechecks and adjacent reports. Use **sdd-design** and its [project brief contract](../../sdd-design/references/project-brief.md) for PROJECT (concise purpose/users/outcomes/scope/constraints), then ARCHITECTURE and DECOMPOSITION; **sdd-specify** for behavior and acceptance; **sdd-plan** for delivery strategy and layout; **sdd-tasks** for TASKS. Resolve consequential decisions as they arise. | Selected artifacts and open decisions. Completed main preparation includes verified/published documentation integration, then milestone closure and the final preimplementation checkpoint; preparation-only stops before implementation. Explicit earlier stops remain controlling. |
| Prepare a feature | Establish the [required brief/record pair](feature-preparation.md) and obtain applicable FEATURE acceptance before dependent deltas. Enforce [document QC gates](document-qc-gates.md) for the selected feature delta against accepted main inputs. Inspect existing contracts and implementation. Use design deltas where needed, then **sdd-specify**, **sdd-plan**, and **sdd-tasks** for the necessary FEATURE-SPEC, FEATURE-PLAN, and FEATURE-TASKS. Reuse established design and layout where sufficient. | Bounded feature requirements, delivery strategy, and executable tasks. Stop at preparation unless implementation is included in the request. |
| Implement a bounded range | Apply [tracking decision](tracking-decision.md) and [phase activation](phase-activation.md) before executable handoff; requested/confirmed tracking needs verified eligible-phase projection, otherwise report blocked execution. Pass the owning TASKS or FEATURE-TASKS, requested IDs/count/milestone/phase, dependencies, and boundary to **sdd-implement**. It resolves the executable range and coordinates **sdd-tdd**, **sdd-docs**, **sdd-verify**, **sdd-report**, and active **sdd-forge** tracking. | Evidence-backed completed tasks, commits, pushes, and applicable issue closure. For main development, pause on an incomplete phase branch or explicitly integrate the verified full phase. For other workflows, integrate only the coherent authorized boundary. Verify/push applicable targets, then stop; retain branch state on a blocker. |
| Resume interrupted implementation | Pass orientation's identified pending task and evidence to **sdd-implement**. It inspects publication eligibility, then pushes eligible outstanding commits before ordinary task work, even on a clean tree; known-invalid completion enters its bounded recovery exception. It finishes pending work before advancing. Use the established boundary; clarify it if unavailable. | Continuation of the bounded implementation workflow. No separate recovery protocol or automatic reset. |
| Steer at a checkpoint | Use **sdd-steer** for the human-defined focused amendment during partial implementation. An assessment request returns impact only; a command to implement authorizes direct changes to affected existing development documents, code, tests, and documentation. | Assessment, or a verified amendment branch explicitly merged into the paused implementation branch, merged-state verified and target pushed. Create no feature overlay and invoke no feature-document integration step. Stop; the human separately resumes implementation. |
| Integrate accepted feature documents | Pass the accepted sources and explicit target set to **sdd-integrate-feature**. TASKS and FEATURE-TASKS are independently selectable; transferring task ownership requires both lists in scope. Document-only integration does not imply task reconciliation. | Selected main documents incorporated, task relationships reconciled only within scope, source disposition, and external impacts. Stop without executing tasks. |
| Run a review/revision campaign | Use [review and revision](review-and-revision.md) for planned systematic review or prompt-driven focused review, stable findings, accepted revision planning, and authorized execution. Route concerns to focused owners. | Retained campaign plans/reports. Review stops before source changes unless revisions are authorized; implemented revisions finish with verified explicit merge/publication. |
| Run comprehensive prerelease review | When explicitly selected, load the [prerelease profile](prerelease-review.md) and use the existing review campaign lifecycle and focused owners against the pinned complete current product. | Published candidate-specific coverage, findings, readiness and revision proposals; stop before repairs or release unless independently authorized. This review is optional. |
| Review or maintain a selected scope | Route design review to **sdd-design**, behavior review to **sdd-specify**, strategy/layout review to **sdd-plan**, task-list review to **sdd-tasks**, selection-only requests to **sdd-implement**, test strategy or test maintenance to **sdd-tdd**, documentation to **sdd-docs**, and acceptance checks plus read-only milestone/phase implementation code review to **sdd-verify**. Use **sdd-conventions** for relevant criteria. | Findings, evidence, or explicitly requested maintenance. Review and verification do not authorize repairs or completion updates. Stop at the selected scope. |
| Prepare a handoff for another agent | Apply [continuity transfer preparation](continuity.md#explicit-transfer-preparation): reconstruct the checkpoint plus later records/Git, optionally refresh it and verify branch publication and necessary input availability. | Accurate transfer checkpoint/evidence and explicit limits; no fabricated milestone completion, automatic range expansion or additional implementation. Ordinary continuation requires no explicit handoff command. |
| Synchronize hosted tracking | Use **sdd-forge** for the requested projection, association lookup, or issue reconciliation. Use available client authentication first and coordinate credential recovery through the credential protocol when needed; leave provider access checks and object mapping to its backend. | Repository and task-to-issue associations, eligible-phase object creation, verified issue/milestone closures, differences, and access blockers. Stop after the hosted operation. |

## Workflow loading

Use this operation when the human asks to read, load or explain SDD Manager workflows before development. It is distinct from preparing project documents. Greenfield selects the new-project starting context of main development, not a separate core workflow.

1. Identify the requested workflow or operation and the purpose of this loading turn. Use supplied context; recover target-project evidence only when the request needs it. A generic workflow explanation requires no target repository or Git worktree.
2. Read the coordinator entry and selected workflow/operation instructions, including dependencies governing relevant transitions and human checkpoints. Load selectively; do not read unrelated workflows or every reference. If a required source is unavailable, identify that limit rather than claim it was loaded or the procedure is established.
3. Report in chat the repository paths of sources actually read, applicable stage sequence and human checkpoints, authorized work/outputs and exclusions, and the next step. Distinguish the documented path from actual project readiness or approvals. Honor an explicit request for sources even when routine reporting detail is reduced.
4. Stop at the requested loading boundary. Do not create project files, bootstrap records, branches, hosted objects or commits merely to prepare the workflow. Loading instructions neither accepts artifacts nor authorizes subsequent development.

## Release operations

For requested release publication, apply the [advisory prerelease review reminder](prerelease-review.md#advisory-release-reminder) at entry and carry its disposition through the release handoff. The shared policy defines when to remind and how to continue; selecting release work does not select review.

| Request | Route and boundary |
| --- | --- |
| Prepare/draft/assemble/update a release message or release notes | Coordinate [complete message preparation](../../sdd-forge/references/release-message.md): forge supplies validated Git highlights, report assembles applicable ancillary sections, and manage establishes output ownership. Retain body-only notes, refreshing them atomically. Root `RELEASE-NOTES.md` is the default final path; active revision campaigns may commit release documents within their directory for placement during the release commit. No provider, tracking, release/tag writes or dispatch is required. Explicit supplied-text-only editing keeps its narrower scope. |
| Collect/revise highlights since a release | Use sdd-forge’s [shared Git highlights](../../sdd-forge/references/release-highlights.md) before provider selection and sdd-report for curation. Coordinate draft/ignore ownership and exact source coverage. Return the ignored local draft or finalized body; no hosting access, TASKS, release/tag creation or publication is required. |
| Assess a package or develop release packaging/workflow | Use sdd-forge's [package preparation](../../sdd-forge/references/github-packaging.md) and [release workflow](../../sdd-forge/references/github-release-workflows.md) guidance. Coordinate accepted repository edits, meaningful checks, commits/pushes and eligible integration through existing Git ownership. Retain interactive decisions; stop before product release publication unless requested. |
| Create/finish a release or run its established workflow | Pass repository, exact verified source/tag, package set, notes, state/latest policy and authorized effects to sdd-forge's [release lifecycle](../../sdd-forge/references/github-releases.md). Verify/refresh retained complete notes using local provenance and version agreement; coordinate the default-branch release commit (direct or a merge from the designated primary development branch), whose body is the complete message, verify its published first-parent provenance and tag that exact SHA. Create/update shared highlights through the exact source before the new tag becomes a baseline, establish finalized-notes transfer, select one publisher, coordinate any necessary tag/Git work, verify actual outputs and remote state, verify the published complete body before cleaning up only the owned internal highlights checkpoint; retain the complete-message file, then return release URLs/evidence or pending effects. |

Before release tags/triggers/uploads/publication, coordinate forge and verify through the mandatory [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair). A failing name requires authorized repairs to producers and related code/tests/docs, published source, refreshed release provenance, exact rebuild/checksums and revalidation; do not bless the bad expected set or stop at a routine repair report. Continue the authorized release through actual publication/readback, preserving narrow stops, human constraints and existing-tag/immutable recovery.

Release requests do not require TASKS, GitHub tracking activation or automatic phase-end release creation. Existing source/build documentation supplies sufficient contracts for a scoped package request; consequential unresolved choices return to the user, while routine authorized steps proceed. Use sdd-verify's [release checks](../../sdd-verify/references/release-checks.md) and sdd-report's [release reporting](../../sdd-report/references/releases.md). Permission recovery distinguishes workflow-file modification, release writes and workflow dispatch.

## Delivery strategy handoff

Commit preimplementation project artifacts and adjacent QC reports on the designated design-docs branch. Completed main preparation follows [its completion sequence](main-preparation.md#final-package-qc-integration-and-checkpoint); completed feature preparation follows [its mapped sequence](feature-preparation.md#final-package-qc-integration-and-checkpoint). Both include verified/published documentation integration, closure of their selected preparation milestone and the final preimplementation checkpoint. Autodoc’s [pass boundary](doc-design-modes.md#complete-a-pass) stops after DOCS-008 or starts the next predefined reset; it does not select package QC/integration. Other preparation-only paths stop on design-docs; feature autodoc stops at FDOCS-008 before feature package QC/integration, just as main autodoc stops at DOCS-008. Honor explicit earlier, no-merge and local-only limits. Before an authorized implementation handoff, complete [preparation integration](branch-management.md#preparation-integration-gate), then branch from the recorded integration parent containing that published checkpoint; the implementation range still needs authorization. Campaign review/revision records remain on their revision branch and do not require this project-document stage.

Preparation uses **sdd-plan**'s [delivery procedure](../../sdd-plan/references/delivery-plan.md) to bound every phase as a coherent functionality increment; greenfield Phase 1 establishes the simplest sensible usable product. Version scope may span phases and does not select a single phase. Retain complete design/SPEC, justified prerequisites, prior working behavior and scoped exits before **sdd-tasks** derives executable work. A feature or existing system begins with its bounded changed outcome; no new MVP is imposed.

Pass the selected range, owning capability/milestone outcomes, dependencies, verification obligations, and applicable human decision gates into implementation. At consequential checkpoints, return the demonstrated functionality and relevant usability/risk evidence for the human's continue/amend/simplify/stop decision. This does not authorize automatic steering, broaden the selected range, or require approval for routine work already authorized.

## Feature sequencing

At feature initialization, execute/reuse [manual AI provenance setup](ai-logs.md#default-execution-and-overrides) by default, without an opt-in question. Honor explicit opt-out/deferral and use its existing-initialization procedure for missing setup; report/recover enabled blockers. Do not replay completed DOCS-001 or automatically merge manual log changes.

- **Preparation:** Load [feature preparation](feature-preparation.md) for the required FEATURE/FEATURE_PREPARATION pair, decision/acceptance ownership and continuation rules. Establish the convention's campaign/package identity and `design-docs/<campaign>-<slug>` under [branch management](branch-management.md). Record its identity, branch/target and active source links in FEATURE_PREPARATION; preserve another active package in the same worktree. Establish the entry HANDOFF with scope, parent and active package links under [continuity](continuity.md); intermediate approvals stay in FEATURE_PREPARATION, with refresh at completed preparation/integration. Keep feature deltas distinguishable from complete main documents. Creating a feature task list does not require immediate incorporation into TASKS.
- **Implementation:** Apply [feature phase/campaign delivery](feature-delivery.md) for phase segmentation, receiving targets, scoped incorporation and retained future work. Explicitly merge, verify and publish the accepted feature preparation into the default branch before creating `feature/<campaign>-<slug>` from its recorded integration parent containing that checkpoint. If that parent is an active phase, apply the preparation gate's verified propagation step first; final integration returns to the creation parent. Accepted FEATURE-TASKS can then drive implementation while its authoritative feature documents remain active. Identify those sources explicitly in the handoff.
- **Document integration:** Incorporate accepted targets included in the request on the feature branch before final verification and Git merge. A complete feature implementation includes incorporation needed for a coherent final project; a preparation-only or narrow task request does not authorize unrelated incorporation. Do not infer acceptance from passing tests.
- **Archive:** After accepted final incorporation and task/evidence disposition, **sdd-integrate-feature** retains eligible sources under the package directory, repairs selected links, and marks historical snapshots. Partial/narrow integration retains needed active documents; verify archive ownership before final merge.
- **Git integration:** Feature phases use [phase-matched incorporation and integration](feature-delivery.md); incomplete phases push/pause, completed phases integrate and preserve later work, and final campaign completion alone permits eligible final archive. Merge the verified completed boundary into its recorded target explicitly, verify and publish. Completed feature preparation includes its package QC and verified published preparation integration, then stops before implementation unless authorized; autodoc first stops at FDOCS-008 pending explicit advance. The earlier preparation merge is a separate document-only boundary.
- **Consistency:** If the selected work requires an unresolved contract or dependency decision, report it before the dependent mutation. Continue independent authorized work when sound.

## Cross-cutting operations

- **Reporting:** Use **sdd-report** throughout, or independently for an issue, commit message, PR description, or progress report. Drafting PR text does not create or merge a PR.
- **Hosted tracking:** Local workflows remain usable when tracking is not selected; selection makes its gates required for dependent execution. Hosting outages permit independent execution only in an already verified activated phase for projected tasks with satisfied dependencies; preserve verified local results and report pending closure without waiving initial/added-work or transition gates. Apply the shared backend lifecycle: activate/project only an eligible phase before its first task; coordinate committed milestone/phase review tasks and reports, task issue closure and then milestone closure; gate next-phase activation on verified predecessor integration/publication. Use phase activation for the transition. When tracking is active, coordinate task associations before commit composition and verified closure through **sdd-forge**; issue state never supplies completion evidence.
- **Authentication:** Use the [supervised HTTPS publication entry](git-workflows.md#monitor-pending-git-operations) from the first authorized push, with deterministic supplied-token/existing-auth selection. Route access/credential failures to the coordinator's repository-token recovery protocol; preserve distinct Git and API access and the active backend's permission profile.
- **Continuity:** All composite workflows and focused calls affecting them use [checkpoint/recovery](continuity.md). Supporting and release operations return material state/decision changes to the active owner; do not invent task campaigns or change release-message, commit/tag or provider rules to maintain a handoff.
- **Persistence:** Implementation and steering own their commits and pushes. Coordinate persistence of other authorized repository edits through the shared protocol; hosted-only changes have no local commit by implication.

## Optional tracking decision at handoff

Use **sdd-manage**'s [tracking decision](tracking-decision.md) before dependent phase activation. Carry the recommendation, actual confirmation/decline, repository/scope and observed hosted state separately. A supplied GitHub token recommends enabled tracking but does not activate it; unresolved activation choices return to the manager. Reuse confirmed scope without repeated approval. Late confirmation reconciles retained evidence instead of replaying product tasks.

## Human preparation sequence

Use [human document review](human-document-review.md) for both initial and feature preparation. Apply selected [doc-design mode/pass control](doc-design-modes.md) for main/feature preparation and explicit scoped preapproval before determining active checkpoints. FEATURE has its own boundary before dependent feature design/specification. PROJECT, ARCHITECTURE, DECOMPOSITION, SPEC, PLAN, layout and TASKS each have their own boundary; guide the human through necessary new proposals and hold dependent progression only where human acceptance remains required. Feature campaigns review their necessary deltas and reuse sufficient existing main inputs without inventing optional overlays.

At startup or after interruption, assess existing progress and continue from the next eligible stage by default. An explicitly requested interactive review comes first; important issues can prompt a concern and offer. Preserve the selected mode, its stopping boundary and actual pending human decisions. Agent QC and broad continuation authority do not replace required creation checkpoints.
# Orion

Orion returns Hello World and delivers two portable representations, with a checksum list. Users need no development server.

Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under dist/release. The current producer names its outputs orion-1.2.3.opaque and orion-1.2.3. Release version is in version.json. Keep both representations and SHA256SUMS available in every release.

The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. It invokes `/tmp/sdd141-trial-direct/provider.py` and records release/assets/body/latest in `/tmp/sdd141-trial-direct/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
Orion 1.2.3 delivers the Hello World baseline in two portable representations.
{"version":"1.2.3"}
def greeting():
    return "Hello World"
import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1];version=json.loads((root/'version.json').read_text())['version'];out=root/'dist/release'
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True)
names=['orion-'+version+'.opaque','orion-'+version]
for name in names:(out/name).write_text('Hello World; embedded version '+version+'\n')
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in names))
print(json.dumps({'version':version,'artifacts':sorted(x.name for x in out.iterdir())}))
import argparse,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--tag',required=True);a=p.parse_args()
subprocess.run([sys.executable,str(root/'scripts/build.py')],check=True)
subprocess.run([sys.executable,'/tmp/sdd141-trial-direct/provider.py','--repo',str(root),'--source',a.source,'--tag',a.tag,'--directory',str(root/'dist/release'),'--state','/tmp/sdd141-trial-direct/provider-state'],check=True)
import unittest
from app import greeting
class App(unittest.TestCase):
    def test_message(self):self.assertEqual(greeting(), 'Hello World')
7ec357c (HEAD -> main) Prepared controlled product baseline
* main 7ec357c Prepared controlled product baseline
.github/workflows/release.yml
.gitignore
AGENTS.md
README.md
RELEASE-NOTES.md
app.py
scripts/build.py
scripts/release.py
tests/test_app.py
version.json

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/SKILL.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-packaging.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-release-workflows.md
```

```text
---
name: sdd-forge
description: Use when projecting software-development phases, milestones, and tasks to a hosted repository; creating or reconciling GitHub labels, milestones, and task issues; finding an issue for a task ID; or closing verified task issues and milestones, reopening invalidated milestones, or recovering interrupted hosted transitions. Also use for provider-independent complete release-message preparation, Git release highlights and incremental highlights drafts, GitHub release package assessment, release workflow preparation or dispatch, release creation and interrupted release recovery. GitHub is the available backend. Ordinary local Git and SDD work does not require hosting access.
---

# Git release preparation and hosted operations

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

## Shared protocol

- **Feature preparation:** For selected preparation tracking use [GitHub feature preparation](references/github-feature-preparation.md), through the backend prerequisites: campaign-specific milestone/nine FDOCS issues, exact source/readback, mapped pass reset and published integration before milestone closure. FEATURE_DOCS_TASKS holds checkoffs; FEATURE_PREPARATION owns control/evidence. Existing docs-main utilities are not feature projection tools.
- **Main preparation:** Before enabled main documentation repository writes, use [GitHub main preparation](references/github-docs-preparation.md), after its parent backend prerequisites, for `sdd-docs-main` and nine issues from the bundled JSON definitions. DOCS_TASKS contains task definitions/checkoffs; DOCS_PREPARATION supplies active-pass approval/control evidence; explicit cursor reset reopens the same DOCS-002–009 issues under that lifecycle. Autodoc stops leave package QC/milestone completion pending; final milestone closure follows verified published documentation integration. Product PLAN/TASKS and implementation-phase activation are not prerequisites for this separate preparation operation.
- **Scope:** Run only for a requested hosted operation or release/package preparation, including local Git release highlights. Route shared highlights before provider selection; identify the provider before loading a hosted backend; report ambiguous remotes or unsupported providers without guessing. Local preparation/inspection and workflows without selected tracking need no hosted activation; requested/confirmed tracking retains the manager's phase execution gates.
- **Release artifacts:** **Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before tagging, publishing triggers, uploads or publication, enforce the independent [artifact-name gate and repair](references/github-packaging.md#artifact-name-gate-and-repair). Require stable version-free actual names, project-local direct/CI checks and current passing evidence; route failing scripts/related code/tests/docs through authorized repair, source publication, rebuild and recheck, then finish the requested release/readback. Preserve narrower stops and existing-tag/immutable recovery.
- **Hierarchy:** For implementation task tracking, use the **sdd-conventions** task hierarchy to read phase, milestone, and task IDs and names from TASKS or the active FEATURE-TASKS and preserve their parentage in the host projection. The selected backend defines its concrete objects.
- **Coordination:** Before a local draft edit or hosted mutation, **sdd-manage** coordinates the user's request and a current **sdd-orient** handoff establishing the eligible Git worktree and governing instructions. Read-only inspection needs no Git mutation gate.
- **Credentials:** Use the available authenticated client or a suitable supplied token. **sdd-manage** discovers, accepts, and persists tokens under **sdd-conventions**' **Hosting tokens** rules and recovers the affected client's authentication when needed. A direct caller may supply a token to **sdd-forge**. Consume it through a protected mechanism without ordinary handoff/output exposure; Git shell authentication does not prove API-client access. The selected backend defines provider-specific checks and permission requirements.
- **Access failure:** For a backend access-related 403, request a suitable token from **sdd-manage** and return the endpoint, required access, and any provider-indicated non-credential cause without exposing the credential. The coordinator checks credential suitability and identifies any policy or other restriction requiring a different remedy; escalation does not require substituting a token when the existing credential is suitable. For direct use without **sdd-manage**, ask the user. Recheck access before retrying; a replacement token does not establish permission by itself.
- **Operational failure:** Let the selected backend distinguish access failures, rate limits, service/transport outages, invalid requests, and uncertain writes. Preserve successful independent results and return pending/unknown effects with bounded retry or deferred-reconciliation context; do not route every 403 to credential replacement.
- **Handoff:** Return the repository, requested operation, changed objects, checks, access failures and remaining differences. Tracking returns task/issue associations; release work returns package/source/tag, workflow/run, release/assets/URLs and actual latest state. Local file preparation returns changed files to sdd-manage for Git persistence. Hosted state does not itself establish task completion or downloaded-byte verification.

Do not create commits, push branches, or create or merge pull requests here.

Add a backend only when it supports a concrete hosted operation with its own repository resolution, authentication, object mapping, and reconciliation rules. Give it a focused reference and explicit trigger; do not advertise a provider before its workflow is defined.

## Shared release preparation

For requested release creation/completion or a publishing workflow run, apply sdd-manage's shared [advisory prerelease review reminder](../sdd-manage/references/prerelease-review.md#advisory-release-reminder), including direct calls. Reuse its handoff disposition when already covered by the coordinator.

For requests to prepare, draft, assemble or update a release message or release notes, load [complete release-message preparation](references/release-message.md). Coordinate source/output ownership through manage, collect Git highlights, and use report to assemble the full message with applicable compatibility, installation and limitation sections. Retain the complete message, normally finalized at root `RELEASE-NOTES.md`; an active revision campaign may stage it within its directory for placement in the release commit. Preparation stops before publication. Editing-only requests remain scoped to supplied text.

For “collect key changes since the latest release,” highlights-only preparation or incremental highlights, load [Git release highlights](references/release-highlights.md). Pin the release-tag baseline and target, collect complete range identities/parents/subjects, read integration summaries first (latest adequate cumulative summary for reopened campaigns) and resolve direct/uncovered changes with targeted evidence, curate an ignored YAML-checkpointed draft and return body-only notes. No provider, token, tracking or TASKS is required. Release creation consumes this shared workflow; preparation alone stops before publication. Keep draft cleanup tied to verified published-body consumption.

## Available backends

- **GitHub:** Read [GitHub backend](references/github.md) when the requested operation targets a GitHub repository. It resolves repository identity and access, then routes tracking, package/workflow preparation and release lifecycle operations. An available [GitHub CLI](references/github.md#github-cli) may perform supported operations with suitable existing or provided/saved-token authentication. Apply the shared backend object lifecycle for tracking; standalone release requests need no task hierarchy or tracking activation. Package preparation does not implicitly publish a release.

For hosted operations, carry the confirmed request scope, destination/object identity and explicit limits through the [coordination handoff](../sdd-manage/references/coordination.md#coordinate-execution). Keep credentials protected and optional tracking activation separate from access capability.

## Optional local tracking utilities

For canonical-list input authoring and eligible phase or main-preparation projection with local Node 22+ and Git, select the [input-authoring workflow](scripts/forge-project-input.md) and [projection utility](scripts/forge-project.md). Phase drafting extracts structure for agent-authored dependencies/briefs and retains an explicit reviewed request. For routine `docs-main`, prefer the single-call projection entry with repository DOCS_TASKS and origin defaults; its guide defines bootstrap template fallback, explicit overrides and the required apply eligibility confirmation. The agent reviews outgoing content and the coordinator establishes actual eligibility. Preparation drafting before its pre-write gate keeps files outside the target repository. Exact conflicts/unsupported scopes retain the existing backend procedures.

For eligible completed implementation task/milestone reconciliation with local Node 22+, Git and an eligible ignored repository token, the backend can select [forge-close.mjs](scripts/forge-close.mjs) under its [CLI and handoff contract](scripts/forge-close.md). Load the backend and selected lifecycle first; the utility performs bounded mechanics, while execution/coordination establishes actual acceptance/publication and exclusive ownership. Consume known/unknown effects and use reconcile-only for uncertain prior writes. Other clients and unsupported scopes retain their existing backend procedures.

## Supporting modules

Load the [GitHub backend](references/github.md) first for these operations; it supplies identity/access prerequisites and routes the selected module. Load only the relevant support module and its stated dependencies, including for a direct request. Shared local highlights and release-message preparation keep their routes above.

| Module | Purpose and boundary | Route through | Load when |
| --- | --- | --- | --- |
| [github-packaging.md](references/github-packaging.md) | Package contents, archive assessment and names; preparation only | [github.md](references/github.md) | Assessing or developing GitHub release packaging |
| [github-release-workflows.md](references/github-release-workflows.md) | Workflow authoring, dispatch and monitoring within requested effects | [github.md](references/github.md); package contract as required | Preparing, inspecting or running a release workflow |
| [github-releases.md](references/github-releases.md) | Release reconciliation, upload, publication and readback | [github.md](references/github.md); accepted package contract | Creating, completing, inspecting or recovering a release |
| [github-projection.md](references/github-projection.md) | Eligible-phase labels, native milestones and task issues | [github.md](references/github.md) | Creating or reconciling the selected task hierarchy |
| [github-feature-preparation.md](references/github-feature-preparation.md) | Campaign-specific feature preparation milestone/nine FDOCS issues, completion/reset and integration-before-closure | [github.md](references/github.md) | Projecting/reconciling selected feature documentation preparation |
| [github-docs-preparation.md](references/github-docs-preparation.md) | Main preparation milestone/nine issues, current-pass closure, explicit reset reopening and merge-before-milestone completion | [github.md](references/github.md) | Projecting or reconciling main documentation preparation, including its early pre-write gate |
| [github-milestone-lifecycle.md](references/github-milestone-lifecycle.md) | Milestone closure, reopening and backlog reconciliation | [github.md](references/github.md) | Reconciling milestone completion or invalidation |
| [github-issue-lifecycle.md](references/github-issue-lifecycle.md) | Exact task/issue identity and verified issue-state changes | [github.md](references/github.md) | Resolving a task issue or closing/reopening it |
# Prepare a GitHub release package

Use for a supplied ZIP, an existing package/build definition, or an interactive request to develop release packaging. Preparing packages or a workflow does not itself request a product release. Coordinate repository edits and their commits/pushes through **sdd-manage**; this reference supplies the package procedure. Release preparation is independent of optional task tracking and does not require TASKS when no task list governs the request.

## Establish the package contract

1. Use the current orientation and [GitHub repository/access](github.md#repository-and-access) handoff. Identify the intended distributable, source commit, authoritative inputs, requested outputs and stopping boundary. Inspect existing build/release tooling before proposing replacements.
2. Accept an archive or preliminary description as a seed. Establish intended users, archive format, root layout, required files, exclusions, entry points, installation/use expectations, version source and actual variants. Reuse sufficient project instructions and ordinary defaults; ask only for consequential unresolved choices. A platform, runtime or installer choice can require interactive development over several turns.
3. Retain accepted decisions, assumptions and remaining questions in existing build/project documentation or the active record. On continuation, compare those decisions with actual source/output state and resume pending work. Do not invent a registry or replay settled choices.
4. For a simple tracked-source package, an explicit `git archive` inventory may suffice. For compiled/generated content, establish dependency/runtime versions, build steps and the origin of each output. Do not demand that all package members be tracked files. Prefer the same build/verification procedure locally and in CI, with platform-specific differences documented.

## Assess the actual archive

Inspect member names and metadata before extracting; never execute bundled scripts merely to discover the package. Reject absolute/traversal paths, duplicate or conflicting entries and unsafe link targets. Account for extraction limits, archive corruption, encryption, unsupported features and decompression size before extraction into an owned temporary directory. Reject credential material and exclude Git internals, unrelated development records and accidental local outputs. Preserve permitted independent assessment on a defective input.

Compare required and actual members, internal paths, entry points, applicable licenses/notices, metadata/version and executable modes where relevant. For an input ZIP, map members to the selected source or declared generated outputs; it represents an intended layout, not automatically an approved inventory. Distinguish missing required files, intentional exclusions and unexplained extras. Verify installation/import/startup behavior appropriate to the package, without executing untrusted input contents. Route necessary changes through the coordinated work boundary.

Build a candidate from the exact source and inspect its actual output using **sdd-verify**'s [package and release checks](../../sdd-verify/references/release-checks.md). Record member/content comparison, source SHA, version, runtime and SHA-256 hashes. Equivalent layout does not prove identical bytes; reproducible builds require the appropriate repeated-build evidence and control of timestamps/order/modes and other variable inputs.

## Names and URLs

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Check the complete actual artifact inventory; unknown formats, arbitrary extensions and names with no extension are included automatically. This is mandatory, with no exception based on a build tool, file type, expected upload list or checksum result.

Establish the stable expected names independently in existing package/build documentation before generating producers, release scripts or their packaging tasks. Use a stable project basename, extension and only necessary variant suffixes. Version identity belongs in tags and metadata. The following examples illustrate names and do not limit the prohibition's scope:

| Asset purpose | Example |
| --- | --- |
| Single HTML app | `tetris.html` |
| General package | `project.zip` |
| Windows x64 build | `project-windows-x64.zip` |
| Linux ARM64 build | `project-linux-arm64.tar.gz` |
| macOS ARM64 build | `project-macos-arm64.zip` |
| Chromium / Firefox extensions | `project-chromium.zip` / `project-firefox.zip` |
| Separate source package | `project-source.zip` |

Respect established ecosystem vocabulary such as `amd64` where appropriate; examples do not require these variants or extensions. Preserve spelling, case and extension across releases and check uniqueness across the complete variant set. Renaming/removing a public filename is a consequential compatibility decision.

Use these [GitHub latest-release links](https://docs.github.com/en/repositories/releasing-projects-on-github/linking-to-releases):

```text
https://github.com/{OWNER}/{REPO}/releases/latest
https://github.com/{OWNER}/{REPO}/releases/latest/download/{ASSET_NAME}
```

Define the expected asset set for each stable release. The repository-wide latest pointer cannot fall back to an older release for a missing variant. Verify that the latest release includes each advertised asset; drafts/prereleases cannot be latest stable. A private repository's URLs retain its access requirements. Do not promise a universal latest-prerelease alias.

Explicitly attached packages differ from GitHub's automatic source ZIP/tarball downloads and from temporary Actions artifacts used between jobs. Return tag-specific URLs as well when consumers need pinned versions. Use `<asset>.sha256` for a simple package or a stable `SHA256SUMS` for several assets; hashes must describe the actual uploaded bytes.

## Artifact-name gate and repair

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** An actual executed check must reject a prohibited name even when the producer, upload list and checksums all agree. No extension/type allowlist may exclude an artifact. A prose promise or unexecuted check is not evidence.

This gate is mandatory for release/package acceptance, including an established publisher. Before creating/pushing a release tag, dispatching a publishing workflow or uploading/publishing assets, have **sdd-verify** compare actual candidate names with this naming contract, independently of the generator and its expected upload list. A complete inventory with valid checksums still fails when its names violate the contract; copying those names into an expected set does not make them acceptable.

1. Establish the stable basename/extension and only necessary variant suffixes from the product/delivery requirements. Check uniqueness, preserved public spellings, version-free names, checksum entries and advertised latest URLs. Cover raw artifacts: `tetris-v0.5.0.html` fails where `tetris.html` is required. Numeric product identities are not automatically release versions; do not use a blanket ban on digits or a universal suffix vocabulary.
2. Under an authorized release or repair request, route failures to the owning implementation/maintenance workflow. Correct packaging/build/release scripts and related producers/consumers, configuration, tests, checksum generation, installation/release documentation and download links. Repair agent-generated conflicting naming assumptions in current project documents; preserve real human constraints and closed records. Do not merely rename one temporary upload, weaken the gate or report an otherwise routine repair and stop. Read-only or explicit path/effect limits remain controlling; obtain only a genuinely missing decision/authority.
3. Add or reuse a deterministic project-local naming/inventory check in the project's existing stack, using the [executed check contract and optional Python helper](../../sdd-verify/scripts/release-assets.md) where suitable. Its expectation must come from the naming contract, not unchecked generator output. Observe the offending example fail and corrected artifacts pass; check real variant collisions and checksum filename/byte agreement as applicable. Run it before tag creation/push and publishing dispatch, for local/direct publication, and in CI before upload and final publication. A tag-trigger-only builder must expose a build-only path that produces and checks the exact candidate before tagging; an absent local artifact is not permission to skip the gate. A successful build, test count or matching generated manifest is insufficient.
4. Commit/publish/read back the repaired scripts, related code/tests/docs and required source/version changes through **sdd-manage**, completing eligible integration before release. Refresh source-associated notes and the release-commit/tag evidence; rebuild from that exact verified committed source, regenerate checksums and rerun package/naming checks. Never attach rebuilt content from a changed source to an old tag or reuse stale passing evidence. Existing tags/published releases use the [release recovery](github-releases.md#recover-without-duplicate-writes) boundary, including a corrective version/release when required; no tag move, silent asset deletion/clobber or history rewrite.
5. Pass the source, stable expected names, exact-byte hashes and observed check results to the selected publisher. Recheck the complete draft before publication and the actual hosted/latest filenames, checksum contents and stable URLs afterward. A naming failure blocks the corresponding release transition/completion and returns to repair. Continue an already-authorized release through verified publication/readback after repair; package-only, build-only, draft-only and local-only requests retain their actual stops. Do not manufacture a second publisher or another permission checkpoint.

## Prepare and hand off the workflow

Use [release workflow preparation](github-release-workflows.md) to create/extend the appropriate workflow and its build/verification procedure. Return accepted package layout, source/version, asset names and required set, checksums, performed checks, remaining questions and changed files. Stop at the requested preparation boundary. A request to actually release continues through [release creation](github-releases.md); do not publish merely because a candidate archive exists.
# Prepare and run a release workflow

Load after the [package contract](github-packaging.md) is sufficient, or when inspecting/dispatching an established release workflow. **sdd-manage** coordinates repository authoring, verification and Git persistence. **sdd-forge** owns requested GitHub dispatch/monitoring; it does not commit or push the workflow files.

## Author or extend

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Establish independent stable names before writing the workflow. Generate a real failing-before-passing naming check in the existing stack, cover every staged artifact without filtering by type, and require it before uploads/publication. Provide a build-only route for pre-tag candidate verification.

Inspect existing `.github/workflows/` and project build procedures. Reuse a suitable workflow and publishing stage rather than introduce competing release creators. Establish trigger, exact source/tag inputs, build-only versus publication behavior, supported variants, expected asset set and notes/latest/prerelease policy. Keep a simple source ZIP proportionate: an explicit inventory, relevant checks, archive inspection, checksum and one publishing stage may be enough.

Before a publishing tag push or dispatch, complete the [artifact-name gate and repair](github-packaging.md#artifact-name-gate-and-repair), including publication/readback of repaired source and checks against the rebuilt pinned candidate. Generated and reused workflows must:

- Select the exact release source. For tag triggers, use the tag's resolved commit; for manual runs, distinguish the ref containing the workflow from the release source input. Before publication, verify that the pinned release commit is on the actual remote default branch’s first-parent history and the peeled tag/version/source agree under the coordinator’s release boundary. A revision/development tip does not qualify through ordinary ancestry. Keep the workflow execution ref separate; build the pinned release commit even if default later advances.
- Support the accepted tag trigger and/or `workflow_dispatch`, plus build-only validation where needed. A manual dispatch requires the workflow to be present on the default branch and to declare `workflow_dispatch`; verify the selected ref contains the intended workflow. Inspect actual inputs rather than assume their names.
- Use declared runtimes/dependencies and supported actions. Pass user inputs as data through environment/structured arguments rather than interpolate arbitrary text into shell code. Run the meaningful project checks and the agreed package inspection against actual built archives.
- Scope job permissions: build jobs normally need Contents read; the publisher needs Contents write for release writes. PAT Workflows permission enables workflow-file modification; conditional Actions permission enables provider dispatch/run operations. These are separate from job `GITHUB_TOKEN` permissions. Keep credentials out of outputs and package inventories.
- Build every required variant, check nonempty outputs and unique stable version-free names against the independent naming contract, collect the exact asset set and create SHA-256 files. Run the project-local naming/inventory check on actual outputs before upload and before final publication; a versioned raw HTML filename fails just as a versioned archive does. Check checksum entries and documented latest URLs against the same stable set. For a matrix, collect all successful builds before one publisher creates/uploads/publishes the release. Do not upload an unexamined broad glob or silently omit a failed variant.
- Serialize publication for the same repository/tag with an appropriate concurrency group. Avoid cancellation that abandons uploads or races between tag and manual triggers. Define repeat behavior using the [release lifecycle](github-releases.md), not unconditional `gh release create` or `--clobber`.
- Keep build-only runs free of tag/release writes. Record build outputs separately from public release assets. Optional signing, SBOM or provenance steps follow actual project requirements.

A tag pushed with the repository's `GITHUB_TOKEN` does not normally trigger another push workflow. Follow [GitHub's token event rules](https://docs.github.com/en/actions/concepts/security/github_token): build/publish in the same intended workflow or use a supported dispatch route; do not claim the chain ran without evidence. Do not change accounts/tokens to evade a host denial.

If an existing workflow or packaging script produces nonconforming names, repair its producers and related code/tests/docs, publish the corrected source, rebuild and repeat the gate under the existing release authority. Do not patch only a temporary upload or stop after identifying the problem; preserve the requested effects and published-tag recovery boundaries.

Verify syntax with suitable tooling, inspect permissions/inputs/checkout identity and execute the local build/verification where supported. Use [release checks](../../sdd-verify/references/release-checks.md). Distinguish a parsed YAML file, successful local package build, actual CI run and hosted release verification. GitHub Actions syntax and runtime compatibility are not proved merely by YAML parsing.

## Notes transfer

Use [complete release-message preparation](release-message.md) to assemble final body-only notes, using [shared Git highlights](release-highlights.md) for changes and authoritative inputs for ancillary sections, through the exact intended source before dispatch or a publishing tag push. Select the previous baseline before creating the pending release tag, or explicitly exclude that tag; retries retain the validated prior baseline. Complete semantic editing on the agent side. On release requests, apply the [message freshness/release-commit gate](release-message.md#release-request-freshness-and-commit-gate): verify local coverage and stated version, tag the verified release commit and transfer its complete message body. Build-only/package preparation does not create a release marker. An ignored local draft is absent from checkout, and ordinary Actions runners do not implicitly supply an AI agent. If a workflow collects Git evidence itself, establish complete tags/history (a default shallow checkout is insufficient), but deterministic log collection is not semantic distillation.

Inspect the existing publisher’s declared mechanism. For manual dispatch, a declared string notes input can carry the finalized Markdown via a supported structured/JSON input file; the publishing job must consume that value as data through a notes file/API body, not shell interpolation. Check input size limits and preserve multiline bytes. For larger notes or tag-only workflows, establish an authorized source-associated artifact/file transfer with explicit retrieval and integrity/identity checks; never assume the ignored draft was pushed. Keep YAML control data out of the final body. Do not add an untrusted arbitrary download/execute mechanism.

If the existing workflow has no supported notes transfer, extend and verify it before triggering publication or return the prepared handoff as pending. Generated notes alone do not satisfy requested curated highlights. Reuse one publisher, preserve human notes, avoid duplicate highlights and retain the internal highlights checkpoint until published-body readback confirms consumption. Build-only or failed runs retain it. The complete-message file remains after all outcomes, including verified publication; refresh/replace it on the next preparation. Transfer its exact UTF-8 bytes with source association and body hash through the established publisher; an ignored local file is not available by CI pathname alone.

## Dispatch and monitor

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before a publishing dispatch, require current executed naming evidence for every actual candidate artifact through the [naming gate](github-packaging.md#artifact-name-gate-and-repair). Missing or failing evidence requires repair/rebuild; build-only dispatch remains nonpublishing.

For a run that will publish a release, apply the shared [advisory prerelease review reminder](../../sdd-manage/references/prerelease-review.md#advisory-release-reminder), reusing any disposition from the release handoff. Build-only runs retain their preparation boundary. Apply the same handoff before an authorized publishing tag trigger through the release lifecycle.

Dispatch only when the request covers running the selected workflow and its effects. Resolve repository, workflow ID/path, selected ref, actual inputs, exact intended release source and expected outputs. Check [operation-specific access](github.md#release-and-workflow-access); Workflows write does not imply Actions write. Do not enable a disabled workflow or change repository settings by implication.

For a configured workflow, a command recipe is:

```text
gh workflow run release.yml --repo OWNER/REPO --ref WORKFLOW_REF -f tag=RELEASE_TAG -f publish=false
```

Replace those example input names with the workflow's declared inputs. `publish=false` is meaningful only if the workflow implements that build-only behavior. Change it to publication only when the selected request covers that operation. Use structured inputs or a JSON input file for complex values. See [GitHub CLI dispatch](https://cli.github.com/manual/gh_workflow_run) and the [workflow REST API](https://docs.github.com/en/rest/actions/workflows).

Retain a returned run ID/URL when available. Where a client/API returns only dispatch acceptance, correlate the run using workflow/ref/event/time and any declared request marker; do not pick the most recent unrelated run. After an uncertain dispatch, inspect existing runs before repeating. Ambiguous correlation remains unknown and blocks a duplicate dispatch.

Inspect queued/running/completed state, conclusion and the expected jobs/artifacts. Use `gh run view RUN_ID --repo OWNER/REPO` or the supported run API; bounded monitoring may return pending with the known run URL and next action. Do not wait indefinitely or infer build success from dispatch acceptance. No automatic rerun/cancel is implied by a failure.

When the workflow owns publication, do not create the same release independently. After successful publication, apply [release readback](github-releases.md#read-back-and-report). Return workflow/ref/source, run identity and conclusion, actual outputs, release state, failures and pending work. A failed job or unavailable facility keeps its affected result unverified.

```
Exit status: 0

Decision: standalone authorized release operation; repair existing producers/consumers/tests/docs before release. Stable contract will be orion.opaque, orion, SHA256SUMS; retain version metadata. Tracking disabled; local-only Git exception applies.

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/github-releases.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-message.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/SKILL.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/references/release-checks.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release-assets.md
```

```text
# Create and reconcile a GitHub release

Use for requested release creation, draft completion, release readback or recovery. Load [GitHub identity/access](github.md#repository-and-access), the accepted [package contract](github-packaging.md) and existing operational failure guidance. Product release publication is a distinct requested effect from preparing a workflow. Continue an authorized release request through necessary steps without repeated permission questions; respect explicit draft/local-only/stop boundaries.

## Resolve identity and select one publisher

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Apply the check to every actual artifact, including unfamiliar formats and extensionless names. No upload-manifest agreement or build-tool default can waive it.

At release entry, apply the shared [advisory prerelease review reminder](../../sdd-manage/references/prerelease-review.md#advisory-release-reminder), reusing the coordinator/direct-call disposition. Follow that policy without adding a review gate to this lifecycle.

Establish repository, exact verified source SHA, version/tag, expected package/checksum set, title/notes, draft/prerelease state and latest selection from the request and current project policy. Ask for consequential unresolved choices, not an authorization already supplied. No TASKS or tracking activation is needed for a standalone release. Prepare missing package inputs through the package owner before publication.

At release entry, verify the retained complete message's freshness through [the message/commit gate](release-message.md#release-request-freshness-and-commit-gate): use local source/coverage context and check its stated version against the intended release, refreshing absent/stale evidence. Manage creates/reuses and publishes the release commit on the actual default branch, directly or as the merge from the designated primary development branch. Verify its first-parent placement on the refreshed remote default branch before using that exact SHA for the peeled tag, package and publisher; mere side-history reachability does not qualify. The final notes form both the commit body and GitHub body. An existing-source-only request still requires an eligible release commit. An already completed matching release is read back/reused without another marker.

Before creating/pushing the pending release tag or triggering its publisher, create/update [shared Git highlights](release-highlights.md) through the exact verified source, explicitly excluding that pending tag from previous-baseline selection. On retries validate/reuse the pinned prior baseline. Prepare the [complete message](release-message.md) through reporting, preserving accepted human sections and assembling applicable compatibility/install/limitation material around the highlights. Use the exact UTF-8 final body, source association and hash for publisher transfer. Establish direct notes-file/API use or the workflow’s [notes transfer](github-release-workflows.md#notes-transfer); a tag-only publisher without transfer needs extension before triggering.

Before any new tag/publishing trigger or upload, require a passing [artifact-name gate](github-packaging.md#artifact-name-gate-and-repair) for the actual pinned candidate. Validate names against the contract independently of the expected upload set, including raw files. On failure, repair/publish scripts and related code/tests/docs, refresh the release source/notes and rebuild before continuing under existing authority. An old tag cannot certify repaired source; use the recovery/version boundary below.

Look up the tag and release by repository/tag; inspect draft and published states using the authenticated client. Peel an annotated tag to its commit and compare it with the intended source. When the tag is absent and creation is covered, first verify publication of the eligible default-branch release commit; **sdd-manage** then coordinates the tag and ordinary Git publication, or the selected supported API creates it at that exact SHA. Do not tag a revision/development tip or substitute a newer default tip after the release source is pinned. Never use an unspecified default-branch target, move an existing tag or force-push. Verify remote target before upload/publication.

Choose one route: [dispatch the established workflow](github-release-workflows.md#dispatch-and-monitor), or publish already verified packages using an available authenticated client/CLI/API. Verify that a tag push or another trigger has not already started the workflow's publisher before taking the direct route. Do not dispatch and separately create a duplicate release. Missing provider capabilities are reported precisely; ordinary local Git persistence stays with its existing owner.

## Draft, upload and publish

1. Inspect an existing matching release before writing. Validate tag target, owned fields, state and asset inventory. Reuse a uniquely matching draft. An already complete published release can satisfy a repeated request after readback; a conflicting source or unexpected state needs reconciliation rather than a second release.
2. Create a draft if absent, explicitly referencing the verified existing tag. Use the finalized body-only notes prepared from shared highlights through **sdd-report**'s [release reporting](../../sdd-report/references/releases.md), preserving user-authored material. Refresh coverage if the source advanced. For an existing draft reconcile its body without duplicate highlights before publication. Generated notes may supplement curation; they do not replace required highlights or compatibility/install guidance.
3. Upload every expected artifact and checksum with its stable filename and appropriate type. Read existing assets first. Reuse matching verified assets and upload only missing ones; mismatching content, duplicate names, unexplained assets or failed/starter uploads require a bounded repair decision. Do not silently delete or `--clobber` assets. Hash the exact bytes supplied, not a subsequently rebuilt archive.
4. Have **sdd-verify** recheck the complete draft against the independent naming contract and expected inventory: all actual names free of version numbers without any type/extension exemption, only necessary stable variant suffixes, source/tag, checksum filenames/contents, asset sizes and exact-byte hashes where available. An expected set containing versioned names does not pass. Require observed passing evidence for the current source and actual draft before publication; failures return to the owning repair/rebuild loop. On a partial upload/build failure, retain the draft and successful assets; do not publish or advance latest. Draft completeness applies even when immutable releases are disabled.
5. Publish only when this request covers publication, the current naming/package gate passes and all expected assets are ready. Apply the established prerelease/latest policy: latest is for complete stable releases, not drafts/prereleases. Historical/backport releases should not silently displace latest. Respect existing immutable-release settings; do not enable them as an incidental repository change.

Example commands for an already published, verified tag and locally verified files:

```text
gh release create v1.2.3 --repo OWNER/REPO --verify-tag --draft --title "Project v1.2.3" --notes-file release-notes.md
gh release upload v1.2.3 project.zip project.zip.sha256 --repo OWNER/REPO
gh release view v1.2.3 --repo OWNER/REPO --json tagName,isDraft,isPrerelease,body,assets,url
gh release edit v1.2.3 --repo OWNER/REPO --draft=false --latest
```

The final command is for an authorized stable/latest publication after inventory verification. For a prerelease, use its explicit prerelease setting and do not mark latest; for a stable release that should not replace latest, use `--latest=false`. These are sequenced examples, not an unconditional script: skip creation/upload when readback shows them already applied. See [create](https://cli.github.com/manual/gh_release_create), [upload](https://cli.github.com/manual/gh_release_upload) and [edit](https://cli.github.com/manual/gh_release_edit). If the CLI is unavailable, equivalent supported [release](https://docs.github.com/en/rest/releases/releases) and [asset](https://docs.github.com/en/rest/releases/assets) APIs preserve the same semantics and protected authentication.

GitHub's [immutable release procedure](https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases) is draft → attach all assets → publish. Published immutable tags/assets cannot be replaced; published corrections require the applicable new-release/version decision. Do not erase a partial/conflicting history or change settings to make a write succeed.

## Recover without duplicate writes

Follow the backend's bounded failure protocol for permissions, rate limits, outages and invalid input. Keep the request's destination, exact source and package set through credential recovery. Following a timeout or uncertain response, look up tag/release/asset or workflow-run state before replay. Paginate complete inventories where necessary; an incomplete lookup is not proof of absence.

For a naming violation discovered after tagging or publication, preserve existing tags, assets and frozen evidence. Use the existing authorized corrective release/version procedure or a specifically permitted hosted repair; source changes require a new eligible source/tag, never an old tag relabeled as repaired. Preserve public-link compatibility and immutable-release constraints. Ask only for an actually missing version/compatibility decision or effect grant; an authorized routine producer/docs repair needs no renewed blanket approval. Recheck the repaired candidate and actual hosted/latest names before claiming recovery complete.

Confirm draft identity and content before resuming pending uploads. A published release requires readback, not another create. Unexpected source, published asset mismatch or ambiguous ownership blocks replay. Return known successful, pending and unknown effects and the next supported action; replacing a token cannot resolve a policy denial. Do not switch publication channels to evade a host rejection.

## Read back and report

Read the actual release body through supported CLI/API fields (for example `gh release view TAG --repo OWNER/REPO --json body,isDraft,url`). Confirm intended highlights and preserved human sections, with no YAML front matter or duplicate curated section. A missing/mismatching body keeps note consumption unverified. Retain the complete-message file (`RELEASE-NOTES.md` by default) after publication. Only confirmed published-body consumption permits **sdd-manage** to remove the untracked workflow-owned internal highlights checkpoint under [shared cleanup](release-highlights.md#consume-and-retain-or-clean-up); retain it for draft-only, failed/uncertain or missing readback and explicit retention. Reconcile uncertain writes before replay or cleanup.

Verify repository and release identity, peeled tag source, release state, expected asset names/count/sizes/digests and latest selection. Retain tag-specific release/asset URLs and, for the actual latest stable release, [stable URLs](github-packaging.md#names-and-urls). Re-read repository latest rather than infer it from a successful edit response. Reapply the independent naming contract to actual hosted names and verify checksum entries and every advertised stable filename/URL in that release; there is no older-variant fallback. A mismatch keeps release completion pending and triggers authorized repair/reconciliation rather than a successful-release report.

Download uploaded assets through supported protected access where feasible and compare SHA-256 against the built files/checksum inventory. When digests or download access are unavailable, distinguish metadata confirmation from verified download bytes. A redirect/HTTP response alone does not prove correct content. A private-resource link is not an anonymous public-download promise.

Return exact tag/source, release ID/URL/state, workflow run when used, assets and hashes, actual latest status, successful checks, limits and pending differences through **sdd-report**. Do not claim release completion from a local ZIP, successful tag push or accepted workflow dispatch.
# Prepare a complete release message

## Entry and routing

Load for requests to prepare, draft, assemble or update a release message or release notes. These requests select complete-message preparation. **sdd-manage** establishes repository context, output ownership and the stopping boundary; **sdd-forge** supplies validated [Git release highlights](release-highlights.md); **sdd-report** assembles the complete Markdown through [release reporting](../../sdd-report/references/releases.md#complete-release-message). Local preparation needs an eligible Git worktree, not a provider, token, tracking activation or TASKS.

A narrower request to collect release highlights selects only the shared highlights workflow. An explicit request to edit supplied text without collecting project changes stays within that editorial scope. Seed text for a complete release message supplies material and preferences; it does not establish complete Git coverage or authorize publication.

## Establish inputs

1. Pin the exact target and previous release baseline using the shared highlights rules. Exclude a pending release tag from baseline discovery; retain a valid prior baseline on retry. With complete initial history and no qualifying tag, use the established null baseline. Resolve a consequential unknown release line or target before dependent collection; do not create a version/tag by implication.
2. Discover the project template, requested version/channel, package/install documentation, verified assets and relevant compatibility/known-issue evidence. Use supplied accepted sections and current authoritative sources. Unknown facts remain unknown; omit unsupported claims rather than inventing URLs, contributors, checks or release status. A preparation draft may identify intended assets as intended, not available downloads.
3. Establish preparation and final destinations and their ownership before writes. The default final location is `<project-root>/RELEASE-NOTES.md`; honor an explicit path or project template. Within an active revision campaign, release documents may instead be prepared and committed under that campaign's directory, recording their intended final paths. No new campaign is implied by ordinary preparation. Read existing staging and final files, retaining applicable accepted human sections, edits and cuts while correcting stale facts. Existing content alone is not proof of workflow ownership. Resolve unreadable/foreign destinations or symlinks before replacement; never follow a link to overwrite external content.

## Assemble and persist

Collect or refresh the internal highlights checkpoint through the pinned target before editorial assembly. Reuse valid incremental coverage; an unchanged target does not require replaying history. Do not advance its watermark past incomplete analysis. If the internal checkpoint was consumed/deleted after a prior publication, establish fresh coverage using the shared baseline rules; the retained final message has no coverage metadata and cannot substitute for that checkpoint.

Ask **sdd-report** to assemble the complete message from the curated changes and ancillary verified inputs. Return body-only Markdown, without YAML metadata, raw logs or internal campaign transcripts. Use a project's template or the adaptable structure in release reporting; omit empty sections and repeated highlights. A GitHub release title is a separate field and need not be duplicated in the body.

Default new generated output outside tracked campaign preparation is ignored/untracked. **sdd-manage** adds a narrowly scoped ignore rule for that generated destination using existing Git persistence rules, preserving current ignore content and foreign work. Campaign-staged release documents may be tracked and committed on the revision branch; do not ignore those selected tracked sources. A tracked destination remains tracked; update and persist it only within authorized repository scope, without silently untracking it. Complete required persistence/publication of owned ignore or tracked-note changes before further work.

Validate the entire candidate, applicable human-content preservation and current source association before replacement. Save atomically using a temporary sibling and filesystem replacement; failed collection, editing, validation or writing retains the prior complete file. Recheck ownership/current contents before replacement; do not clobber intervening edits. Remove only workflow-owned temporary files. Replace the selected file rather than append another message. If both target and applicable ancillary facts/body are unchanged, retain the existing bytes without a needless rewrite; changed verified ancillary facts may require an update even at the same Git target.

Return the preparation path, intended final path, final body, exact target/baseline, coverage checkpoint and evidence limits. Preparation stops here: no relocation into the default branch, release commit, tag, release, asset upload, workflow dispatch or version bump is implied.

## Retention and publication handoff

Keep the complete-message file after preparation and publication, including draft-only, failed, uncertain or successful outcomes. For campaign staging, retain it there until the release commit moves the owned document to its established final location; this planned move is not highlights-draft cleanup. The finalized file remains available after publication. The next authorized preparation refreshes/replaces the applicable file; explicit retention/path policy controls. Campaign plans, reports and evidence retain their campaign paths.

The internal `.release-highlights.md` retains its separate [verified-consumption cleanup](release-highlights.md#consume-and-retain-or-clean-up). Preserve applicable human curation from the retained message even when fresh internal coverage must be established. Other destinations follow the same distinction between final message and internal checkpoint.

Before an authorized publication, refresh Git coverage and ancillary sections through the exact final release source. Review both sides and the prospective result of a development merge before finalizing the release message: changes newly arriving from default must not escape coverage. Any commit caused by tracked notes or ignore-rule persistence advances that source; perform the required incremental refresh and inspect whether it changes user-visible facts. A pure document move adds no product highlight. Do not manufacture another tracked edit for an unchanged body. A retained message may belong to an earlier source and is not automatically valid for the next release.

Pass the complete message's exact UTF-8 Markdown bytes, source association and body hash to the selected publisher through its supported notes-file/API/structured handoff. An ignored file is absent from CI checkout; transfer the body explicitly, not merely its local pathname or a tag. Preserve accepted human sections and avoid inserting highlights twice. Read back the actual published body before claiming consumption; uncertain writes require reconciliation. Successful readback may permit cleanup of the owned internal checkpoint, while the complete-message file remains.

## Release-request freshness and commit gate

A release request loads this workflow even when `RELEASE-NOTES.md` already exists. Use available local preparation context to establish its target/baseline, version/channel, body hash and completed coverage. Check any version stated in the message against the intended release and project version authority. Version agreement is a corroborating check, never proof of current coverage. If provenance is absent, stale, contradicted or the target advanced, reconstruct/refresh the required coverage and ancillary facts before consuming the file. Preserve applicable human material; do not publish an old message merely because its filename or version looks correct. Final release notes identify the established release version/tag in their overview or project-template location; preparation without an established version does not invent one.

**sdd-manage** coordinates the [default-branch release commit and tag](../../sdd-manage/references/git-workflows.md#release-commit-and-tag), and **sdd-report** formats its [commit message](../../sdd-report/references/object-drafts.md#release-commit-message). Use either a direct default-branch commit or the merge into default from the designated primary development branch; that merge itself is the release commit. Its body uses the same finalized Markdown as the GitHub release body. Include owned verified release/version changes and necessary moves from campaign staging to final destinations, preserving unrelated and foreign content. Only a direct release with no file changes may need an empty marker. Preparation-only creates no release commit. Reuse an existing commit only when its default-branch provenance and all release contracts qualify; an existing-source-only request cannot waive those checks.

After the release commit, inspect its actual source and refresh/check notes coverage through it before tag publication. A marker that only records the already assessed release outcome adds no new product highlight. Confirm the commit body still equals the final complete message. If newly discovered user-visible changes require a different body, correct the pending boundary before tagging; preserve published history and never move an existing tag to hide the discrepancy. Tag the verified release commit and use that exact SHA/body/hash for the single publisher. Commit/tag publication is a Git boundary; GitHub release completion still requires its own successful readback.
---
name: sdd-verify
description: Use when selecting and running checks for an SDD task, selected change, milestone, phase, or project; assessing acceptance and exit-condition coverage; classifying observed failures; performing read-only milestone/phase implementation code review, checking Git release-highlight ranges and drafts, release package contents, release workflows, CI outputs and hosted asset integrity; or returning verification evidence and remaining gaps before completion.
---

# Verify a selected work boundary

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** For package/release checks, validate every actual name without type/extension filtering through the [independent naming gate](../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair). Matching manifests/checksums cannot waive it.

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

For whole-feature preparation QC, use the coordinator's [FDOCS-009 contract](../sdd-manage/references/feature-preparation.md#final-package-qc-integration-and-checkpoint): assess the complete delta plus affected accepted main context and retain FEATURE-QC-REPORT. Do not infer package readiness from individual document reports or implement repairs outside the selected scope.

Establish the requested task, change, milestone, phase, or project scope. Load the relevant references:

| Work | Load |
| --- | --- |
| Review milestone/phase implementation code and findings | [boundary review](references/boundary-review.md) |
| Derive checks from requirements, changes, and dependencies | [check selection](references/check-selection.md) |
| Execute a complete-inventory artifact-name check; select the project check or Python helper | [executed naming gate](scripts/release-assets.md) |
| Assess Git highlights, package contents, release workflows, CI outputs and hosted download evidence | [package and release checks](references/release-checks.md) |
| Execute checks and assess acceptance evidence | [execution and evidence](references/execution-and-evidence.md) |
| Classify failures and return unresolved work | [failure assessment](references/failure-assessment.md) |

Use a current **sdd-orient** handoff for governing instructions, Git state, dirty-path ownership, relevant documents, and declared commands. **sdd-manage** coordinates the requested scope and execution prerequisites; the active implementation workflow, **sdd-implement** for main task work or **sdd-steer** for a checkpoint amendment, requests verification within its boundary. For standalone package/release work, use accepted source/build/package inputs without inventing TASKS; load release checks. Otherwise read the owning TASKS or FEATURE-TASKS, relevant SPEC contracts, PLAN exit conditions, design and layout, actual changes, tests, and existing evidence as needed. Read-only check planning can precede execution; commands with side effects require the established eligible Git worktree and authorized environment.

For main documentation package QC, use [main preparation](../sdd-manage/references/main-preparation.md#final-package-qc-integration-and-checkpoint) and DOCS-009 in DOCS_TASKS, not the implementation task/audit lifecycle. Assess the current whole document set, DOCS_TASKS checkoffs and DOCS_PREPARATION control/decision evidence; return the passing/blocked DOCS-QC-REPORT to the coordinator for repairs, checked-task persistence, publication and hosted closure. Ordinary later edits retain first-approval completion; an explicit cursor reset invalidates DOCS-002–009 for the next pass. Before package QC, verify the [selected mode/range permits DOCS-009](../sdd-manage/references/doc-design-modes.md#complete-a-pass); autodoc’s DOCS-008 stop does not select it.

For an explicit boundary review task, load boundary review and assess implementation code separately from test execution. Neither activity substitutes for the other. Return findings and recheck evidence without repairs or task/hosted state changes.

1. Identify the acceptance and exit conditions to verify and the implementation state being checked.
2. Select sufficient direct, dependent, integration, and boundary checks. Use project commands and an existing verification map where useful; neither a map nor new scripts are required.
3. Establish representative environment capabilities for the planned checks through check selection; load its browser guidance only for relevant browser work. Run the selected checks and inspect actual outcomes, including failures, warnings, skips, and collection counts where relevant.
4. Associate each condition with evidence and any limitation. Distinguish verified, failed, blocked, and not checked conditions; passing checks do not establish acceptance they never exercised.
5. Classify observed failures where evidence permits and return remaining work to its owner. Do not silently omit an unrelated or pre-existing failure from the results.

**sdd-tdd** owns testing strategy and test design or changes; this skill assesses coverage and executes the verification campaign. **sdd-docs** owns documentation maintenance. The active workflow owns repair coordination, completion, persistence and hosted closure: **sdd-manage** for main preparation, **sdd-implement** or **sdd-steer** for implementation. Leave source, tests, governing documents, and task status unchanged during verification; report necessary changes rather than repairing them here. Account for command-generated artifacts and preserve unrelated pending work.

Return the boundary and implementation state, conditions assessed, check selection and rationale, commands and environment, observed outcomes and evidence locations, failure classifications, omitted or blocked checks, and remaining gaps. **sdd-report** owns presentation of these facts. Existing task evidence or a project-designated record may hold durable results; no separate verification journal is required. State when the selected conditions are verified without equating that finding with task completion or whole-project correctness.
# Package, workflow and release checks

Load for selected release/package acceptance. Use the requested boundary and the accepted [package contract](../../sdd-forge/references/github-packaging.md), not a guessed universal inventory. Verification assesses actual outputs and returns evidence; the coordinated work owner repairs files or performs publication. Local checks do not themselves authorize a live release.

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** The [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) is a mandatory pre-tag/prepublication check and hosted completion recheck. Derive accepted stable names independently of build output or an upload manifest; a complete/checksummed but version-named set fails. Return specific failing producer/consumer/doc locations to the owning workflow for authorized repair, source publication, rebuild and recheck; verification does not itself edit or publish. Retain passing/blocked evidence for the exact candidate and actual hosted state.

Apply [cross-platform verification scope](check-selection.md#cross-platform-artifacts-and-native-verification) to target artifacts. Unavailable native execution does not prevent an authorized release when the requested artifacts and in-scope checks are complete. Identify cross-built/inspected packages and native tests not run in release evidence and installation instructions; do not claim native-tested compatibility. A missing artifact or failed feasible required check remains distinct.

| Claim | Evidence to obtain |
| --- | --- |
| Git highlights range | Pin target and release line/channel, qualifying tag policy, peeled baseline and ancestry; check complete history/tag discovery, pending-tag exclusion, and complete range identity/parent inventory, latest adequate cumulative campaign summaries, other integration messages including reachable nested merges, and targeted gap messages/diffs. Verify earlier same-campaign bodies are fallback rather than required reconstruction, and original opening pointers stay unchanged across amendments. Verify direct-change/revert coverage, amendment/enclosing-child deduplication and evidence limits; phase/preparation versus implemented-delivery claims remain distinct and refs/tips are discovery only, including phase and plugin-convention `design-docs/*` document-preparation refs. Verify explicit null baseline only for complete initial history. Use [shared Git highlights](../../sdd-forge/references/release-highlights.md). |
| Incremental draft | Confirm ignored/untracked ownership, parseable YAML/full identities, unchanged tag target and baseline → analyzed → target ancestry. Exercise no-op, pending-only update, reverts/cuts, malformed/moved/diverged state and interrupted saves without false watermark advancement. |
| Complete message | Check explicit complete-message routing versus highlights-only/editing-only scope, established template or applicable optional sections, preserved human material, supported factual claims, output ownership/path, body-only Markdown and atomic replacement/no-op behavior. Check separate preparation/final paths: release documents may be committed inside the active revision directory and moved to their final destinations in the release commit. Root `RELEASE-NOTES.md` is the default final path. Verify tracked/untracked ownership, preserved human content and campaign evidence, exact bytes and final-source/ancillary refresh; failure preserves the previous copy. |
| Release commit/tag agreement | Verify current notes provenance/coverage and stated version; matching version alone is insufficient. Resolve the actual default branch and designated development role. Verify a direct default-branch release commit or the merge into default from that development branch; the merge itself is tagged, without another marker. Confirm first-parent placement on the published remote default branch, exact release-commit/notes/GitHub body equality and peeled tag/package/publisher SHA agreement. Reject revision-side commits, ordinary side-history ancestry and wrong merge direction. Recovery retains an eligible pinned commit if default advances; existing-source-only requests do not waive eligibility. No preparation-only marker. |
| Final notes/cleanup | Confirm exact final source coverage, complete UTF-8 body/hash/source transfer to one publisher and actual body readback. Retain the complete-message file after every outcome. Keep internal checkpoints on preparation/draft-only/failure/uncertain or missing readback; delete only an owned internal highlights checkpoint after published-body confirmation unless retention was selected. |
| Package layout/content | Inspect actual member names, duplicates, path/link safety, corruption and declared size limits; compare required members, intentional exclusions, entry points, applicable notices, versions and modes. Explain generated members through the build procedure. |
| Build/source identity | Resolve the exact source SHA/tag, runtime/dependencies and version source; run the declared build from that state into an owned output directory. Compare the candidate with supplied reference contents where relevant. |
| Usable package | Exercise installation/import/startup or another declared consumer check in a suitable controlled environment, without executing untrusted supplied archive scripts. Report unsupported platform coverage. |
| Reproducibility | Repeat under equivalent declared inputs and compare bytes/hashes when this claim is required. Matching inventories alone establish layout, not reproducibility. |
| Stable variants/checksums | Compare actual local/draft/hosted filenames with the independent stable version-free naming contract, for every artifact, including unfamiliar types and names without extensions; no type/extension may be skipped. Include every promised variant, only necessary conventional suffixes, no collisions, and matching checksum filenames/exact-byte SHA-256. Exercise the project-local gate with the known bad name before repair and corrected names after rebuild; inspect its direct/CI prepublication wiring. An expected list copied from a faulty generator is not acceptance. |
| Workflow validity | Check YAML plus available Actions validation, trigger/input/permission semantics, checkout identity, build-only effects, matrix collection, one publisher, concurrency and recovery. Parsing is not CI execution. |
| CI success | Identify actual run/ref/source, relevant job conclusions and expected built artifacts. Accepted dispatch, queued state or a success in an unrelated job is insufficient. |
| Hosted release | Read release/tag identity and source, state, complete asset names/sizes/digests, actual latest pointer and URLs. Follow the [release readback](../../sdd-forge/references/github-releases.md#read-back-and-report) procedure. |
| Download integrity | Download exact assets through supported access; compare bytes/hashes with the built files and checksum set. Report metadata-only coverage separately. |

Select positive and relevant failure/recovery checks proportionate to the changes: missing/extra members, unsafe ZIP entries, variant name collisions, absent latest assets, wrong source/version, missing permission, failed matrix build, partial draft upload, uncertain publication and published/immutable conflicts. For highlights use disposable real Git/file fixtures for deterministic identity/parent/merge-message collection and targeted fallback mechanics, plus source/consumer assessment for editorial coverage, consolidation and deduplication. Separate recipe execution from an agent following the workflow: successful fixture scripts do not prove semantic curation, fresh-consumer acceptance or live publisher transfer/cleanup. Use disposable local fixtures or provider mocks where appropriate; mock lifecycle success is not live GitHub acceptance.

Before a hosted check, identify its authorized repository, operation and effects. Do not create a release, dispatch publication or modify immutable/settings policy merely to test instructions. If live CI, installation or download checks are unavailable, return their limits rather than fabricate coverage or declare them passed. Record tested state, actual commands/results and remaining work under [execution and evidence](execution-and-evidence.md).

Use the project's executed check or the [read-only Python naming helper](../scripts/release-assets.md) for the complete candidate/provider inventory; its existence or a partial-draft result is not a complete pass.
# Executed artifact-name gate

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Every artifact in the complete inventory is checked, including unknown extensions and names without extensions. Follow the canonical [package contract and repair loop](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair).

Use the project's deterministic executable check in its existing stack. When Python 3.11+ is available, this bundled read-only standard-library helper can supply the naming/inventory check; it is not a universal extra runtime prerequisite. An equivalent project check must satisfy the same positive/negative cases. Executing a check is mandatory even when this particular helper is not selected.

## Inputs and invocation

Establish the stable name contract independently from product/delivery requirements before generating build/release scripts. Retain it in existing project package/build documentation or configuration. Review every expected name for version content; never bless a generator's output by copying it into the contract. Pattern matching alone cannot establish a semantic naming contract.

For the helper, supply a JSON array of the independently reviewed expected names and a dedicated flat staging directory containing every actual release artifact. Do not filter entries by extension or omit an unrecognized type. Directories, links and special entries fail rather than hide unexamined contents; package directory artifacts into their specified release form before this check.

```text
python PATH/skills/sdd-verify/scripts/release_assets.py --expected EXPECTED.json --directory STAGING --version 1.2.3
```

For an actual provider inventory, collect every asset name with complete pagination/readback and supply its JSON array:

```text
python PATH/skills/sdd-verify/scripts/release_assets.py --expected EXPECTED.json --observed ACTUAL.json --version 1.2.3
```

Exit 0 requires every observed name to satisfy the prohibition, exact contract membership/completeness and uniqueness, including case collisions. The expected names are checked too: a matching faulty upload manifest cannot authorize a prohibited name. Common version notations and selected-version forms are rejected; ordinary product/architecture digits are not categorically banned. Exit 1 returns a JSON diagnostic. No network request, file write, source repair or publication occurs.

## Transitions and evidence

Require an observed failure for the offending artifact before correction and a passing full-inventory check after the producer/code/docs repair and committed-source rebuild. Capture the exact source, contract/inventory, command, exit status and outcome in existing release evidence. Recheck an actual complete draft before publication and hosted/latest names afterward. Reuse the project's existing checksum/content/source checks; this helper does not establish those properties.

The importable check_names function supports incomplete draft inspection only with complete=False. Such a result is not complete release acceptance. Before tag creation/push, publishing dispatch, upload and publication, the corresponding complete candidate/inventory must pass. A tag-trigger-only builder needs a nonpublishing candidate-build path before tagging. Do not replace an executed gate with an agent promise or the existence of a checker file.

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-orient/SKILL.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/repository-bootstrap.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/continuity.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/prerelease-review.md; cat .github/workflows/release.yml .gitignore; python --version; git rev-parse --is-shallow-repository; git tag --list; git symbolic-ref HEAD; git status --porcelain=v1; python /tmp/sdd141-trial-direct/provider.py --help
```

```text
---
name: sdd-orient
description: Use when locating and inspecting a software project's repository before SDD work, checking execution OS/shell readiness, Git worktree and interrupted-task state, discovering governing instructions and development documents, or handing a scoped project orientation to an orchestrating agent. Read-only; report whether a proposed mutation has the required Git and authority baseline.
---

# Orient in a project

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Establish a factual, scoped starting point before another SDD skill changes repository files. This skill is a shared, **read-only** capability. It neither authorizes a mutation nor decides which later workflow to run. Read [inspection and handoff](references/inspection-and-handoff.md) for the evidence checks and report contract.

1. Establish the user's intended project path and proposed scope, if supplied. Distinguish the project root from its enclosing Git root; do not assume the current directory is the project. Identify the actual execution host/tools under [execution readiness](references/inspection-and-handoff.md#execution-os-and-tool-readiness). Follow applicable user/repository instructions and return observed readiness failures to sdd-manage without repairing the environment.
2. Read root/applicable nested AGENTS.md; assess concise orientation, command/link currency and execution-owner discoverability under **sdd-manage**'s [agent orientation](../sdd-manage/references/agent-orientation.md). Report missing/stale guidance without creating or editing it. Inspect root `SDD-MANAGER.md`, `AI_DISCLOSURE.md` and README links as adoption/disclosure evidence and report missing or conflicting records in the handoff; do not create them during orientation. Identify applicable repository instructions, including root and path-scoped `AGENTS.md`, referenced policies, and project-designated sources. Inspect `docs/dev/PROJECT.md` for the project brief; if it contains operating instructions, preserve their applicability and report their scope and any conflict.
3. Inspect Git, current branch or detached/unborn state, HEAD, worktree status, and changes affecting the intended paths. Suppress optional Git writes with command-scoped `git --no-optional-locks` or an equivalent scoped `GIT_OPTIONAL_LOCKS=0`. Git commands must not change the index, branch, working tree, or configuration.
4. Inspect the HANDOFF checkpoint, relevant later decision/task evidence and available workflow refs under [inspection and handoff](references/inspection-and-handoff.md#continuity-checkpoint). Report candidate parents, containment and remote-state uncertainty to the coordinator without selecting/fetching/switching branches. Inspect adjacent SPEC/PLAN/TASKS (and selected feature) review reports, finding/gate state and reviewed/governing identities; report absent or apparently stale readiness without performing QC or writing reports. Discover present development documents and their focused children, the active feature or change context, relevant code and tests, and declared project commands. When a task list exists, identify the last committed task and compare it with the owning checklist, pending changes, and existing verification evidence. Distinguish completed work awaiting commit from incomplete work; pass the identified state to **sdd-implement** for continuation.
5. Produce the scoped orientation report. Separate observed facts from inferences and unknowns, identify concrete blockers, and state whether the Git prerequisite for a contemplated mutation is met. Re-orient when the project path, target scope, HEAD, instructions, or material worktree state changes.

Use current governing documents and the active campaign for routine orientation. Do not load prior campaign documents unless the current task specifically needs their historical context; then read only the relevant records/sections. Identity/path discovery does not require reading historical contents. Apply the [closed-record boundary](../sdd-conventions/references/review-campaigns.md#closed-campaign-records).

If the target is outside a usable Git worktree, mark **repository mutation blocked**. Do not initialize Git, create files, clean worktrees, restore files, run tests with side effects, commit, or invoke a mutating workflow. A conversational or read-only inspection may continue.

For a subagent, the orchestrator supplies the applicable path scope, instructions, relevant document authorities, Git baseline, known dirty paths, and prohibited mutations. A subagent can inspect additional evidence within its scope; the orchestrator rechecks the overall state before coordinating any mutation or commit.

For feature preparation, observe FEATURE, task-only FEATURE_DOCS_TASKS, FEATURE_PREPARATION mode/pass/acceptance evidence and FEATURE-QC-REPORT readiness and next boundary under [feature preparation](../sdd-manage/references/feature-preparation.md), without authoring. For main/feature preparation, observe actual document progress and pending human instructions under [human document review](../sdd-manage/references/human-document-review.md). For main preparation, inspect DOCS_TASKS for task definitions/checkoffs and DOCS_PREPARATION for mode/pass, initialization/approval evidence and pending effects, together with actual document, QC, Git and hosted state under [main preparation](../sdd-manage/references/main-preparation.md); orientation remains read-only. Pass the next unfinished stage and any selected review to the coordinator; absent retrospective acceptance evidence alone does not require interactive replay. Keep readiness observation separate from authoring and substantive owner QC.
# Bootstrap SDD Manager in a target repository

For fresh or resumed **main documentation preparation**, load [main preparation](main-preparation.md) before any target-repository write. Its early tracking gate, DOCS-001 initialization (including the default provenance checkpoint unless explicitly overridden), preservation/pause rules and PROJECT-stage README links take precedence over the combined-first-result procedure below. The provenance-only checkpoint's narrow exception is defined by [manual AI provenance](ai-logs.md); it is not a general disclosure or publication waiver. Other adoption paths retain the procedure below.

## Greenfield startup

During main/feature initialization, execute/reuse the [manual provenance setup](ai-logs.md#default-execution-and-overrides) by default without an opt-in question. Honor explicit human/project opt-out or deferral; unspecified choice is not a skip. Main preparation owns the fresh DOCS-001 sequence; resumed/feature setup follows the supplement's existing-initialization rules without rewriting history or replaying completed tasks. Report/recover enabled setup blockers rather than silently omitting the step. Conversation recording remains manual.

Load this section at greenfield entry, before the first persistence operation. Treat a preliminary project description as a seed for exploration, not an accepted specification. Use the current **sdd-orient** handoff to establish the eligible Git repository, controlling instructions and actual state; route problem framing, alternatives and consequential choices to **sdd-design**'s [exploration](../../sdd-design/references/exploration.md). Retain established decisions and identify assumptions without imposing an unrequested product, stack or feature set.

Carry the supplied repository, project scope, stopping boundary and explicit repository-operation authorization into [coordination](coordination.md). Apply the existing [workflows](workflows.md) and [document QC gates](document-qc-gates.md) for acceptance and execution boundaries, and [Git workflows](git-workflows.md) for complete checkpoint publication and synchronization. Ask for material missing information or consequential decisions; continue independent authorized work when sound. Standing repository authority does not accept proposed requirements or select an implementation range.

Treat an explicit request for GitHub phase labels, milestones and task issues as tracking confirmation under [tracking decision](tracking-decision.md); carry that choice without asking again. Delegate projection, associations and verified state updates to **sdd-forge** and [phase activation](phase-activation.md) at their eligible boundaries. Protect a supplied token through [hosting credentials](credentials.md); its technical permissions neither define project scope nor require unrelated operations.

The bundled [Greenfield Project Prompt Template](<../../../assets/Greenfield Project Prompt Template.md>) supplies the user's project seed, repository/token inputs, standing authorization and tracking selection. The plugin owns startup and subsequent procedures. Continue through the requested stages and checkpoints; preserve preparation-only, local-only and explicit stop instructions. The disclosure/adoption trigger below remains the first authorized SDD commit, not the start of conversational exploration.

## Ownership and trigger

Before the **first authorized SDD commit** in a target repository, include the disclosure and usage notice below in that same commit. This includes initial document preparation or review records, not just the first implementation task. “Initial” means SDD adoption in an already eligible Git worktree; do not initialize Git implicitly. Read-only orientation, discussion, selection and verification create nothing.

**sdd-manage** owns this shared policy and coordinates bootstrap for preparation, maintenance and feature incorporation. **sdd-implement** and **sdd-steer** apply it in their own commit procedures, including direct invocations. **sdd-report** checks bootstrap evidence when composing a commit but does not write or commit files. Load this reference at greenfield entry and before the first persistence operation in other adoption workflows; it is an ordinary agent procedure, not a hidden hook or client installer.

For implementation, push eligible outstanding commits first under the existing startup protocol, then perform bootstrap before staging the first new result. Outside main documentation preparation, do not make a separate bootstrap commit ahead of the requested result. A preparation-only request can bootstrap with its preparation commit and still stop before implementation.

## Root artifacts and discoverability

Establish/reconcile `docs/dev/HANDOFF.md` from the [continuity template and procedure](continuity.md) with the same first authorized workflow result, preserving existing records and write limits. Keep its branch-parent and scope facts discoverable; do not add a separate administrative commit.

Ensure root AGENTS.md through [agent orientation](agent-orientation.md) during authorized adoption. Read existing controlling instructions first; preserve manual content and explicit path limits. Include affected orientation with the same first result checkpoint, not a separate administrative commit. Its ownership and subsequent maintenance are independent of disclosure byte-copy requirements.

Resolve assets relative to the loaded plugin root: this reference is at `skills/sdd-manage/references/repository-bootstrap.md`; bundled files are at `assets/AI_DISCLOSURE.md` and `assets/SDD-MANAGER.md`. Use the same installed or pinned source as the running skills, including an acceptance vendor snapshot. Do not fetch a newer template silently or fabricate a missing asset.

1. Inspect the target Git root, applicable instructions, root `AI_DISCLOSURE.md`, `SDD-MANAGER.md`, README and relevant Git history. Establish bootstrap ownership separately from unrelated pending content. For a project nested in a Git repository, place these records at the **target repository root**, not inside `docs/dev/` or the project subdirectory; resolve incompatible repository-wide scope before writing.
2. If absent, copy `assets/AI_DISCLOSURE.md` byte for byte to root `AI_DISCLOSURE.md` and `assets/SDD-MANAGER.md` to root `SDD-MANAGER.md`. The notice names SDD Manager and links `https://github.com/pchemguy/SDD-Manager`; it links the root disclosure and makes no unsupported completion claim. Never include credentials or local installation paths.
3. Add a concise discoverable root README link, preserving its project focus and existing text:

    `Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md).`

    Reuse an existing equivalent link instead of duplicating it. If no root README exists, create a minimal `README.md` with the established project name and these links; do not invent product claims. Where the repository uses another designated root README, use that document and correct relative links.
4. Preserve existing disclosures and usage notices. If byte-identical, reuse them. If different, read and reconcile within authorized scope: retain project-specific disclosure and truthful attribution, add the required SDD Manager link, and do not replace established text with a template. An existing disclosure can satisfy the disclosure requirement if it expresses the project's AI assistance and maintainer responsibility; record why it was retained rather than claiming a byte-identical copy. Conflicting disclosure claims or ownership require a decision before the affected commit. Do not follow a symlink to edit an external file or directory.
5. Inspect links, truthful scope, file ownership and the staged diff. Include the owned root changes with the first verified SDD result and its ordinary status/evidence changes; apply the existing unrelated-index isolation, commit and push/readback rules. Verify the committed tree contains the required root records and README links, and an added disclosure matches its packaged bytes. A draft or untracked copy is not completion.

## Scope limits, recovery and upgrades

These files are ordinary bootstrap outputs of an authorized initial SDD workflow. Explicit human restrictions such as selected-path-only, no README edits, or read-only take precedence. If those restrictions exclude a required missing artifact, report the bootstrap scope conflict and obtain the missing decision rather than silently widening paths or falsely claiming bootstrap complete. Honor local-only/no-push instructions; bootstrap itself does not authorize publication.

On interruption, inspect actual files, index and Git evidence. Reuse valid pending copies in the same first result, preserving unrelated staged work. If the first SDD commit already includes the records, continue its pending push instead of making another bootstrap commit. On subsequent invocations, retain established files and links without duplicate sections or version churn. If an older SDD-managed repository lacks the records, add them to the next authorized coherent commit within scope and report this as adoption backfill; never rewrite history or claim they were in its original first commit. Report missing/conflicting records for scoped repair when their creation is not currently authorized.

A plugin update does not automatically overwrite the target's disclosure or notice. Version/commit provenance may be added when accurately known, but is not a prerequisite and must not misrepresent a dirty-source snapshot as a released version.

## Human review at startup

Apply [human document review](human-document-review.md) from greenfield entry. Walk the human through necessary new documents, pausing at each created root before dependent work unless explicit applicable [future-checkpoint preapproval](human-document-review.md#future-checkpoint-preapproval) covers it. For existing or interrupted main/feature preparation, assess progress and reuse acceptable inputs without automatically entering interactive mode. Begin with explicitly requested interactive reviews; raise important startup concerns and offer review before advancing. Retain real pending review/stopping instructions.
# Preserve and recover workflow context

Use this subworkflow at composite-workflow entry or reconstruction, scheduled handoff checkpoints, nested/steering return and explicit handoff preparation. Focused calls affecting an active workflow use the same continuity contract. Read-only discovery/review does not authorize adoption, checkout or execution.

## Checkpoint and owners

Maintain tracked target-project `docs/dev/HANDOFF.md` from the bundled [template](../../../assets/HANDOFF_TEMPLATE.md). It describes a named checkpoint; later task commits need not change it. The coordinator owns continuity, the active owner supplies its facts and persistence, and **sdd-orient** observes/reconstructs without writes. AGENTS links the record and this coordinator route. The main/default branch retains its integrated checkpoint; workflow branches inherit and update their own copies until integration.

Keep a brief outcome summary and four groups:

1. Workflow/variant, stage/owner and links to governing documents, task list and evidence.
2. Authorized objective/range, exclusions, exact stop, pending approvals and scoped preapprovals/overrides with decision sources.
3. Working branch, recorded creation parent, full branch-off commit, integration target, suspended parent stage and return boundary.
4. Pending work/effects, blockers and next eligible action **as of the checkpoint**. Include necessary package/version/setup/input availability and transfer limits when relevant.

TASKS, current campaign/phase reports and accepted documents own their details. Feature preparation retains its current decisions, exact acceptance/QC references and pending stage in [FEATURE_PREPARATION](feature-preparation.md), with checkoffs in FEATURE_DOCS_TASKS, package readiness in FEATURE-QC-REPORT and product scope in FEATURE; HANDOFF links these owners rather than duplicating their records. In main preparation, DOCS_TASKS owns task definitions/checkoffs and DOCS_PREPARATION owns control, scope sequence, decisions and evidence; HANDOFF links both rather than duplicating their detail. Preserve later grants, revocations, stops and tracking decisions in those existing records when received, before dependent work; ordinary commits retain their normal result/evidence. Link their locations from the handoff. Retain the selected reporting preference here when needed. Summarize older phase/campaign outcomes with links instead of repeating tasks, logs or a conversation. Require no additional journal, issue registry, incremental handoff files or saved patch series.

## Establish and refresh

At authorized workflow entry/adoption, reconcile existing context and create/update the checkpoint with the actual scope, sources and parent. Preserve controlling/manual content and unrelated work. Apply [main preparation](main-preparation.md) before its first repository write; its initial handoff is generated workflow metadata, outside DOCS-001's four-file presence test. Do not merge unfinished preparation merely to expose the handoff on default.

| Boundary | Required persistence |
| --- | --- |
| Each main/feature milestone's assigned final boundary task: standalone review when required, otherwise final implementation task | Refresh HANDOFF with the verified outcome, evidence, remaining scope, pending effects and next stop in the same commit as that task's report/result and initial checked completion. |
| Phase review/report task | Refresh with overall exits and integration readiness in its completion commit. One task closing both a review milestone and the phase produces one combined update. |
| Revision finalization | Refresh its outcome and return boundary with existing campaign finalization evidence; intermediate action detail stays in campaign records. |
| Completed main/feature preparation or other composite operation | Refresh the preparation/operation checkpoint with its actual pending human/hosted boundary. Intermediate document approvals stay in their owning evidence. |
| Nested entry, steering return or eligible integration | Preserve parent suspension or restore parent context under the return procedure below. |
| Doc-design cursor reset or autodoc DOCS-008 stop | Refresh with concise mode/pass/next-boundary context and a DOCS_PREPARATION evidence link, retaining outstanding hosted effects under [pass control](doc-design-modes.md); include the snapshot in the reset or DOCS-008 completion commit. |

Refresh at these boundaries automatically, without waiting for a handoff request. Include it in the owning commit; do not add handoff tasks or routine maintenance commits. Failed/blocked review retains its findings and incomplete boundary; it cannot produce a successful-completion snapshot. A completed milestone inside an incomplete main phase pushes/pauses without merging.

No per-commit handoff edit or handoff audit is required between checkpoints. Refresh earlier only when existing records cannot adequately preserve a consequential change or a transfer is explicitly requested. Keep every owned commit's [publication](git-workflows.md#publish-each-commit) and task/document atomicity unchanged.

Identify the checkpoint by workflow/milestone and the commit containing its explicit snapshot. Inspect path history, for example `git log -1 --format=%H -- docs/dev/HANDOFF.md`, and verify the selected content/ancestry; a timestamp alone is insufficient. A snapshot must not contain its own future SHA. Completion reports may name known baseline/end commits for on-demand diffs. A checkpoint cannot prove its own later push, issue closure or merge: record required subsequent effects as requiring confirmation and reconcile them by readback.

## Select the continuation branch

At initial/reconstructed startup, inspect local and remote workflow refs and relevant active navigation. Include revision/feature and unfinished preparation/phase branches. Establish remote freshness through permitted coordinator Git operations; orientation inspects available refs without fetching or switching. An unavailable remote means unknown state, not no unfinished work. Inspect only the identities/current sections needed; closed campaigns are not a reading queue.

Reserved `design-docs/ai-logs` is a [manual provenance branch](ai-logs.md), not a continuation candidate merely because manual records are unmerged. Do not read transcripts or ask to resume it during unrelated startup. A known interrupted adopted initialization still requires reconciliation of its actual seed/merge/publication; explicit provenance requests may select that scope.

For each candidate, recover its recorded creation parent, branch-off checkpoint and actual unfinished boundary. Test source-tip containment against that parent and its established remote destination, not main alone. A retained child already merged into its unfinished parent is integrated; a target merge awaiting push is pending publication, not a reason to repeat the merge. Unmerged history alone does not prove execution remains authorized.

If the continuation branch is not already explicitly selected or established in sufficient current context, present candidate branches with their parent and pending stage and **ask which branch to continue**, even for one candidate. Do not select by recency or prefix. Preserve an explicit selected branch and avoid repeating the question on ordinary continuation. With no unfinished candidate, use the main/default checkpoint and actual request without resurrecting completed work. Missing/ambiguous parent or authority requires the consequential decision before affected mutation.

After selection, follow [branch management](branch-management.md) for safe checkout/worktree handling. Do not stash, reset, discard incomplete milestones or switch over unrelated work implicitly.

## Reconstruct after the checkpoint

1. Read applicable AGENTS instructions, selected HANDOFF and relevant current owners. Establish actual branch/HEAD, worktree/index ownership and package availability. If the record is absent, reconstruct derivable facts from existing documents/Git and establish it only within authorized write scope; do not invent past grants.
2. Locate and verify its checkpoint. Inspect relevant commits/diffs since it, current TASKS or campaign evidence, and main DOCS_TASKS plus DOCS_PREPARATION and later decisions as applicable. Include non-task and merge changes; an older handoff followed by valid task commits is expected, not a failure.
3. Recover the current objective/range, stop, approvals/revocations, tracking choice, accepted inputs, unfinished operation and parent return. Current controlling instructions and actual later human decisions supersede the older snapshot. Branch names, ready tasks and checkboxes do not supply missing authorization.
4. Inspect uncertain Git/hosted effects by exact identity before retrying. Preserve an eligible retained commit, in-progress merge, issue operation and their evidence; use the owning recovery procedure. Do not replay completed work or infer external success from saved text.
5. Hand reconstructed facts to the selected owner and resume the earliest eligible operation within actual authority. Report a concrete missing decision/facility if evidence is contradictory, unresolvable or outside scope. A current clean snapshot is not a prerequisite for safe recovery.

## Integrate and return

For workflow completion, new branches record their creation parent and branch-off commit at setup and integrate their completed eligible scope into that same parent under [Git workflows](git-workflows.md). Preserve explicit target overrides and established legacy associations; corroborate history rather than guessing an original branch name. Partial ranges and explicit no-merge boundaries remain unmerged.

For [incoming synchronization](git-workflows.md#merge-purpose), retain the receiving workflow's identity, original creation parent, scope, pending human decisions and stop; record the incorporated baseline and resulting readiness. Do not replace its HANDOFF with the incoming baseline's context or treat catch-up as child completion/parent return.

Before nesting, retain the immediate parent's unfinished stage, scope, pending decision and return boundary in active campaign evidence and the child checkpoint. At the child's finalization, record its actual result and pending integration. During the prospective merge, deliberately reconcile HANDOFF to the parent's resulting context, retaining a concise child outcome/evidence link. Do not choose the entire child or parent file mechanically or edit a closed child report afterward.

Verify/publish the eligible merge, then return through the actual parent worktree/branch. Restoring context does not resume parent tasks, accept its pending document or expand its range. Completed root work leaves a completed/paused checkpoint and the actual next human boundary. Interrupted merge/publication resumes the retained operation rather than creating another campaign.

## Explicit transfer preparation

Requests such as “prepare a handoff” run this same reconstruction and may refresh a mid-milestone snapshot without declaring the milestone complete. Verify that the selected branch/checkpoint and necessary non-secret files are available through the receiving mode, and publish eligible owned results within existing authority. No explicit transfer command is needed for ordinary repository-based continuation.

A fresh clone cannot reconstruct unpublished/index/ignored bytes; identify missing inputs and use an authorized transfer or report the limit. Required package availability, credentials and host permissions must be supplied separately when the repository cannot provide them. Never place secrets or transient credential/helper paths in the handoff. Do not manufacture task completion, overwrite foreign state or bypass required gates to make a transfer appear complete.
# Comprehensive prerelease review

Use when the human explicitly selects comprehensive review of a release candidate. This provider-independent profile supplies scope and criteria to [review and revision](review-and-revision.md); use its campaign lifecycle and sdd-report's [campaign artifacts](../../sdd-report/references/campaign-artifacts.md) rather than a separate framework. Release callers load only the [advisory reminder](#advisory-release-reminder) unless review is selected.

## Advisory release reminder

At entry to a requested release creation/completion or a workflow run that will publish a product release, briefly recommend this review and explain that it can be selected explicitly. Apply this to coordinated and direct release calls, including publication triggered by a tag push. For example: “A comprehensive prerelease review is recommended for this candidate and can be requested separately; it is optional, and I will proceed with the authorized release checks.”

Emit the reminder once for the selected release operation; pass its disposition through the normal handoff to prevent duplicate reminders by the coordinator and publisher. Reuse a known human decision or an applicable candidate-specific review, acknowledging its actual coverage when useful. Do not fabricate a decline, waiver or review selection from silence. If the candidate changes, identify any resulting evidence limit without automatically starting review or requiring it to proceed.

The reminder is advisory: do not ask for confirmation, pause or delay an authorized release, activate review, require a waiver, or add a mandatory gate. If the human explicitly selects review before publication, honor that requested sequence and its report boundary. Highlights-only work, package assessment and build-only/workflow preparation do not themselves trigger this publication reminder or authorize release publication.

Ordinary required source, package, workflow and publication checks still apply under the accepted project contract and [release checks](../../sdd-verify/references/release-checks.md). Optional review does not replace them, clear a known required-check failure, or grant publication authority. A review's readiness assessment is evidence for the human, not an additional universal release gate.

## Establish candidate and plan

1. Establish the selected project, governing instructions, supported product scope, release intent, exact candidate source SHA and relevant version/package identities. Pin supplied package hashes and provenance; distinguish source-only review from assessment of actual built bytes. Record pending changes, the inspected/tested states and authorized checks/effects. A moving branch name alone is not the candidate identity.
2. Inventory the complete CURRENT supported product: governing contracts/design, implementation, tests, workflows, public documentation, entry points and distribution assets. Use the release diff and risk to prioritize depth, not limit coverage to changed files. Account for generated/third-party material and exclusions with reasons. Apply the [closed-record boundary](../../sdd-conventions/references/review-campaigns.md#closed-campaign-records): exclude closed campaigns and historical feature/steering snapshots from routine loading and current-validity checks. Selected historical consultation answers only a specific evidence question and creates no compatibility repair duty.
3. Create the campaign review plan with bounded units, owner routing, dependency order, criteria and representative success/failure/boundary/recovery scenarios. Identify tools, permitted local/external checks, unavailable facilities and exclusions. Adapt criteria to the actual project; record not-applicable concerns with reasons rather than inventing product requirements or mandatory artifacts.
4. Assess each unit using the selected focused owners below. Review consequential handoffs on both sides. Record no-finding coverage, blocked/deferred units and evidence classes: source inspection, consumer assessment, actual execution or authorized external verification. An example inspected is not an example executed; structural support tests are not live agent/client acceptance.

## Coverage and owner routing

| Concern | Assess | Focused owners / references |
| --- | --- | --- |
| Product coherence | Duplication, conflicting terminology/behavior, inconsistencies, misalignment, stale current material, gaps, scope violations, defects and improvement opportunities across supported capabilities. | sdd-manage coordinates; sdd-conventions supplies relevant design/code criteria. |
| Traceability and public claims | Requirements → design → implementation → tests → documentation; accurately supported/planned/deferred/untested behavior, scope limits and evidence. Do not presume implementation is authoritative when it conflicts with requirements. | sdd-design, sdd-specify, sdd-plan and sdd-tasks for their contracts; sdd-docs and sdd-verify for claims/evidence. |
| Workflow/instruction behavior | Prerequisites, ownership, dependencies, handoffs, human checkpoints, stopping and recovery paths, authorization/permission conflicts, ambiguous assumptions, unsupported mandates and gate bypasses. | sdd-manage and affected workflow owners; existing governing decisions remain controlling. |
| README | Positioning, capabilities, installation, quickstart, examples, limitations, navigation and release/download guidance match current supported behavior and actual evidence. | sdd-docs [documentation review](../../sdd-docs/references/review-and-findings.md). |
| AGENTS.md | Concise current orientation, authorities, commands and ownership; controlling human instructions preserved, no competing workflow copy. | sdd-manage [agent orientation](agent-orientation.md) and sdd-docs. |
| Diagrams | Actors, transitions, branches, gates, failures and stopping points match the documented/implemented workflow; inspect rendered legibility where facilities permit. Valid syntax alone does not establish semantic alignment or readability. | sdd-docs and the depicted behavior's owner; report unavailable rendering separately. |
| Maintainability | Boundaries, coupling, unnecessary duplication, competing authorities, progressive disclosure and context consumption. | sdd-conventions, sdd-design and affected source owners. |
| Verification | Meaningful success/failure/boundary/recovery checks, coverage gaps and stale evidence; avoid tests that merely mirror implementation. Distinguish source/local support evidence from actual consumer/platform acceptance. | sdd-tdd for strategy; sdd-verify for coverage and execution. |
| Distribution and operation | Actual package members/exclusions, metadata/version, entry points, dependencies/notices, checksums, installation/startup, supported platforms/clients/interfaces and compatibility as relevant. | sdd-forge's accepted package contract and sdd-verify [release checks](../../sdd-verify/references/release-checks.md); use the selected backend only for hosted concerns. |
| Access and sensitive material | Credential handling, unintended sensitive contents, applicable dependency risks and supported access assumptions. Use evidence and project requirements; do not invent speculative compliance mandates. | sdd-manage credential owner, sdd-forge backend and sdd-verify. |
| Agent plugins, when applicable | Activation descriptions, direct invocation, bundled-reference resolution, instruction handoffs, progressive disclosure and source-to-shipped-package consistency. These are not universal criteria for other products. | sdd-manage and affected skill owners, sdd-docs and sdd-verify. |

## Findings, readiness and rechecks

Use stable finding IDs and the existing report format. Each canonical finding records baseline location/evidence, observation and consequence, type (defect, evidence gap or improvement recommendation), priority, confidence, bounded proposed correction, dependencies/needed decisions and objective recheck. Do not confuse a recommendation with an accepted requirement; retain actual acceptance, rejection and deferral separately from observed evidence.

After each planned unit, update and commit the review report; the coordinating workflow pushes and verifies remote containment before any next unit or additional work under [per-commit publication](git-workflows.md#publish-each-commit). Consolidate coverage, findings/counts, dependencies, unavailable checks and readiness against the pinned candidate and existing required release criteria. Separate evidenced blockers, accepted deferrals, optional improvements and unknowns. Record actual human decisions; do not invent risk acceptance or infer global readiness from passing structural tests.

When the source, contract or package changes, identify affected units, handoffs and dependent regressions and reassess them against the new exact candidate. A previous report remains evidence for its own source, not automatic readiness for the new candidate. Reuse unaffected evidence only with its provenance and justified applicability. Accepted repairs use the existing revision procedure and owner workflows; recheck their objective criteria before marking findings Verified.

## Complete and stop

Return the published report, assessed source/package, coverage/readiness, canonical proposed revision queue and concrete evidence limits. Review assessment ends at its report commit; coordination completes its authorized publication. Stop before source repairs, revision execution, release/tag creation or publishing workflow dispatch unless those effects are independently authorized. Selecting this profile does not select hosted tracking or authorize external checks with write effects.
name: Release
on: workflow_dispatch
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python scripts/build.py
      - run: python scripts/release.py --source ${{ github.sha }} --tag v1.2.3
dist/
__pycache__/
Python 3.12.14
false
refs/heads/main
usage: provider.py [-h] --repo REPO --source SOURCE --tag TAG --directory
                   DIRECTORY --state STATE

options:
  -h, --help            show this help message and exit
  --repo REPO
  --source SOURCE
  --tag TAG
  --directory DIRECTORY
  --state STATE

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/SKILL.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/SKILL.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/releases.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/object-drafts.md; sed -n '/## Release commit and tag/,$p' /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/git-workflows.md; cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-forge/references/release-highlights.md
```

```text
---
name: sdd-tdd
description: Use when defining an SDD project's testing strategy, deriving test scenarios from accepted contracts, writing or reviewing tests, reproducing a bug, or guiding a test-first red-green-refactor cycle for a selected implementation task.
license: MIT
---

# Design tests and guide test-first implementation

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Choose the requested operation and load its references:

| Work | Load |
| --- | --- |
| Define testing strategy and scenario coverage | [testing strategy](references/testing-strategy.md) |
| Guide a feature, bug fix, or behavior change through TDD | [test-first cycle](references/test-first-cycle.md) and [writing good tests](references/writing-good-tests.md) |
| Write, revise, or review tests, doubles, or test helpers | [writing good tests](references/writing-good-tests.md) |

Use the selected TASKS or FEATURE-TASKS entry, accepted SPEC contracts, relevant design, PLAN and layout, inspected implementation, and project test commands. **sdd-manage** coordinates scope and a current **sdd-orient** handoff establishing Git eligibility, governing instructions, and ownership of dirty changes. Strategy and review can remain read-only; test edits and execution follow the authorized scope and environment.

For new or changed behavior and bug fixes, establish a test that fails for the intended reason before the production change. Observe the failure, guide the smallest implementation that satisfies the accepted contract, and refactor with checks remaining green. **sdd-tdd** owns test strategy, scenarios, test changes, and development-cycle test execution. The active implementation workflow, **sdd-implement** for main task work or **sdd-steer** for a checkpoint amendment, owns production changes and applies the GREEN and production-refactoring steps; this skill supplies the test and evidence at each handoff. A strategy-only request does not authorize implementation.

Preserve existing work when resuming. If code predates the tests, report missing test-first evidence and use characterization or a safe isolated baseline where appropriate; do not delete or reset code to reconstruct an unobserved history. Follow applicable project policy and previously authorized exceptions for work that cannot use a meaningful test-first cycle. When an exception is still required and undecided, explain the concrete limitation and defer that decision to the user.

Return the testing strategy or test changes, covered contracts and scenarios, actual RED and GREEN commands and outcomes, regression results, remaining coverage gaps, and any exception or blocker. Do not invent a failed run or infer whole-project correctness from a focused passing test. **sdd-verify** owns the verification campaign and acceptance assessment; the active implementation workflow owns completion updates, commits, pushes, and issue-closure coordination. **sdd-docs** owns documentation maintenance and **sdd-report** presents completion evidence.

This skill adapts both Superpowers TDD and its test-writing companion. See [upstream provenance and adaptation](references/upstream-provenance.md) and the included [license](LICENSE).
---
name: sdd-docs
description: Use when creating, reviewing, or maintaining professional module and API documentation, aligning README and standalone guides with an SDD project's supported implementation, checking documentation examples and links, or auditing documentation after code changes or across the project.
---

# Maintain project documentation

For Markdown output or document work within this skill's scope, apply the shared [Markdown style](../sdd-conventions/references/markdown-style.md): blank lines after headings and around top-level lists and code blocks, plus four-space structural indentation, including nested lists, with exactly one space after each list marker. This applies to direct calls as well as coordinated work; it does not expand editing or review authority.

Choose the requested scope: documentation for affected code, README or selected guides, or a project-wide audit. Read only the relevant references:

| Work | Load |
| --- | --- |
| Module docstrings, API documentation, and explanatory comments | [in-code documentation](references/in-code-documentation.md) |
| README, standalone guides, examples, and navigation | [standalone documentation](references/standalone-documentation.md) |
| Change-scoped or project-wide audit and amendment findings | [review and findings](references/review-and-findings.md) |

Use a current **sdd-orient** handoff for applicable instructions, Git state, target paths, and ownership. **sdd-manage** coordinates the requested editing scope; the active implementation workflow, **sdd-implement** for main task work or **sdd-steer** for a checkpoint amendment, coordinates documentation maintenance after substantive code changes. Read project documentation policies, relevant layout, accepted design, SPEC and PLAN or their active feature equivalents, affected code and tests, and existing documentation as needed. Review can remain read-only; edits require an eligible Git worktree and established ownership of pending changes.

Follow the documentation style specified by governing project documents. Otherwise select an established professional style appropriate to the language and documentation tooling, such as Google-style Python docstrings. Keep documentation accurate, useful, and proportionate to the code's responsibility. Ensure every code module within the selected scope has a professional module docstring or its language's equivalent; a project-wide audit covers every project-owned code module. Report generated or externally maintained modules separately and follow project policy for editing them.

Maintain documentation against both accepted requirements and observed implementation. Clearly distinguish supported behavior from planned capabilities. If a discrepancy requires an amendment to SPEC, PLAN, design, layout, or another authoritative requirement, identify its location, issue, impact, and proposed amendment and report it to the user. Defer the decision to the user; do not amend the governing document or invoke its owning skill automatically. Continue independent documentation work and report anything dependent on that decision as unresolved.

For main preparation, [main preparation](../sdd-manage/references/main-preparation.md) owns template-based initialization and its preservation/partial-state stop. Maintain later project-specific guidance only within the selected scope; do not reconcile existing root files during DOCS-001. Its coordinator owns non-implementation preparation commits and issue progression.

Keep code edits confined to documentation unless additional work is authorized. Do not mark tasks complete, create commits, push, or change hosted objects here; the active implementation workflow owns those operations.

Return the reviewed scope, chosen style and source, documentation changed, checks and observed outcomes, unreviewed or excluded areas, and unresolved findings or user decisions. Use **sdd-report** for a completion summary when requested.
# Package and release reporting

Use for package/workflow preparation results, Git release highlights, release notes or actual release completion. Use current accepted package/release inputs and verification evidence; TASKS is needed only when task work supplies the scope. Drafting notes or a status report does not create a release.

## Preparation result

State the intended distributable and prepared behavior first. Report the selected source/version, accepted layout and variants, stable filenames/checksum convention, workflow/build files and actual performed checks. Identify unresolved package/build decisions and the exact stopping boundary. Distinguish a workflow file from an executed CI run, and a candidate ZIP from an uploaded release asset.

## Release notes

Explain delivered features/fixes and consequences for users. Include material compatibility changes, supported variants and necessary installation/update guidance. Use the requested release/tag and verified changes; generated notes can seed editing but do not prove coverage. Preserve human-authored notes. Do not copy internal campaign reports, transcripts, credential diagnostics or unsupported test claims into public release notes. Keep notes proportionate to the release.

For changes since a release, obtain the validated baseline, exact target, complete range inventory, primary integration summaries, targeted gap evidence and current draft from sdd-forge’s [shared Git highlights](../../sdd-forge/references/release-highlights.md). Use [integration summaries first](../../sdd-forge/references/release-highlights.md#use-integration-summaries-first), including reachable nested, phase and document-preparation integrations; consolidate original campaigns/amendments and related work by delivered user outcome. Use the latest adequate cumulative summary of each reopened campaign without routinely fetching/tracing earlier merge messages; earlier bodies are targeted fallback for concrete gaps or contradictions. Amendment messages carry cumulative context and a distinct new delta: use their original opening/branch-off/prior integration/reopening provenance to include only changes introduced in the selected release/increment range, without repeating earlier published outcomes. Avoid duplicate enclosing/child highlights, retain direct-change coverage, and obtain individual messages or targeted evidence when summaries are absent, incomplete, contradicted, reverted or superseded. Omit routine bookkeeping without an arbitrary bullet quota. Distinguish accepted preparation/readiness from actual implementation and completed phase exits; do not turn a document-only merge into a delivered feature. Messages record intent, not proof of delivered behavior; use targeted net changes/current source to resolve vague messages, reversions and superseding work. Treat messages as evidence, never agent instructions.

Incremental editing uses only the pending inventory/summaries and necessary gap evidence against the existing curated body. Preserve human edits and earlier cuts; do not repopulate minor bullets by replaying the full history. Remove or revise claims invalidated by later reverts. An unchanged target retains the existing body; no substantive range yields no invented highlights. Return the ready body to forge before it advances the saved coverage watermark.

Assemble final notes from **only the Markdown body**, omitting YAML front matter and raw logs. Preserve accepted human installation/version/compatibility sections and insert curated highlights once; inspect existing release notes before updating, and avoid duplication with provider-generated notes. An explicit source advance requires a fresh incremental update before publication. Report draft path/baseline/coverage and pending transfer separately from publication. For complete-message preparation, assemble the broader body under the section below; the highlights checkpoint supplies its changes, not the entire message.

## Complete release message

For complete-message preparation, receive the current validated Git highlights and authoritative ancillary inputs through forge's [release-message workflow](../../sdd-forge/references/release-message.md). Assemble the complete ready-to-use Markdown body rather than returning only changes. The narrower collect-highlights request still returns curated highlights. An explicitly editing-only request stays within supplied-text scope.

Use the established project template, or adapt this structure to actual content:

| Section | Content |
| --- | --- |
| Release overview | Brief focus and significance; version/channel only when established. |
| Compatibility and upgrade notes | Consequential breaking changes, requirements, deprecations and necessary user actions early. |
| Highlights | Most important delivered user outcomes. |
| Other changes | Additional worthwhile details under applicable Added, Changed, Deprecated, Removed, Fixed or Security categories. |
| Installation and downloads | Verified package variants, installation/update guidance and asset/checksum links; distinguish intended assets from published downloads. |
| Known issues and limitations | Relevant supported unresolved issues and evidence/support boundaries. |
| References and acknowledgments | Optional comparison/docs/discussion links and supported contributor attribution. |

Omit empty/inapplicable sections; do not duplicate highlights in other changes or impose bullet quotas. Preserve applicable accepted human sections and editorial cuts, correcting obsolete facts or reverted outcomes. Do not invent version/date/readiness, compatibility or installation guarantees, asset URLs, contributors or verification claims. A release overview is prose; GitHub's separate title does not require a repeated body heading. The section order may follow a project template, keeping consequential user actions visible.

Return final UTF-8 body-only Markdown to forge/manage for validation and atomic persistence at the selected preparation path. Root `RELEASE-NOTES.md` is the default final destination; an active revision campaign may commit release documents within its directory for relocation in the default-branch release commit. Return both paths, source association and evidence limits separately from the public body. YAML coverage metadata stays in the internal checkpoint. On repetition assemble a replacement from fresh coverage and verified ancillary facts; unchanged facts/body do not justify rewriting. Preparation and editorial assembly authorize no publication or relocation into default. The finalized complete-message file remains after publication; only the separately owned internal highlights checkpoint is eligible for verified-consumption cleanup.

## Release outcome

| Fact | Report from actual evidence |
| --- | --- |
| Identity | Repository, version/tag, exact source SHA and release ID/URL. |
| State | Draft, prerelease or published stable; actual latest selection, not assumed ordering. |
| Execution | Direct publication or workflow ID/ref/run URL and observed conclusion. |
| Assets | Expected and observed filenames, sizes/hashes/checksum URLs, tag-specific links and applicable stable latest links. |
| Highlights | Baseline/tag, analyzed source, actual final-body readback, and retained complete-message path and retained/removed owned internal highlights checkpoint with its reason. |
| Verification | Actual build/package checks, CI conclusions, metadata readback and downloaded-byte verification with their separate limits. |
| Recovery | Successful effects, pending/unknown writes, conflicts and next supported action. |

For several assets, use a compact table of variant, filename, hash/checksum and download link. Do not describe private links as anonymously accessible, an absent platform asset as downloadable, or a draft/prerelease as latest stable. Declare completion only for the boundary supported by [release readback](../../sdd-forge/references/github-releases.md#read-back-and-report); a local archive or accepted dispatch remains preparation/pending execution.
# Issue, commit, and PR drafts

Keep the same task identity across all outputs. Use the ID from its owning TASKS or FEATURE-TASKS entry, or the predefined DOCS/FDOCS ID from its main/feature documentation task list; include a resolved issue reference only when **sdd-forge** supplies a unique repository and number. Match the requested object's time perspective: an issue describes intended work, while a commit or PR describes actual changes and available evidence.

## Task issue

Return `title` and `body` separately. Format the title as `[<task-id>] <task title>`, using the owning task list. Draft the body from the task outcome, reason and project context, expected scope and dependencies, objective acceptance and prescribed checks, and source document links. Add relevant kind-specific details. For example:

- **Performance:** Describe the problem with the current implementation, explain how the proposed approach may improve it, and identify the measurement plan and any established baseline. Do not present an expected speedup as an achieved result.
- **Security:** State the affected guarantee and risk without exposing exploit instructions or credentials.

**sdd-report** owns the title and body format. Preserve an exact task identity marker when one is supplied. Never invent host labels, milestone associations, issue URLs, or resolution state.

For forge's optional [structured projection handoff](../../sdd-forge/scripts/forge-project-input.md), supply the corresponding reviewed brief/dependency fields instead of an arbitrary complete-body override. Its renderer derives title/context/markers from validated source identities. Mechanical extraction does not author dependencies or acceptance; use actual governing documents and preserve the same task identity and evidence boundaries.

## Git commit

For a first SDD commit or adoption backfill, load **sdd-manage**'s [repository bootstrap](../../sdd-manage/references/repository-bootstrap.md). For main preparation use [its initialization exception](../../sdd-manage/references/main-preparation.md): normal DOCS-001 completion has four preserved/copied root files and the task list; the default provenance scaffold has a preliminary unchecked checkpoint unless explicitly overridden. README links follow at PROJECT. Otherwise confirm the commit owner has included or validly retained root disclosure/usage records and README links within scope. Return missing bootstrap evidence to that owner; drafting does not perform bootstrap or establish a committed result.

Draft a short imperative subject naming the actual change, based on the inspected diff and checks rather than merely the task brief. Use a body when the reason, verification, migration implications or verified issue references need explanation.

### Task commit subjects

For every task-associated commit, use exactly `[<owning-task-id>] <imperative description>`. The single owning task marker must be the first content of the subject, followed by one space and the description. Preserve the exact ID from TASKS/FEATURE-TASKS or the mapped DOCS_TASKS/FEATURE_DOCS_TASKS. FDOCS subjects use their stage ID; hosted issue identity also includes the campaign. Feature document completion follows [feature preparation](../../sdd-manage/references/feature-preparation.md), keeping checkoffs in FEATURE_DOCS_TASKS and decision/QC evidence in FEATURE_PREPARATION; it does not use the product T-task audit. DOCS subjects use the same single-ID shape, but document task completion means first approval under [main preparation](../../sdd-manage/references/main-preparation.md), not implementation task completion. Proposal commits leave the DOCS task unchecked; approval commits include its checked task, accepted document state and DOCS_PREPARATION decision/QC evidence. Keep narrative out of DOCS_TASKS. Later revisions retain completed first-approval tasks/issues. Do not prepend a conventional-commit type/scope, put the ID only at the end, or use multiple task IDs or a task range in the subject. Apply this format to production, tests, documentation and explicit milestone/phase review/report tasks, as well as authorized partial checkpoints and later task-specific repairs or parent-status follow-ups. Describe partial or follow-up work accurately; a subject does not establish completion.

For numeric `T-` IDs padded to at least three digits, `^\[T-[0-9]{3,}\] [^\r\n]+$` checks the basic subject shape. Also check that the ID is the exact owning entry, the subject has no second task identity, and the description is concise, imperative and truthful. A regex alone cannot establish ownership, single-task composition or completion.

| Subject | Assessment |
| --- | --- |
| `[T-028] Implement lock delay` | Valid shape for one verified owning task. |
| `[T-030] Complete Milestone 2.4 review` | Valid for the review task's actual result and completion. |
| `[T-028] Record partial lock-delay checkpoint` | Valid shape; retain unchecked status and required checkpoint authority. |
| `feat(mechanics): [T-028] Implement lock delay` | Invalid: content precedes the task marker. |
| `Implement lock delay (T-028)` | Invalid: task marker is not at the beginning. |
| `[T-028, T-029] Implement lock delay and wall kicks` | Invalid: multiple owning tasks. |
| `[T-028] Implement lock delay and close T-029` | Invalid: second task identity, despite passing the shape regex. |

For implementation tasks, closing composition follows **sdd-implement**'s [task commit contract](../../sdd-implement/references/completion-and-checkpoints.md#task-commit-contract): one executable task's result, required evidence and initial completion checkbox together. Return a detected composition conflict to the commit owner; do not merely improve the subject of a bundled or split closing commit.

For DOCS tasks, use [main preparation](../../sdd-manage/references/main-preparation.md): verified initialization or package QC, or first human approval for a document, with the checked DOCS task in its completion commit. For FDOCS stages, use the [feature counterpart](../../sdd-manage/references/feature-preparation.md) for context, accepted/reused documents and package QC. The implementation history audit does not govern DOCS/FDOCS preparation tasks.

For other preparation, campaign actions or maintenance without an assigned executable task, do not invent a task ID. Merge commits use their integration-summary format and may summarize several completed tasks; they do not close those tasks for the first time.

Use `Refs owner/repo#123` when the commit advances an issue without completing it. Use `Fixes owner/repo#123`, `Resolves owner/repo#123`, or `Closes owner/repo#123` when the commit fully resolves that issue and the evidence supports completion. One task may have multiple verified issue associations, with a separate appropriate reference for each; these references do not permit bundling multiple executable tasks in one closing commit. Omit issue references when no verified association exists. On GitHub, closing keywords may close an issue when the commit reaches the default branch. **sdd-forge** still reconciles issue closure after verified task completion, without waiting for that automation. If verification has not been run, say so in a proposed body rather than claiming it passed. The active implementation workflow makes and checks its commits; **sdd-manage** coordinates persistence for other authorized repository changes.

## Merge commit

Draft a subject identifying the actual feature, revision campaign, steering amendment or selected completed range. For a campaign, include its stable ID and a concise title derived from the final delivered scope, such as `Merge revision 040_a0685b5 — Revision campaign modes`; do not retain a stale opening title when scope changed. A main milestone/task subset does not justify a merge while its phase remains incomplete. Return subject/body separately; the coordinator owns the explicit two-parent integration.

### Campaign integration summary

Every ordinary, nested or reopened revision integration, and every feature, steering, completed phase or accepted document-preparation integration, carries a concise, self-contained summary for [release highlights](../../sdd-forge/references/release-highlights.md#use-integration-summaries-first). Include the following facts, with labels when useful rather than a mandatory machine schema:

- **Objective:** The problem or intended outcome and why it matters.
- **Review:** Actual reviewed scope/coverage and material conclusions; state when no separate review was performed. Do not imply a comprehensive review from a focused amendment.
- **Delivered:** Actual executed scope and consequential features/fixes/documentation or workflow changes, including effects relevant to users. Separate accepted/executed work from proposals, exclusions and unfinished parent work.
- **Verification:** Actual boundary and merged-state checks/results, with relevant counts/environment and evidence limits. Record blocked/unrun checks, material conflict resolutions, compatibility/migration consequences and deferred work when applicable; passing local tests does not prove live acceptance.
- **Integration:** Campaign/phase/preparation identity and mode where applicable, working and recorded creation-parent/return-target branches, full original campaign-opening commit ID, full original branch-off/base commit ID (the starting baseline), and distinct reopening checkpoint when applicable, verified parent/source tips and affected task/action IDs. Apply campaign-opening provenance to campaigns; do not invent a campaign ID/opening for an initial preparation or phase that has none. Git parents establish ancestry; titles/branch names alone do not establish coverage.

A reopened amendment carries forward a concise cumulative summary of the campaign’s retained result and objective/review coverage, then clearly separates the new delta and added actions. Include prior integration, the original campaign-opening commit pointer and original branch-off SHA alongside the reopening checkpoint. Every amendment retains the first opening pointer; do not replace it with an amendment’s first commit. Make the latest cumulative summary sufficient for release highlights without tracing earlier campaign merges: carry forward all relevant retained outcomes, review coverage and material superseded/withdrawn consequences, with original opening provenance and separately identified new delta. Retain relevant earlier information without copying raw prior messages or presenting original delivery as new. Correct superseded outcomes in the cumulative result and distinguish historical checks/source from actual new merged-state verification; inherited verification is not fresh evidence.

Subsequent summaries may also retain compact explicit scope references for the original opening and individual reopenings: identify each opening/reopening commit or checkpoint, added action IDs and its review/execution scope. Carry needed scope distinctions forward in the latest message rather than requiring readers to follow older merge bodies; distinguish these provenance references from the cumulative user outcome and current delta. They are not a new registry or raw chronological transcript.

The campaign-opening commit is the verified first commit opening that campaign and its retained records. It is distinct from the branch-off/shared source checkpoint and from later reopening commits; do not infer it from current branch tips or invent an unavailable identity.

An enclosing integration summarizes the combined delivered result and identifies included nested campaigns/amendments sufficiently to prevent duplicate release highlights. Keep the semantic summary prominent and technical provenance compact; do not substitute raw logs or a list of commit subjects for the outcome.

Phase summaries describe actual completed phase scope, delivery/reviews/exits and verification; retain the full-phase merge gate and report an explicit partial-integration override accurately. Document-preparation summaries identify accepted documents/review coverage and readiness for their dependent stage, without claiming implementation or task completion. Use the plugin’s established `design-docs/*` document-preparation branches; prefixes discover candidates but never establish scope or acceptance. Preserve repeated preparation deltas as distinct scope, with appropriate source/checkpoint evidence.

The message is an **integration summary**, not proof that closure/publication already happened. It is committed before its push and final worktree return; do not claim those future steps succeeded. Closure still requires the applicable verified target publication and return boundary. Review-only publication does not fabricate a closure merge. Do not represent an amendment as completion of the next task, an interrupted parent or a product release. Drafting authorizes no extra work or hosted PR.

```text
Merge revision 040_a0685b5 — Revision campaign modes

Objective: Define nested revisions and eligible campaign amendments.
Review: Assessed campaign routing, branch ownership, closure and reporting.
Delivered: Added both modes, eligibility checks, scoped reopening and
explicit return to the interrupted campaign branch.
Verification: 16 source scenarios checked; 113 support tests passed on the
merged state. Package and link checks passed; live compliance not assessed.
Integration: <campaign/mode, original opening, branch-off/reopening, branches/parents>
```

## Pull request

Draft a title and description only when requested; this skill does not create a PR. Scope the text to the actual branch diff and its included task IDs. Summarize **What**, **Why**, **Verification**, and **Result**; add the relevant fields from [change kinds](change-kinds.md). State the base branch and integration status only when known. List unrun checks, limitations, and remaining work explicitly rather than presenting partial work as complete.

A code health PR should explain the ownership or maintainability problem and the checks supporting behavior preservation. A performance PR should include baseline and current times, input size, environment, method, and whether the measured gain is meaningful. Do not imply that GitHub PR operations are available through **sdd-forge**.

## Examples

These show formatting for an issue title, commit message, and PR draft. Use actual task IDs, issue references, checks, and results for the current work.

### Issue title

```text
[T-012] Implement ZIP stream support
```

### Commit message

```text
[T-041] Clarify filesystem utility ownership

Move shared filesystem helpers into the module named by the project layout.
Update its documented responsibility; the focused unit suite passed.

Refs owner/repo#123
```

### Code health PR

```markdown
# 🧹 Clarify filesystem utility ownership

- 🎯 **What:** Renamed `common.py` to `fs.py` and updated its documented responsibility.
- 💡 **Why:** A focused module name makes ownership clear under the project's layout rules.
- ✅ **Verification:** Inspected layout references and passed the focused unit tests.
- ✨ **Result:** Filesystem utility ownership is explicit, with behavior preservation supported by the cited checks.

```

## Release commit message

Use for the release commit selected by manage's [release commit/tag boundary](../../sdd-manage/references/git-workflows.md#release-commit-and-tag). Compose a concise `Release <version/tag>` subject, a blank line, then the exact finalized release-message Markdown body. Assemble the UTF-8 message file as subject bytes + `b"\n\n"` + body bytes, without shell interpolation, reflow or newline normalization. Preserve hard-break spaces, CRLF when present, trailing blank lines and the presence or absence of a final newline. The same body bytes remain in the notes and publisher handoff; no task ID is invented.

The Git owner commits the prepared file with `git commit --cleanup=verbatim -F <message-file>`; ordinary file-message cleanup can strip Markdown spaces/blank lines or append a newline. This applies both to a direct default-branch release commit and the release merge from the designated primary development branch into default; the merge uses this release message, with integration provenance retained in existing evidence. Add `--allow-empty` only when an authorized direct release requires it, never to add a marker after the release merge. Include necessary owned release-document moves from campaign staging without relocating campaign plans/reports. If a client or hook alters the text, actual raw-body comparison must catch the mismatch before publication; do not silently change finalized notes to match cleaned Git output. No task/campaign-summary formatting or premature provider-success claim is added. This skill supplies the draft; manage owns the commit, comparison and publication.
## Release commit and tag

**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before creating or pushing the pending tag, obtain sdd-verify's executed [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) for the exact candidate and complete inventory. Missing/failed evidence blocks tagging and publishing triggers; route persistent producer/checksum/docs repair, source publication and rebuild through the owner before retrying. Do not accept a generator's matching expected list as a pass.

For an authorized release request, forge first verifies/refreshes the retained complete message through [release-message preparation](../../sdd-forge/references/release-message.md#release-request-freshness-and-commit-gate). Local source/coverage/body context and the established version govern freshness; a matching version alone is insufficient. Manage owns Git persistence and forge owns provider publication.

**Release tags always target release commits on the repository's actual default branch.** Discover that branch from current repository/remote metadata rather than assuming main, master or a cached local alias. Establish whether development uses that branch directly or a designated primary development branch; a branch name alone does not select its role. Refresh the default branch and preserve unrelated work before preparing the release boundary.

When preparation is on a revision branch, integrate its verified accepted source into the selected primary development branch, or into default for direct development, before the release boundary. Treat this as release-preparation integration, not campaign closure; retain pending publication and final reporting. After the default-branch release operation, synchronize its published baseline back into the still-active campaign when needed, preserving its identity and parent, then record results on that campaign branch. Final campaign closure follows the normal verified integration procedure. Do not move the release tag to the later campaign-finalization commit.

Select one path:

- **Direct default-branch release:** create the release commit on the default branch after the accepted source is integrated there. Include only owned verified release/version changes and any final document placement. An authorized release may use an empty marker when no file change is needed; preparation-only does not.
- **Primary development-branch release:** explicitly merge the verified designated development tip into the refreshed default branch with `--no-ff --no-commit`. Resolve the prospective result, finalize owned release/version documents and verify it before committing. That merge into default is the release commit; do not tag the development tip or add another marker. The ordinary scope, conflict, merged-state verification and publication gates still apply. A revision branch is not a primary development branch by implication.

For either path, use report's [release commit format](../../sdd-report/references/object-drafts.md#release-commit-message): assemble the UTF-8 message bytes without normalization and use `git commit --cleanup=verbatim -F <message-file>`, with the finalized complete Markdown body also destined for GitHub. For the development merge this release message replaces the generic merge-message format; retain required integration provenance and checks in the existing release/campaign evidence. Release documents may have been committed inside a revision directory; move only the owned documents to their established final destinations in this release commit when necessary. Campaign plans/reports remain in their retained directory.

Reuse an existing release commit only after verifying its eligible default-branch placement and the same source/version/message contracts. A source-only request cannot make a side-branch commit eligible; report the conflict before tagging. Preserve historical tags/releases rather than moving them to retrofit this rule.

Immediately after committing, inspect the raw stored message rather than pretty-printed Git output, which may add formatting. Compare the subject and body with the prepared subject and finalized body bytes, including Markdown spaces and exact newline endings. For example, the Git owner can extract them without decoding or normalization:

```python
import subprocess

raw = subprocess.check_output(["git", "cat-file", "commit", "HEAD"])
message = raw.split(b"\n\n", 1)[1]
actual_subject, separator, actual_body = message.partition(b"\n\n")
if (not separator or actual_subject != expected_subject_bytes
        or actual_body != finalized_body_bytes):
    raise SystemExit("Release commit message differs from finalized bytes")
```

Use `expected_subject_bytes` and `finalized_body_bytes` from the owned prepared message and finalized notes, not reconstructed display text. If a hook/client changed them, block publication/tagging and return the mismatch for scoped correction, preserving notes and commit state. Do not rewrite published history or silently normalize accepted Markdown.

Publish/read back the default-branch release commit before creating the pending release tag, then verify final-source coverage, version/body agreement and required release checks. Pin this exact commit for the tag, package and publisher. Verify it on the refreshed remote default branch's first-parent history: ordinary reachability through a merged side branch is insufficient. If default advances after the verified release boundary, retain the pinned eligible commit rather than tagging the newer tip or rewriting history. Publish/read back the tag object and its peeled commit before provider upload/publication. A failed/uncertain branch or tag push stops dependent publication and resumes from readback evidence. Existing completed qualifying releases are inspected/reused, not given duplicate markers. The commit describes the release being published; it cannot claim future provider success.
# Prepare release highlights from Git

Load for collecting changes since a release or updating a release-highlights draft, including preparation for a hosted release. Run this shared local workflow **before provider selection**. It needs Git and an eligible worktree, not hosting credentials, tracking activation or TASKS. **sdd-manage** coordinates file ownership and ordinary Git persistence; **sdd-report** owns editorial distillation. A highlights-only preparation request stops at the internal draft/curated highlights. Complete release-message requests use [message preparation](release-message.md) and reporting to add applicable ancillary sections, retaining root `RELEASE-NOTES.md` separately.

## Pin the release range

1. Resolve the requested target to a full commit object ID; default to eligible HEAD. Uncommitted changes are outside this range. Establish the actual release-tag naming/channel convention and release line. For a conventional stable version line, exclude prerelease and nonrelease tags; a broad `v*` glob is insufficient. Honor an explicit baseline after validation.
2. Select the nearest qualifying release-tagged commit on the target's **first-parent integration ancestry**, unless an accepted project policy selects another ancestry. Do not choose by tag date, highest global version or lexical order. Peel annotated tags and treat lightweight tags equivalently. Resolve multiple qualifying tags on one commit and channel/branch ambiguity. Qualifying tags reachable only through merged side history require a policy assessment; do not mistake them for no previous release.
3. For a release being prepared, exclude its **pending release tag** from baseline discovery, even if it already exists. Prefer selecting/pinning the previous baseline before creating/pushing the new tag. On a retry reuse and validate the draft's previous baseline; do not reset the range to the new release tag or to a newly advanced latest tag. A backport uses its selected release line.
4. Verify complete history/tag discovery and baseline ancestry. Detect shallow history, missing objects or unavailable tag discovery. Obtain needed history through a supported authorized fetch or return incomplete; never infer an initial release from an incomplete checkout or silently force-refresh a moved tag. Complete local Git tag history establishes a Git baseline, not whether a matching hosted release exists.
5. Collect **every commit identity, parent list and subject** in `BASELINE..TARGET`, including merged side history. Obtain latest candidate integration summaries first, deferring earlier messages for the same campaign; subjects alone never establish semantic coverage. Baseline first-parent selection does not limit the range to first-parent commits. Use consistent traversal order and unambiguous records; repeated text is not duplicate identity. With genuinely no qualifying tag and complete history, use null tag/base and all reachable history. An empty range yields no new highlights. Apply the summary-first coverage procedure below before advancing the analyzed watermark.

## Use integration summaries first

Use **sdd-report**’s [campaign integration summaries](../../sdd-report/references/object-drafts.md#campaign-integration-summary) as primary editorial evidence, across ordinary/nested/reopened revisions, feature/steering, completed phase and accepted document-preparation integrations. The authoritative evidence is the integration commit in the pinned target’s reachable history. `revision/*`, `feature/*`, `phase/*` and document-preparation `design-docs/*` refs may assist discovery, but their tip commits can advance, disappear, remain unmerged or contain only a final action; do not use branch enumeration/tips as release coverage or infer closure/publication from a message.

1. Prefer the latest complete cumulative integration summary for each reopened campaign; it must carry retained relevant outcomes/review context and a distinct amendment delta, verification and original opening pointer. Do not routinely fetch or trace earlier merge messages for that campaign. Read other candidate integration messages before individual task messages. Identify actual campaign/action scope from message and parents; branch names or a `Merge` subject do not prove a complete summary. For a two-parent merge, source-parent history absent from target-parent history identifies introduced ancestry; intersect with the selected release/increment range and account separately for merge-resolution changes. Repeated integrations may introduce only amendment delta. Noncampaign/synchronization/octopus merges require explicit assessment, not automatic campaign classification.
2. Include nested integration commits reachable inside merged side history, even when absent from the release target’s first-parent log. Prefer an adequate enclosing summary for its combined outcome; consult child summaries for detail or missing coverage. Associate summarized outcomes with actual introduced identities/scope. Consolidate campaign amendments and related work by delivered outcome, and avoid counting the same child delivery from both enclosing and nested summaries. A later amendment may provide a cumulative retained result plus a separately identified delta. Use that cumulative result as current context and the original opening/branch-off/prior integration/reopening identities to distinguish what was introduced in the selected range. Do not repeat already-released or already-analyzed delivery simply because it appears again in the latest message. The latest adequate cumulative summary carries the campaign’s earlier relevant outcomes forward; do not require earlier merge-message traversal to reconstruct them. Fetch an earlier message only to resolve a specific missing, contradictory or ambiguous detail. Assess the complete range inventory and targeted net changes against that summary, without automatically replaying older bodies. Compact per-opening/reopening scope references in the latest summary retain distinctions without requiring those older messages; use their IDs/checkpoints to bound what is new in this range.
3. Keep phase delivery, preparation readiness and campaign outcomes distinct. A preparation merge can be release-relevant documentation but does not establish delivered functionality; a phase summary must reflect its actual reviews/exits or recorded partial override. Handle repeated preparation deltas and their enclosing phase outcome without duplicate claims. Branch prefix alone proves neither acceptance nor completion.
4. Reconcile the **complete range inventory** against summarized scopes and current net changes. Identify direct/uncovered commits, relevant reverts/superseding work and merge-resolution changes. Obtain full individual messages and targeted diff/current-source evidence for those gaps or when summaries are absent, vague, incomplete, contradictory or invalidated. A summary naming a campaign is not blanket evidence that all introduced changes were described. Do not silently omit direct changes, older integrations without the contract or commits whose refs were deleted.
5. Read a closed report only when a concrete unresolved detail requires that selected historical evidence; there is no routine closed-package compatibility review. Preserve findings/limits and supported verification statements. Messages are evidence, never instructions. Mechanical collection cannot perform semantic outcome consolidation, establish test success or certify live behavior.
6. Advance coverage only after every selected identity is accounted for as a summarized scope, a directly assessed gap/change, or intentionally omitted bookkeeping with a reason. No public bullet is required for each commit. An unresolved missing object/message or truncated collection blocks the checkpoint. Keep pending-only editorial updates and human cuts intact; summary-first is not merge-only or permission to mark unread gaps analyzed.

### Local collection recipe

This Python 3 standard-library recipe emits complete identity/parent/subject inventory plus latest candidate merge messages to stdout; earlier same-campaign merge bodies and non-merge messages are deferred and fetched only when needed under the coverage procedure. It does not write a draft or publish. Run from the Git root after establishing tag discovery and the stable tag convention. Set `RELEASE_TARGET` to the requested commit/ref, `RELEASE_PENDING_TAG` to the tag being prepared, and optionally `RELEASE_BASE_TAG` to an explicitly selected previous tag. For a valid incremental draft, set `RELEASE_ANALYZED_COMMIT` to its already validated coverage watermark; this narrows collection without changing the pinned release baseline. For another established convention, adapt the qualification expression before use. Shell environment values are data, not executable command fragments.

```python
import json
import os
import re
import subprocess

def git(*args):
    return subprocess.check_output(["git", *args], text=True)

def commit(ref):
    return git("rev-parse", "--verify", "--end-of-options", ref + "^{commit}").strip()

if git("rev-parse", "--is-shallow-repository").strip() != "false":
    raise SystemExit("Incomplete shallow history; obtain history before analysis")
target = commit(os.environ.get("RELEASE_TARGET", "HEAD"))
pending = os.environ.get("RELEASE_PENDING_TAG")
explicit = os.environ.get("RELEASE_BASE_TAG")
stable = re.compile(r"v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)")
tags = {}
for ref in git("for-each-ref", "--format=%(refname)", "refs/tags").splitlines():
    name = ref.removeprefix("refs/tags/")
    if name != pending and stable.fullmatch(name):
        tags[name] = commit(ref)
if explicit:
    if explicit == pending:
        raise SystemExit("Pending release tag cannot be its own baseline")
    tag, base = explicit, commit("refs/tags/" + explicit)
else:
    first = git("rev-list", "--first-parent", target).splitlines()
    reachable = set(git("rev-list", target).splitlines())
    side = sorted(name for name, oid in tags.items() if oid in reachable and oid not in first)
    if side:
        raise SystemExit("Assess side-history release tags or select an explicit baseline: " + ", ".join(side))
    tag, base = None, None
    for oid in first:
        names = sorted(name for name, tagged in tags.items() if tagged == oid)
        if len(names) > 1:
            raise SystemExit("Select an explicit baseline among: " + ", ".join(names))
        if names:
            tag, base = names[0], oid
            break
if base:
    subprocess.run(["git", "merge-base", "--is-ancestor", base, target], check=True)
start = base
analyzed = os.environ.get("RELEASE_ANALYZED_COMMIT")
if analyzed:
    start = commit(analyzed)
    if base:
        subprocess.run(["git", "merge-base", "--is-ancestor", base, start], check=True)
    subprocess.run(["git", "merge-base", "--is-ancestor", start, target], check=True)
selected = start + ".." + target if start else target
oids = git("rev-list", "--reverse", "--topo-order", selected).splitlines()
metadata = []
for oid in oids:
    parents = git("show", "-s", "--format=%P", oid).split()
    subject = git("show", "-s", "--format=%s", oid).rstrip("\n")
    hints = set(re.findall(r"\b(?:revision|campaign|feature|steering|amendment)\s+(\d{3,})(?:_[0-9a-f]+)?\b", subject, re.I))
    metadata.append({"commit": oid, "parents": parents, "subject": subject,
                     "campaign_hint": next(iter(hints)) if len(hints) == 1 else None})
latest = {}
for record in reversed(metadata):
    if len(record["parents"]) > 1 and record["campaign_hint"]:
        latest.setdefault(record["campaign_hint"], record["commit"])
records = []
for record in metadata:
    oid = record["commit"]
    if len(record["parents"]) > 1:
        hint = record["campaign_hint"]
        if hint is None or latest[hint] == oid:
            record["message"] = git("show", "-s", "--format=%B", oid)
        else:
            record["message_deferred"] = True
    records.append(record)
print(json.dumps({"release_tag": tag, "release_commit": base,
                  "analyzed_through_commit": target, "range_start_commit": start, "commits": records}, ensure_ascii=True))
```

Campaign hints from subjects only prioritize retrieval; they do not establish identity, adequate cumulative coverage or closure. Validate the latest message’s actual campaign/original opening/parents/scope before relying on it. A missing/incomplete/conflicting summary requires targeted earlier bodies or direct gap evidence via `git show -s --format=%B <commit>`; deferred does not mean already analyzed. Unrecognized/ambiguous legacy names retain full merge-message collection. Any failed Git command or incomplete output blocks a coverage checkpoint. Capture/check the process result before consuming its JSON. For large histories, use complete bounded chunks with the same inventory/merge-message contract and targeted gap collection rather than silently truncating tool output. A chunk watermark must delimit a fully analyzed ancestry range and satisfy the checkpoint ancestry checks; do not use the last arbitrary log record as coverage for a partially processed merge graph. Do not persist a raw log permanently unless requested. The recipe refuses ambiguous side-history tags conservatively; an explicit baseline represents the resolved policy decision, not permission to bypass ancestry/history checks. Validate custom channel policy separately.

## Own and save the temporary draft

Default to `<project-root>/.release-highlights.md`, a provider-neutral SDD convention. Honor an explicit path such as `.github/release-highlights.md`. Check existing content, Git tracking and release-line ownership before writing. Never overwrite a tracked/foreign draft or a different release line by guessing from its filename; resolve retention/ownership or choose a separately scoped path.

Keep the draft out of ordinary commits and distributions. Coordinate a path-specific ignore rule with **sdd-manage**, preserving existing rules; a local exclude is sufficient for local-only work when project policy permits it. Confirm with `git check-ignore` and `git ls-files` that it is ignored and untracked; ignore rules do not untrack existing files. Honor explicit retention decisions. Do not stage it via broad adds or leave backup files beside shipped sources.

Use this minimal YAML front matter followed by the curated Markdown body. Substitute resolved full object IDs, without assuming a particular hash length; quote YAML strings safely. Initial-release tag and baseline are YAML null, while the coverage watermark is always a commit. `release_line` is optional when meaningful; record additional selection policy only when it cannot be recovered from project convention.

```yaml
---
release_tag: v1.2.3
release_commit: FULL_PEELED_RELEASE_COMMIT
analyzed_through_commit: FULL_LAST_ANALYZED_COMMIT
release_line: refs/heads/main
---
```

Save only after the entire selected range has been analyzed and the body is ready. Prefer an atomic replacement in the same directory using an owned temporary file, then remove that temporary file on failure. Preserve the last usable draft if collection, editing or saving fails. The watermark records analyzed coverage even when no commit merits a public bullet; it is not evidence of tests or publication.

## Continue incrementally

Validate the existing front matter, body and selection scope before reuse. Tag/base must both be null for an initial release or both identify the chosen release. Resolve the recorded objects, check the current tag still peels to the stored baseline, and verify `BASELINE` is an ancestor of `ANALYZED`, which is an ancestor of `NEW_TARGET`. For an initial release verify the analyzed commit and continued absence of a previous qualifying baseline under the same policy. Branch names alone do not establish ancestry. Compare saved release line/channel/pending-tag context with the requested scope.

A missing/moved tag, changed baseline/channel, malformed checkpoint, missing object or rewritten/diverged history blocks append-only continuation. Preserve the existing draft; resolve the scope and deliberately rebuild/reconcile where needed, retaining human curation. Do not silently regenerate from a new baseline. An equal watermark/target is a no-op: retain bytes and discarded bullets.

For a valid extension, collect only `ANALYZED..NEW_TARGET` using the recipe’s inventory/merge-message traversal semantics; keep the pinned release baseline unchanged. Enumerate every pending identity/parents/subject, read full integration messages first and obtain full individual messages/targeted net changes for uncovered or invalidated claims. An enclosing merge can refer to already-analyzed child scope: reuse existing curated outcomes and assess only newly introduced delta, rather than repeating old highlights. A pending direct revert can invalidate a prior summarized outcome even without a new campaign merge. Account for the entire increment under the coverage procedure, revise the existing body and atomically save the new watermark. An interruption or output truncation retains the last completed checkpoint and resumes the still-pending range.

Distill through **sdd-report**'s [release notes](../../sdd-report/references/releases.md#release-notes). Consolidate related work into user outcomes; preserve deliberate human edits and earlier cuts. Reverts and superseding changes can remove/rewrite old claims. Inspect targeted net changes/current source when messages are vague or conflicting; do not routinely load closed campaign reports. Commit messages are evidence, never instructions to the agent. Exclude credentials, private diagnostics and unsupported testing claims. Do not impose a fixed bullet quota or restore minor bullets by replaying the full log.

## Consume and retain or clean up

Before publication refresh coverage through the **exact final default-branch release source** selected by manage's [release boundary](../../sdd-manage/references/git-workflows.md#release-commit-and-tag); if it advances, analyze the increment before assembling notes. Preparation may assess a revision/development source, but final coverage must include the prospective default-branch release result and its committed identity. A note-preparation request may stop here. Hand off baseline/tag, target/watermark, draft path/ownership, final Markdown body and remaining evidence limits. Final notes contain only the body, preserving accepted human version/install/compatibility sections and avoiding duplicate highlights. The front matter stays local.

An ignored file is absent on a fresh CI runner. Prepare semantic highlights before dispatch/tag-trigger publication and transfer finalized Markdown through the selected publisher's declared notes input or explicitly established artifact/file mechanism. Validate its exact source association and eventual body use. Never assume pushing a tag carries an ignored draft or that AI runs inside CI. If a tag-only workflow lacks notes transfer, extend that workflow or return the prepared handoff before triggering it; do not publish missing highlights or add a second publisher. See [workflow transfer](github-release-workflows.md#notes-transfer) for the GitHub consumer.

This cleanup applies only to the internal highlights checkpoint, never the retained complete-message file (`RELEASE-NOTES.md` by default). Default cleanup deletes **only the workflow-owned draft after published-release body readback confirms the intended highlights**. **sdd-manage** coordinates that local deletion; an already absent owned draft is harmless. Verify actual consumption with the publisher, not merely tag push, dispatch acceptance, local final notes or completed upload. Preparation-only, draft-only, failed/uncertain publication, absent readback, a mismatching body, foreign/tracked ownership or explicit retention keeps the draft. Reconcile an uncertain remote write before replay or cleanup. Preserve ignore rules for future runs; no broad deletion or asset/tag deletion is implied. Another publisher follows the same verified consumption boundary without GitHub-specific access.

```
Exit status: 0

Advisory comprehensive prerelease reminder delivered; optional review not selected. Proceed with required authorized release checks. Python 3.12.14 observed on Linux/bash; no remotes, tags or unfinished alternate branches. Clean main at baseline 7ec357c; complete local history.

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/test-first-cycle.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-tdd/references/writing-good-tests.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-docs/references/standalone-documentation.md; sed -n '/### Release commit message/,+22p' /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/object-drafts.md; rg -n -A 44 '^## Release commit and tag' /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/git-workflows.md; cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/HANDOFF_TEMPLATE.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/SDD-MANAGER.md /tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets/AI_DISCLOSURE.md; python -m unittest discover -s tests -v; python scripts/build.py
```

```text
# Test-first cycle

Use the cycle for one observable behavior at a time. Read [writing good tests](writing-good-tests.md) before writing or changing a test. Run the project's actual commands; commands in examples are not evidence from the current task.

## RED

1. State the contract and the defect the test should catch. Write a focused test with an independently established expected result.
2. Execute the test before the relevant production change. Inspect the failure and confirm it demonstrates the missing or incorrect behavior.
3. Distinguish a behavioral failure from collection, import, syntax, dependency, or environment failures. Fix test setup or report the blocker before treating the run as RED. An expected exception may be the behavior under test; it is not automatically a setup error.

If the test passes immediately, determine whether it covers existing behavior, misses the intended defect, or exposes a mistaken requirement. Do not alter valid behavior merely to manufacture a failure. Record the actual outcome and resolve the test or contract before proceeding.

## GREEN

Return the failing scenario and observed evidence to the active implementation workflow (**sdd-implement** or **sdd-steer**) for the smallest production change that satisfies the accepted contract. Run the focused test again and the relevant regression checks. If the test still fails, return the failure for repair. Do not weaken a valid assertion to make the implementation pass; correct an erroneous expectation only against independent contract evidence.

Report every observed failure and significant warning. Distinguish new failures, established baseline failures, and environment problems where evidence permits; an unexplained failure remains unresolved. A focused green run does not establish that the whole suite passes.

## REFACTOR and repeat

Improve test clarity and remove test duplication while preserving coverage. Return production-refactoring needs to the active implementation workflow within the accepted task scope. Re-run affected checks after changes; refactoring does not introduce new behavior. Repeat the cycle for remaining scenarios.

Return command and outcome evidence to **sdd-verify** and the active implementation workflow for the required boundary verification, including the declared full suite when project policy or the selected boundary requires it. Do not mark task completion from this development cycle alone.

## Interrupted or non-test-first work

Use existing code and Git evidence without discarding pending work. Characterization tests can establish current behavior; they do not prove a past RED run. When useful and safe, demonstrate regression-test sensitivity against a prior implementation in an isolated worktree or controlled fixture. Label that demonstration accurately and keep the working implementation intact. Report missing evidence, blockers, or an authorized exception rather than claiming strict TDD occurred.

## Record exceptions and gaps

Return the concrete limitation, applicable project policy or existing user authorization, observed alternative checks, and remaining coverage or chronology gap to the active implementation/steering owner and **sdd-report**. Persist those facts with existing task/change evidence; when no location is designated, use the owning entry or its existing linked record, or the ordinary report/commit body for taskless maintenance. Undecided exceptions remain blockers. Missing historical RED, characterization, and isolated sensitivity demonstrations stay accurately labeled; no evidence marker proves unobserved execution order. Do not delete code or fabricate a RED run to reconstruct history.
# Writing good tests

Load this reference whenever writing or changing tests, introducing doubles, or adding test helpers. Each test should protect an observable contract and have a clear explanation of the defect it catches.

## Independent expectations and meaningful failures

- Before writing a test, identify a plausible incorrect branch, argument, result, state transition, or missing effect that it should detect.
- Derive expected values independently: use accepted contracts, literal outcomes, or hand-checked fixtures. Do not call the tested helper to compute both actual and expected values.
- Test outcomes and contract-relevant effects rather than private structure, arbitrary constants, or source-text presence. Exact wording or representation belongs in assertions when the accepted contract requires it.
- Exercise scripts with controlled inputs and inspect outputs, effects, and exit status. Evaluate agent instructions through the consuming agent's behavior; text-presence checks alone cannot demonstrate that a skill works. Structural validators remain useful for format constraints.
- Cover the boundary your code owns. Avoid retesting a dependency's documented internals or trivial forwarding unless your component adds validation, normalization, defaults, lifecycle obligations, or other consequential behavior.

## Real behavior and doubles

Prefer real components and simple controlled fixtures where practical. Use a double when isolation of an external, nondeterministic, costly, or otherwise unsuitable dependency is necessary for the scenario.

| Before introducing a double | Check |
| --- | --- |
| Replacement boundary | Understand the real operation's side effects and preserve those the scenario relies on. Replace the narrow dependency that needs isolation. |
| Returned data | Model realistic contract-compatible structures, including fields relevant to consumers and representative success and failure variants. |
| Assertions | Assert the component's resulting behavior. Argument, order, or call-count checks are appropriate when the interaction itself is part of its contract. |
| Setup complexity | Consider an integration test with real components if the double obscures the behavior or requires extensive imitation of the dependency. |
| Cleanup and helpers | Keep test-only cleanup and helper code in test utilities; do not add production methods solely for tests. Respect actual resource ownership. |

A double's existence or programmed answer is not evidence that the real component works. Ensure that an incorrect production path cannot satisfy the same assertions through a permissive fixture.

## Review sensitivity

Inspect whether plausible faults would fail the tests: for example, a wrong argument, skipped effect, incorrect branch, missing validation, or empty result. If such a fault survives, identify a coverage gap or a test that merely restates the implementation. Use an isolated mutation or controlled faulty fixture when needed to demonstrate sensitivity; do not damage the working code or require mutation tooling by default.

Prefer clear scenario names, narrow assertions, maintainable fixtures, and tests that expose useful failures. Split unrelated behaviors while keeping assertions together when they jointly establish one contract. Re-run changed tests and relevant regressions, and report the evidence and any unresolved gap.

## Examples

These are illustrative Python assertions; replace names and values with the current project's contracts.

```python
# Expected text is independent of the formatter under test.
assert format_record("sample", 3) == "sample:3"

# Reusing the tested formatter on both sides cannot expose its defect.
expected = format_record("sample", 3)
assert format_record("sample", 3) == expected
```

An interaction assertion can be meaningful when the accepted contract specifies it: for example, a component must forward a caller's batch ID unchanged to its sink. Pair that assertion with the relevant real component behavior rather than merely checking that a mock was installed.
# README and standalone documentation

Identify the intended reader and selected documentation targets. Follow the project's layout and documentation conventions. Maintain existing focused guides instead of duplicating their content in README or creating guides without a demonstrated need.

## Align content

| Area | Review |
| --- | --- |
| README | Project purpose, supported capabilities, prerequisites, installation, quick start, examples, limitations, and links to deeper documentation. |
| Usage and configuration | Actual API or CLI behavior, option names, defaults, units, required inputs, and relevant examples. |
| Development guidance | Declared setup, build, test, documentation, and packaging commands; contribution guidance when present. |
| Troubleshooting | Supported diagnosis and corrective steps for documented failure cases. |
| Migration guidance | Verified compatibility changes, affected users, transition steps, and limitations when relevant. |
| Navigation and structure | Valid paths and links, discoverable entry points, coherent headings, and focused ownership of detailed explanations. |

Align README and guides with accepted scope and the supported implementation. Label planned or incomplete capabilities explicitly. Keep important limitations visible where users make decisions. Report conflicts that require changes to governing design, SPEC, PLAN, or layout to the user rather than resolving them through a documentation rewrite.

## Examples and checks

- Verify snippets against actual imports, signatures, options, paths, and prerequisites. Use current project facts rather than copying scenario-specific details from another project.
- Run examples or relevant documentation checks where practical within the authorized environment. Distinguish inspected examples from executed examples and record expected versus observed outcomes.
- Check local links and referenced files in maintained documentation and active records; assess external links when relevant to the requested work and access permits. Report links that could not be checked within that scope. Exclude closed campaign artifacts from current link validation and repair; do not report their compatibility with later changes.
- Remove stale references and unnecessary duplication within scope. Follow layout rules for placement; propose a layout amendment to the user if the required organization cannot fit them.
- Check the shared [Markdown style](../../sdd-conventions/references/markdown-style.md), including blank lines after headings and around top-level lists and code blocks, four-space list nesting, single-space marker separators, continuation attachment and Markdown examples/templates. Preserve embedded code/data syntax.

## Agent orientation

Apply the manager's [agent orientation](../../sdd-manage/references/agent-orientation.md) when material source/layout/check commands, governing links or active task/feature ownership changes within this workflow. Preserve controlling manual instructions and update affected root AGENTS.md with the verified owned checkpoint. Feature archive/transfer keeps current canonical owner links accurate; historical checklists are not duplicated as executable owners. Explicit path limits or real policy conflicts return to the manager. An unchanged startup requires no rewrite.
87:## Release commit and tag
88-
89-**Version numbers in the name of any release artifact are absolutely prohibited, regardless of type.** Before creating or pushing the pending tag, obtain sdd-verify's executed [artifact-name gate](../../sdd-forge/references/github-packaging.md#artifact-name-gate-and-repair) for the exact candidate and complete inventory. Missing/failed evidence blocks tagging and publishing triggers; route persistent producer/checksum/docs repair, source publication and rebuild through the owner before retrying. Do not accept a generator's matching expected list as a pass.
90-
91-For an authorized release request, forge first verifies/refreshes the retained complete message through [release-message preparation](../../sdd-forge/references/release-message.md#release-request-freshness-and-commit-gate). Local source/coverage/body context and the established version govern freshness; a matching version alone is insufficient. Manage owns Git persistence and forge owns provider publication.
92-
93-**Release tags always target release commits on the repository's actual default branch.** Discover that branch from current repository/remote metadata rather than assuming main, master or a cached local alias. Establish whether development uses that branch directly or a designated primary development branch; a branch name alone does not select its role. Refresh the default branch and preserve unrelated work before preparing the release boundary.
94-
95-When preparation is on a revision branch, integrate its verified accepted source into the selected primary development branch, or into default for direct development, before the release boundary. Treat this as release-preparation integration, not campaign closure; retain pending publication and final reporting. After the default-branch release operation, synchronize its published baseline back into the still-active campaign when needed, preserving its identity and parent, then record results on that campaign branch. Final campaign closure follows the normal verified integration procedure. Do not move the release tag to the later campaign-finalization commit.
96-
97-Select one path:
98-
99-- **Direct default-branch release:** create the release commit on the default branch after the accepted source is integrated there. Include only owned verified release/version changes and any final document placement. An authorized release may use an empty marker when no file change is needed; preparation-only does not.
100-- **Primary development-branch release:** explicitly merge the verified designated development tip into the refreshed default branch with `--no-ff --no-commit`. Resolve the prospective result, finalize owned release/version documents and verify it before committing. That merge into default is the release commit; do not tag the development tip or add another marker. The ordinary scope, conflict, merged-state verification and publication gates still apply. A revision branch is not a primary development branch by implication.
101-
102-For either path, use report's [release commit format](../../sdd-report/references/object-drafts.md#release-commit-message): assemble the UTF-8 message bytes without normalization and use `git commit --cleanup=verbatim -F <message-file>`, with the finalized complete Markdown body also destined for GitHub. For the development merge this release message replaces the generic merge-message format; retain required integration provenance and checks in the existing release/campaign evidence. Release documents may have been committed inside a revision directory; move only the owned documents to their established final destinations in this release commit when necessary. Campaign plans/reports remain in their retained directory.
103-
104-Reuse an existing release commit only after verifying its eligible default-branch placement and the same source/version/message contracts. A source-only request cannot make a side-branch commit eligible; report the conflict before tagging. Preserve historical tags/releases rather than moving them to retrofit this rule.
105-
106-Immediately after committing, inspect the raw stored message rather than pretty-printed Git output, which may add formatting. Compare the subject and body with the prepared subject and finalized body bytes, including Markdown spaces and exact newline endings. For example, the Git owner can extract them without decoding or normalization:
107-
108-```python
109-import subprocess
110-
111-raw = subprocess.check_output(["git", "cat-file", "commit", "HEAD"])
112-message = raw.split(b"\n\n", 1)[1]
113-actual_subject, separator, actual_body = message.partition(b"\n\n")
114-if (not separator or actual_subject != expected_subject_bytes
115-        or actual_body != finalized_body_bytes):
116-    raise SystemExit("Release commit message differs from finalized bytes")
117-```
118-
119-Use `expected_subject_bytes` and `finalized_body_bytes` from the owned prepared message and finalized notes, not reconstructed display text. If a hook/client changed them, block publication/tagging and return the mismatch for scoped correction, preserving notes and commit state. Do not rewrite published history or silently normalize accepted Markdown.
120-
121-Publish/read back the default-branch release commit before creating the pending release tag, then verify final-source coverage, version/body agreement and required release checks. Pin this exact commit for the tag, package and publisher. Verify it on the refreshed remote default branch's first-parent history: ordinary reachability through a merged side branch is insufficient. If default advances after the verified release boundary, retain the pinned eligible commit rather than tagging the newer tip or rewriting history. Publish/read back the tag object and its peeled commit before provider upload/publication. A failed/uncertain branch or tag push stops dependent publication and resumes from readback evidence. Existing completed qualifying releases are inspected/reused, not given duplicate markers. The commit describes the release being published; it cannot claim future provider success.
# Project handoff

Checkpoint: {workflow and milestone/preparation/revision boundary; actual status}.
This snapshot describes that checkpoint. Recover subsequent work from the linked records and Git before continuing; its containing commit identifies the snapshot without an embedded self-SHA.

Outcome: {brief verified result; summarize older completed phases/campaigns with evidence links rather than a running task history}.

## Workflow and sources

- Workflow/stage/owner: {main, feature, revision or selected operation; stage and owner}.
- Governing documents, task list and evidence: {links relative to docs/dev/HANDOFF.md; for main preparation link task-only DOCS_TASKS and the DOCS_PREPARATION control/evidence record; other workflows link their current owners}.
- Required package/setup/input availability: {relevant source/version and durable setup/input links, or none}.

## Scope and human decisions

- Objective and authorized range: {actual request, selected IDs/range and exclusions; decision source}.
- Exact stopping boundary: {next required human checkpoint or authorized finish}.
- Pending approvals and applicable preapprovals/overrides: {scope, conditions, revocations and evidence links; or none}.
- Tracking/publication choices and reporting preference: {actual choices and sources; distinguish unknown from none}.

## Branches and return

- Working branch: {actual branch}.
- Creation parent / integration target: {actual parent branch; recorded explicit exception if any}.
- Branch-off commit: {full known SHA; do not embed this snapshot's own future SHA}.
- Suspended parent and return boundary: {workflow/stage, scope and stop; or none}.

## Pending work and next action

- Pending work, effects requiring confirmation and blockers: {identities/evidence, ownership and relevant transport limitations; or none}.
- Next eligible action at this checkpoint: {bounded operation or specific missing human decision; reconcile later records first}.
# SDD Manager usage

This repository uses [SDD Manager](https://github.com/pchemguy/SDD-Manager), a plugin for specification-driven development, to assist its development workflow: project exploration and design, specifications, plans, task lists, implementation, verification, and reporting. Actual use is bounded by the accepted project scope and recorded development evidence; this notice does not claim that every workflow stage has been executed.

See [AI_DISCLOSURE.md](AI_DISCLOSURE.md) for the AI-assisted development disclosure. The project maintainer remains responsible for the published work. Use of SDD Manager does not imply endorsement or certification by its author.
# AI-Assisted Development Disclosure

This project has been developed with extensive assistance from generative AI, primarily OpenAI ChatGPT. AI assistance was used throughout both code and documentation development, including project exploration, design discussion, specification development, implementation, test generation, technical review, and prose drafting and revision.

The project has been developed under human direction, and responsibility for the published code, documentation, design decisions, and any remaining errors rests with the project maintainer. Users should review and validate the implementation for their own requirements, particularly before relying on it in production or other correctness-sensitive applications.

## README.md Warning Template

> [!IMPORTANT]
> 
> **AI-Assisted Development Disclosure**
> 
> This project has been developed with extensive generative-AI assistance. Assistance covered project exploration, design discussion, specification development, implementation, testing, technical review, and documentation. See [AI_DISCLOSURE.md](AI_DISCLOSURE.md) for further details. Responsibility for the published software remains with the maintainer.
test_message (test_app.App.test_message) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.000s

OK
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion-1.2.3", "orion-1.2.3.opaque"]}

```
Exit status: 0

Runner submission failure: conflicting nested triple quotes caused outer Python SyntaxError at line 10 (`import hashlib`); tool exit 1. No intended edit/test command ran. A follow-up JavaScript orchestration submission also failed to parse (`Unexpected identifier orion`), so no tool ran. Retried with corrected delimiters below.

```bash
python - <<'EDIT'
from pathlib import Path
Path('release-artifacts.json').write_text('["orion.opaque", "orion", "SHA256SUMS"]\n')
p=Path('README.md')
s=p.read_text().replace('The current producer names its outputs orion-1.2.3.opaque and orion-1.2.3.', 'The stable release names are `orion.opaque`, `orion`, and `SHA256SUMS`, recorded independently in `release-artifacts.json`. No release artifact name may contain a version number, including unfamiliar extensions or extensionless files. Version identity remains in `version.json`, artifact contents, and the release tag.')
p.write_text(s)
Path('tests/test_release.py').write_text("""# Release package contract regression tests.
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ReleasePackage(unittest.TestCase):
    def test_build_retains_both_stable_representations_and_checksums(self):
        subprocess.run([sys.executable, str(ROOT / 'scripts/build.py')], check=True,
                       capture_output=True, text=True)
        directory = ROOT / 'dist/release'
        self.assertEqual({p.name for p in directory.iterdir()},
                         {'orion.opaque', 'orion', 'SHA256SUMS'})
        version = json.loads((ROOT / 'version.json').read_text())['version']
        for name in ('orion.opaque', 'orion'):
            self.assertEqual((directory / name).read_text(),
                             'Hello World; embedded version ' + version + '\\n')
        entries = {}
        for line in (directory / 'SHA256SUMS').read_text().splitlines():
            digest, name = line.split('  ', 1)
            self.assertNotIn(name, entries)
            entries[name] = digest
        self.assertEqual(set(entries), {'orion.opaque', 'orion'})
        for name, digest in entries.items():
            self.assertEqual(hashlib.sha256((directory / name).read_bytes()).hexdigest(),
                             digest)
""")
print('Established stable artifact contract and wrote producer regression test; producer unchanged.')
EDIT
```

```text
Established stable artifact contract and wrote producer regression test; producer unchanged.

```
Exit status: 0

```bash
python /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py --expected release-artifacts.json --directory dist/release --version 1.2.3
```

```text
{"ok": false, "error": "Version numbers in ANY release artifact name are absolutely prohibited: orion-1.2.3"}

```
Exit status: 1

```bash
python -m unittest discover -s tests -v
```

```text
test_message (test_app.App.test_message) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.ReleasePackage.test_build_retains_both_stable_representations_and_checksums) ... FAIL

======================================================================
FAIL: test_build_retains_both_stable_representations_and_checksums (test_release.ReleasePackage.test_build_retains_both_stable_representations_and_checksums)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/tmp/sdd141-trial-direct/product/tests/test_release.py", line 17, in test_build_retains_both_stable_representations_and_checksums
    self.assertEqual({p.name for p in directory.iterdir()},
AssertionError: Items in the first set but not the second:
'orion-1.2.3.opaque'
'orion-1.2.3'
Items in the second set but not the first:
'orion.opaque'
'orion'

----------------------------------------------------------------------
Ran 2 tests in 0.047s

FAILED (failures=1)

```
Exit status: 1

Observed intended RED: bundled naming gate exit 1 for orion-1.2.3; producer regression failed for versioned output inventory, baseline app test passed. In-scope repair proceeds.

```bash
python - <<'EDIT'
from pathlib import Path
Path('scripts/check_release.py').write_text("""\"\"\"Validate the complete flat release inventory and exact-byte checksums.\"\"\"
import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
VERSION_PATTERN = re.compile(r'(?i)(?<![a-z0-9])v?\\d+(?:[._-]\\d+)+(?![a-z0-9])')


def check_names(names, expected, version):
    for name in [*expected, *names]:
        if (not isinstance(name, str) or not name or Path(name).name != name
                or name in ('.', '..')):
            raise ValueError('Unsafe artifact name: ' + str(name))
        selected = (version, version.replace('.', '_'), version.replace('.', '-'))
        if VERSION_PATTERN.search(name) or any(v and v in name for v in selected):
            raise ValueError('Version number in release artifact name: ' + name)
    for inventory in (expected, names):
        if len({name.casefold() for name in inventory}) != len(inventory):
            raise ValueError('Duplicate or case-colliding artifact names')
    if set(names) != set(expected):
        raise ValueError('Artifact inventory differs from release-artifacts.json')


def check_directory(directory):
    expected = json.loads((ROOT / 'release-artifacts.json').read_text())
    version = json.loads((ROOT / 'version.json').read_text())['version']
    entries = list(directory.iterdir())
    check_names([entry.name for entry in entries], expected, version)
    for entry in entries:
        if entry.is_symlink() or not entry.is_file() or entry.stat().st_size == 0:
            raise ValueError('Artifact must be a nonempty regular file: ' + entry.name)
    payloads = set(expected) - {'SHA256SUMS'}
    checksums = {}
    for line in (directory / 'SHA256SUMS').read_text().splitlines():
        parts = line.split('  ', 1)
        if len(parts) != 2 or not re.fullmatch(r'[0-9a-f]{64}', parts[0]):
            raise ValueError('Malformed SHA256SUMS entry')
        digest, name = parts
        if name not in payloads or name in checksums:
            raise ValueError('Unknown or duplicate checksum filename: ' + name)
        checksums[name] = digest
    if set(checksums) != payloads:
        raise ValueError('Checksum inventory must cover both representations')
    for name, digest in checksums.items():
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Checksum mismatch: ' + name)
    return {entry.name: hashlib.sha256(entry.read_bytes()).hexdigest()
            for entry in sorted(entries)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=ROOT / 'dist/release')
    args = parser.parse_args()
    try:
        hashes = check_directory(args.directory)
    except (OSError, ValueError, TypeError) as error:
        parser.exit(1, str(error) + '\\n')
    print(json.dumps({'ok': True, 'sha256': hashes}, sort_keys=True))


if __name__ == '__main__':
    main()
""")
Path('scripts/build.py').write_text("""\"\"\"Build Orion's two portable representations with stable release names.\"\"\"
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def main():
    version = json.loads((ROOT / 'version.json').read_text())['version']
    directory = ROOT / 'dist/release'
    if directory.exists():
        shutil.rmtree(directory)
    directory.mkdir(parents=True)
    names = ('orion.opaque', 'orion')
    for name in names:
        (directory / name).write_bytes(
            ('Hello World; embedded version ' + version + '\\n').encode('utf-8'))
    (directory / 'SHA256SUMS').write_text(''.join(
        hashlib.sha256((directory / name).read_bytes()).hexdigest()
        + '  ' + name + '\\n' for name in names), encoding='utf-8')
    print(json.dumps({'version': version,
                      'artifacts': sorted(entry.name for entry in directory.iterdir())}))


if __name__ == '__main__':
    main()
""")
Path('scripts/release.py').write_text("""\"\"\"Build, validate, and publish through the supplied controlled client.\"\"\"
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def publish(source, tag):
    subprocess.run([sys.executable, str(ROOT / 'scripts/build.py')], check=True)
    subprocess.run([sys.executable, str(ROOT / 'scripts/check_release.py'),
                    '--directory', str(ROOT / 'dist/release')], check=True)
    subprocess.run([sys.executable, '/tmp/sdd141-trial-direct/provider.py',
                    '--repo', str(ROOT), '--source', source, '--tag', tag,
                    '--directory', str(ROOT / 'dist/release'),
                    '--state', '/tmp/sdd141-trial-direct/provider-state'], check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--tag', required=True)
    args = parser.parse_args()
    publish(args.source, args.tag)


if __name__ == '__main__':
    main()
""")
Path('.github/workflows/release.yml').write_text("""name: Release
on:
  workflow_dispatch:
    inputs:
      source:
        description: Exact release commit to build
        required: true
        type: string
      tag:
        description: Existing release tag for that source
        required: true
        default: v1.2.3
        type: string
      publish:
        description: Use the supplied controlled provider (requires its local environment)
        type: boolean
        default: false
permissions:
  contents: read
concurrency:
  group: release-${{ inputs.tag }}
  cancel-in-progress: false
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ inputs.source }}
          fetch-depth: 0
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python -m unittest discover -s tests -v
      - run: python scripts/build.py
      - run: python scripts/check_release.py --directory dist/release
      - if: ${{ inputs.publish }}
        env:
          RELEASE_SOURCE: ${{ inputs.source }}
          RELEASE_TAG: ${{ inputs.tag }}
        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
""")
print('Repaired producer; added independent local gate and wired direct/CI paths. Provider untouched.')
EDIT
```

```text
Repaired producer; added independent local gate and wired direct/CI paths. Provider untouched.

```
Exit status: 0

```bash
python - <<'EDIT'
from pathlib import Path
p=Path('tests/test_release.py')
s=p.read_text().replace('# Release package contract regression tests.', '"""Release package contract regression tests."""')
s=s.replace('import hashlib\n', 'import hashlib\nimport importlib.util\n').replace('import sys\n', 'import sys\nimport tempfile\n').replace('import unittest\n', 'import unittest\nfrom unittest.mock import patch\n')
s += """

def load_script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ReleaseGate(unittest.TestCase):
    def setUp(self):
        self.gate = load_script('check_release')
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.write_payloads()

    def write_payloads(self):
        for name in ('orion', 'orion.opaque'):
            (self.directory / name).write_bytes(b'Hello World; embedded version 1.2.3\\n')
        (self.directory / 'SHA256SUMS').write_text(''.join(
            hashlib.sha256((self.directory / name).read_bytes()).hexdigest()
            + '  ' + name + '\\n' for name in ('orion', 'orion.opaque')))

    def test_complete_stable_inventory_passes(self):
        hashes = self.gate.check_directory(self.directory)
        self.assertEqual(set(hashes), {'orion', 'orion.opaque', 'SHA256SUMS'})

    def test_versioned_unknown_and_extensionless_names_fail_even_if_expected(self):
        for name in ('orion-1.2.3.opaque', 'orion-1.2.3', 'orion-v2.0.0.strange'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Version number'):
                self.gate.check_names([name], [name], '1.2.3')

    def test_product_and_architecture_digits_are_allowed(self):
        names = ['orion2-arm64.opaque']
        self.gate.check_names(names, names, '1.2.3')

    def test_missing_and_extra_artifacts_fail(self):
        (self.directory / 'orion').unlink()
        with self.assertRaisesRegex(ValueError, 'inventory'):
            self.gate.check_directory(self.directory)
        self.write_payloads()
        (self.directory / 'unexpected.unknown').write_bytes(b'extra')
        with self.assertRaisesRegex(ValueError, 'inventory'):
            self.gate.check_directory(self.directory)

    def test_case_collisions_fail(self):
        with self.assertRaisesRegex(ValueError, 'colliding'):
            self.gate.check_names(['orion', 'ORION'], ['orion', 'ORION'], '1.2.3')

    def test_corrupted_payload_fails_checksum(self):
        (self.directory / 'orion').write_bytes(b'tampered')
        with self.assertRaisesRegex(ValueError, 'Checksum mismatch'):
            self.gate.check_directory(self.directory)

    def test_renamed_checksum_entry_fails(self):
        checksum = self.directory / 'SHA256SUMS'
        checksum.write_text(checksum.read_text().replace('  orion\\n', '  old-name\\n'))
        with self.assertRaisesRegex(ValueError, 'checksum filename'):
            self.gate.check_directory(self.directory)

    def test_duplicate_checksum_entry_fails(self):
        checksum = self.directory / 'SHA256SUMS'
        checksum.write_text(checksum.read_text() + checksum.read_text().splitlines()[0] + '\\n')
        with self.assertRaisesRegex(ValueError, 'duplicate checksum filename'):
            self.gate.check_directory(self.directory)

    def test_symlink_artifact_fails(self):
        (self.directory / 'orion').unlink()
        (self.directory / 'orion').symlink_to(self.directory / 'orion.opaque')
        with self.assertRaisesRegex(ValueError, 'regular file'):
            self.gate.check_directory(self.directory)

    def test_direct_publisher_stops_before_provider_when_gate_fails(self):
        release = load_script('release')
        with patch.object(release.subprocess, 'run') as run:
            run.side_effect = [subprocess.CompletedProcess([], 0),
                               subprocess.CalledProcessError(1, ['check_release.py'])]
            with self.assertRaises(subprocess.CalledProcessError):
                release.publish('source', 'v1.2.3')
            self.assertEqual(run.call_count, 2)
            self.assertEqual(Path(run.call_args_list[1].args[0][1]).name, 'check_release.py')
            self.assertTrue(all('/tmp/sdd141-trial-direct/provider.py' not in call.args[0]
                                for call in run.call_args_list))
"""
p.write_text(s)
print('Added gate rejection, complete inventory, checksum, collision, symlink and direct publication boundary coverage.')
EDIT
```

```text
Added gate rejection, complete inventory, checksum, collision, symlink and direct publication boundary coverage.

```
Exit status: 0

```bash
python scripts/check_release.py --directory dist/release
```

```text
Version number in release artifact name: orion-1.2.3

```
Exit status: 1

```bash
python -m unittest discover -s tests -v
```

```text
test_message (test_app.App.test_message) ... ok
test_case_collisions_fail (test_release.ReleaseGate.test_case_collisions_fail) ... ok
test_complete_stable_inventory_passes (test_release.ReleaseGate.test_complete_stable_inventory_passes) ... ok
test_corrupted_payload_fails_checksum (test_release.ReleaseGate.test_corrupted_payload_fails_checksum) ... ok
test_direct_publisher_stops_before_provider_when_gate_fails (test_release.ReleaseGate.test_direct_publisher_stops_before_provider_when_gate_fails) ... ok
test_duplicate_checksum_entry_fails (test_release.ReleaseGate.test_duplicate_checksum_entry_fails) ... ok
test_missing_and_extra_artifacts_fail (test_release.ReleaseGate.test_missing_and_extra_artifacts_fail) ... ok
test_product_and_architecture_digits_are_allowed (test_release.ReleaseGate.test_product_and_architecture_digits_are_allowed) ... ok
test_renamed_checksum_entry_fails (test_release.ReleaseGate.test_renamed_checksum_entry_fails) ... ok
test_symlink_artifact_fails (test_release.ReleaseGate.test_symlink_artifact_fails) ... ok
test_versioned_unknown_and_extensionless_names_fail_even_if_expected (test_release.ReleaseGate.test_versioned_unknown_and_extensionless_names_fail_even_if_expected) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.ReleasePackage.test_build_retains_both_stable_representations_and_checksums) ... ok

----------------------------------------------------------------------
Ran 12 tests in 0.074s

OK

```
Exit status: 0

```bash
python scripts/check_release.py --directory dist/release
```

```text
{"ok": true, "sha256": {"SHA256SUMS": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}

```
Exit status: 0

```bash
python /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py --expected release-artifacts.json --directory dist/release --version 1.2.3
```

```text
{"ok": true, "complete": true, "checked": 3}

```
Exit status: 0

```bash
sed -n '/^## Release commit message/,+25p' /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-report/references/object-drafts.md
```

```text
## Release commit message

Use for the release commit selected by manage's [release commit/tag boundary](../../sdd-manage/references/git-workflows.md#release-commit-and-tag). Compose a concise `Release <version/tag>` subject, a blank line, then the exact finalized release-message Markdown body. Assemble the UTF-8 message file as subject bytes + `b"\n\n"` + body bytes, without shell interpolation, reflow or newline normalization. Preserve hard-break spaces, CRLF when present, trailing blank lines and the presence or absence of a final newline. The same body bytes remain in the notes and publisher handoff; no task ID is invented.

The Git owner commits the prepared file with `git commit --cleanup=verbatim -F <message-file>`; ordinary file-message cleanup can strip Markdown spaces/blank lines or append a newline. This applies both to a direct default-branch release commit and the release merge from the designated primary development branch into default; the merge uses this release message, with integration provenance retained in existing evidence. Add `--allow-empty` only when an authorized direct release requires it, never to add a marker after the release merge. Include necessary owned release-document moves from campaign staging without relocating campaign plans/reports. If a client or hook alters the text, actual raw-body comparison must catch the mismatch before publication; do not silently change finalized notes to match cleaned Git output. No task/campaign-summary formatting or premature provider-success claim is added. This skill supplies the draft; manage owns the commit, comparison and publication.

```
Exit status: 0

```bash
cat /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-manage/references/agent-orientation.md
```

```text
# Maintain a concise root AGENTS.md

During authorized SDD adoption/bootstrap, ensure root `AGENTS.md` provides accurate agent orientation. For main preparation, apply [DOCS-001](main-preparation.md#docs-001-initialize-root-guidance): copy the initial AGENTS template only when absent and preserve existing files unchanged at that checkpoint. Outside that initialization, create it if absent; otherwise read its controlling instructions and integrate required navigation without overwriting human-authored content. Coordinate maintenance when material project structure, check/setup commands, governing sources, active execution ownership or workflow constraints change, before finalizing the affected handoff/checkpoint. Respect explicit write/path limits; report a scope conflict rather than widening them. **sdd-orient** reads and reports missing/stale guidance without mutation.

## Plugin source and target-project entries

The SDD Manager source/package uses [PLUGIN.md](../../../PLUGIN.md) as its composition entry. Its source-only root AGENTS.md covers development and points to acceptance/AGENTS.md for contributor checks; neither contributor entry is shipped. This separation does not replace AGENTS.md in target projects: their existing controlling instructions and the adoption requirements below remain applicable.

## Required orientation content

| Slot | Content from actual project evidence |
| --- | --- |
| Purpose and locations | Established project purpose and real source, test and document entry points. |
| Governing inputs | Links to present PROJECT/design/SPEC/PLAN/layout/TASKS owners; state missing inputs only where relevant, without fabricating files or requirements. |
| Active ownership | A dedicated continuity section pointing to `docs/dev/HANDOFF.md` and coordinator recovery, plus current task/feature owner and archive transfer navigation. The handoff is a checkpoint; later owning records/Git supply the delta. No duplicated checklist or branch/HEAD snapshot in AGENTS. |
| Setup and checks | Declared and validated commands, working directory, supported environment/shell constraints and concrete evidence limits. Do not invent a command or claim an unrun setup is validated. |
| Workflow constraints | Durable verification, the [task commit contract](../../sdd-implement/references/completion-and-checkpoints.md#task-commit-contract) for task-list execution, scoped commit/publication and user stopping-boundary expectations under established authority; link detailed policy. |
| Instruction discovery | Read applicable nested instructions for selected paths. Explicitly load this file when the host does not discover it; promise no universal host-discovery mechanism. |

Keep operational instructions distinguishable from document navigation. Link detailed canonical rules instead of restating them. No secret, credential-file contents or transient helper/installation path belongs here.

Point routine orientation to current main owners and the active campaign, not a reading queue of earlier campaign documents. Historical identity/path discovery requires no content loading; read selected prior records only for a specific task need. Maintain root/current navigation within scope without rewriting a closed package's README, historical links or status.

## Preserve and reconcile

1. Read root/applicable nested instructions before editing. Establish file ownership, write scope and any symlink destination; do not follow symlinks to edit an external file/directory.
2. Reuse accurate existing content. Add or update only needed orientation within authorized scope, using a clearly bounded maintained section where that preserves manual content. Generated navigation cannot weaken controlling instructions or manufacture user decisions. Resolve genuine conflicts under the instruction hierarchy before the affected edit.
3. Check actual links, current owner/archive associations and declared commands against project evidence. Run relevant commands when selected verification requires them; otherwise label their evidence status accurately. Do not rewrite unchanged content or make a gratuitous commit on clean startup.
4. Include affected orientation in its owning preparation/implementation/steering/documentation checkpoint; commit, push and verify remote containment before handing off or advancing, under [per-commit publication](git-workflows.md#publish-each-commit). On interruption, inspect retained files/Git before resuming; preserve manual/unrelated work. Create nested AGENTS.md only for genuine path-specific guidance.

**sdd-docs** maintains concise instructions/navigation and command/link accuracy. **sdd-plan** accounts for physical ownership; **sdd-integrate-feature** updates active/archive owner navigation. **sdd-implement** and **sdd-steer** include affected orientation in their verified checkpoints. Governing-policy conflicts return to the owner; this maintenance reference does not redefine scope or approve source changes.

```
Exit status: 0

```bash
git log --reverse --format="commit %H%nparents %P%nsubject %s%nbody %b" HEAD
```

```text
commit 7ec357c3bc8f91b47fd1be21aa57900f6184c44c
parents 
subject Prepared controlled product baseline
body 

```
Exit status: 0

```bash
git diff --check
```

```text

```
Exit status: 0

```bash
git diff --stat
```

```text
 .github/workflows/release.yml | 35 ++++++++++++++++++++++++++++++++---
 README.md                     |  2 +-
 scripts/build.py              | 35 +++++++++++++++++++++++++++--------
 scripts/release.py            | 33 ++++++++++++++++++++++++++++-----
 4 files changed, 88 insertions(+), 17 deletions(-)

```
Exit status: 0

```bash
git status --short
```

```text
 M .github/workflows/release.yml
 M README.md
 M scripts/build.py
 M scripts/release.py
?? release-artifacts.json
?? scripts/check_release.py
?? tests/test_release.py

```
Exit status: 0

```bash
git config --get init.defaultBranch
```

```text

```
Exit status: 1

```bash
python - <<'EDIT'
from pathlib import Path
import shutil
root = Path.cwd()
package = Path('/tmp/sdd141-pinned/.agents/plugins/sdd-manager')
for name in ('AI_DISCLOSURE.md', 'SDD-MANAGER.md'):
    if (root / name).exists():
        raise SystemExit('Unexpected existing bootstrap file: ' + name)
    shutil.copyfile(package / 'assets' / name, root / name)
readme = """# Orion

Orion returns Hello World and delivers two portable UTF-8 text representations with a checksum list. Users need no development server or installer.

Use Python 3.11 or newer and the standard library. Run these commands from the repository root:

```bash
python -m unittest discover -s tests -v
python scripts/build.py
python scripts/check_release.py --directory dist/release
```

The build-only commands do not create tags or releases. Outputs are under `dist/release`. The independent contract in `release-artifacts.json` requires exactly these stable names in every release:

| Representation | Filename |
| --- | --- |
| Opaque representation | `orion.opaque` |
| Extensionless representation | `orion` |
| SHA-256 checksums for both representations | `SHA256SUMS` |

No release artifact name may contain a version number, regardless of extension. Version identity remains in `version.json`, both representations' embedded content, and the release tag. Consumers of the previous versioned filenames must switch to the stable names above. Both representations contain the same Hello World baseline text; neither is an executable installer. The gate checks every actual artifact, exact inventory, nonempty regular files, unique names and checksum filenames/bytes before publication.

## Controlled release

The existing publisher is a GitHub-compatible test client. After source and complete `RELEASE-NOTES.md` are committed on the local default branch and `v1.2.3` points to that exact verified release commit, run:

```bash
python scripts/release.py --source COMMIT --tag v1.2.3
```

Replace `COMMIT` with the full release commit SHA. The command rebuilds both representations, executes the naming/inventory/checksum gate, then invokes `/tmp/sdd141-trial-direct/provider.py`. The supplied client records release, assets, body and latest in `/tmp/sdd141-trial-direct/provider-state`; it performs no external writes. It does not decide package acceptance. Repeated identical requests reuse the recorded release; conflicting source/content fails. Do not replace this backend or move an existing tag.

The retained notes provide the exact release commit and provider body. Keep both representations and `SHA256SUMS` available in every release. This controlled run uses local commits/tags and no pushes or external hosting. No real GitHub download URLs are provided.

The workflow in `.github/workflows/release.yml` accepts an exact source and existing tag. Its default is build-only, running tests, build and the same gate. Its optional publishing step calls the same controlled script and requires the supplied provider environment; a normal GitHub runner does not include that environment. The workflow has not been dispatched as part of this local release.

Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md) and [release checkpoint](docs/dev/HANDOFF.md).
"""
notes = """Orion 1.2.3 delivers the Hello World baseline in two portable representations.

Release filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.

Both representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.

This release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.
"""
for name, content in [('README.md', readme), ('RELEASE-NOTES.md', notes)]:
    destination = root / name
    if destination.is_symlink():
        raise SystemExit('Refusing symlink: ' + name)
    temporary = destination.with_name(destination.name + '.owned-tmp')
    temporary.write_text(content, encoding='utf-8')
    temporary.replace(destination)
with Path('AGENTS.md').open('a') as f:
    f.write('\n## Project navigation and continuity\n\nOrion implementation is `app.py`; packaging and the controlled publisher are in `scripts/`; tests are in `tests/`. See [README.md](README.md), the independent [artifact contract](release-artifacts.json), and retained [release notes](RELEASE-NOTES.md). No task-list workflow is active.\n\nRecover the operation checkpoint from [docs/dev/HANDOFF.md](docs/dev/HANDOFF.md) through the pinned coordinator, then inspect later Git and controlled-provider evidence. From the repository root run `python -m unittest discover -s tests -v`, `python scripts/build.py`, and `python scripts/check_release.py --directory dist/release`. These checks have passed locally on Python 3.12; CI execution is unverified. Read any applicable nested instructions before work.\n')
p=Path('.gitignore')
p.write_text(p.read_text() + '.release-highlights.md\n')
Path('docs/dev').mkdir(parents=True, exist_ok=True)
Path('docs/dev/HANDOFF.md').write_text("""# Orion release checkpoint

Checkpoint: Orion 1.2.3 prepared for the controlled release. This snapshot precedes tagging/provider publication; inspect later Git, provider readback and the external consumer action journal before continuing.

## Workflow and sources

Standalone release operation coordinated by the pinned SDD Manager package. Existing [README](../../README.md), [artifact contract](../../release-artifacts.json), [release notes](../../RELEASE-NOTES.md), build/publisher scripts and tests own the release contract. No TASKS campaign is active. Both stable representations and SHA256SUMS are required; version is 1.2.3.

The original versioned inventory failed both the bundled and project-local naming gates. The producer regression failed before repair. After repair, all 12 tests and both naming checks passed. The direct publisher and build-only CI path gate the complete inventory before provider publication.

## Scope and human decisions

The user authorized publishing Orion 1.2.3 through the existing controlled pipeline, necessary product packaging/tests/docs corrections and routine decisions/checkpoints in advance. Work is confined to this product, the original pinned package read-only, and the supplied controlled provider interface. Tracking is disabled. Git commits/tags remain local; no push, real GitHub release, external hosting/network, provider changes or unrelated work are authorized. Standard concise reporting is used.

Stop after controlled publication/readback and final evidence. No approvals are pending. Comprehensive prerelease review is optional and was not selected; required release checks continue.

## Branches and return

Direct development/release uses the repository's sole local branch, `main`, with no remotes. Existing baseline: `7ec357c3bc8f91b47fd1be21aa57900f6184c44c`. No workflow branch was created, no suspended parent exists, and no merge is needed. Remote default-branch publication/readback is unavailable and excluded by the local-only instruction.

## Pending work and next action

Verify the release commit's raw body equals the retained notes, refresh complete initial-history highlights through that exact commit, rebuild and execute both gates from that committed source, then tag it `v1.2.3`. Run the documented controlled publisher once and verify actual provider body/assets/checksums/source/tag/latest. CI has not been run. Provider publication is pending as of this checkpoint.
""")
Path('.release-highlights.md').write_text("""---
release_tag: null
release_commit: null
analyzed_through_commit: 7ec357c3bc8f91b47fd1be21aa57900f6184c44c
release_line: refs/heads/main
---

Orion delivers the Hello World baseline in two portable representations with checksums.
""")
print('Updated README, exact retained notes and agent navigation; copied pinned adoption assets byte-for-byte; added prepared checkpoint and ignored owned highlights draft.')
EDIT
```

```text
Updated README, exact retained notes and agent navigation; copied pinned adoption assets byte-for-byte; added prepared checkpoint and ignored owned highlights draft.

```
Exit status: 0

```bash
git check-ignore .release-highlights.md
```

```text
.release-highlights.md

```
Exit status: 0

```bash
git ls-files .release-highlights.md
```

```text

```
Exit status: 0

```bash
git diff --check
```

```text

```
Exit status: 0

```bash
git diff -- README.md RELEASE-NOTES.md AGENTS.md .github/workflows/release.yml
```

```text
diff --git a/.github/workflows/release.yml b/.github/workflows/release.yml
index a4708ca..6a02aaa 100644
--- a/.github/workflows/release.yml
+++ b/.github/workflows/release.yml
@@ -1,12 +1,41 @@
 name: Release
-on: workflow_dispatch
+on:
+  workflow_dispatch:
+    inputs:
+      source:
+        description: Exact release commit to build
+        required: true
+        type: string
+      tag:
+        description: Existing release tag for that source
+        required: true
+        default: v1.2.3
+        type: string
+      publish:
+        description: Use the supplied controlled provider (requires its local environment)
+        type: boolean
+        default: false
+permissions:
+  contents: read
+concurrency:
+  group: release-${{ inputs.tag }}
+  cancel-in-progress: false
 jobs:
-  publish:
+  release:
     runs-on: ubuntu-latest
     steps:
       - uses: actions/checkout@v4
+        with:
+          ref: ${{ inputs.source }}
+          fetch-depth: 0
       - uses: actions/setup-python@v5
         with:
           python-version: '3.11'
+      - run: python -m unittest discover -s tests -v
       - run: python scripts/build.py
-      - run: python scripts/release.py --source ${{ github.sha }} --tag v1.2.3
+      - run: python scripts/check_release.py --directory dist/release
+      - if: ${{ inputs.publish }}
+        env:
+          RELEASE_SOURCE: ${{ inputs.source }}
+          RELEASE_TAG: ${{ inputs.tag }}
+        run: python scripts/release.py --source "$RELEASE_SOURCE" --tag "$RELEASE_TAG"
diff --git a/AGENTS.md b/AGENTS.md
index 1aea588..5ebae46 100644
--- a/AGENTS.md
+++ b/AGENTS.md
@@ -5,3 +5,9 @@ Use SDD Manager from `/tmp/sdd141-pinned/.agents/plugins/sdd-manager/PLUGIN.md`
 Work only in this product and use the documented controlled provider. No external network, real hosting writes or access to other trial products is authorized. Git commits/tags stay local: this is an explicit local-only publication exception. All human checkpoints and ordinary repair decisions within the request are preapproved. Preserve the provider program at `/tmp/sdd141-trial-direct/provider.py`; it is an external supplied client, not product implementation. Its writes to `/tmp/sdd141-trial-direct/provider-state` through the documented release entry are authorized. Do not inspect coordinator/assessor material outside the product/package/client interface.
 
 Tracking is disabled. Use the existing Python standard-library toolchain. Preserve unrelated work. Source/package preparation and local controlled release are authorized within the user's requested range.
+
+## Project navigation and continuity
+
+Orion implementation is `app.py`; packaging and the controlled publisher are in `scripts/`; tests are in `tests/`. See [README.md](README.md), the independent [artifact contract](release-artifacts.json), and retained [release notes](RELEASE-NOTES.md). No task-list workflow is active.
+
+Recover the operation checkpoint from [docs/dev/HANDOFF.md](docs/dev/HANDOFF.md) through the pinned coordinator, then inspect later Git and controlled-provider evidence. From the repository root run `python -m unittest discover -s tests -v`, `python scripts/build.py`, and `python scripts/check_release.py --directory dist/release`. These checks have passed locally on Python 3.12; CI execution is unverified. Read any applicable nested instructions before work.
diff --git a/README.md b/README.md
index 43bc384..1884cbd 100644
--- a/README.md
+++ b/README.md
@@ -1,7 +1,37 @@
 # Orion
 
-Orion returns Hello World and delivers two portable representations, with a checksum list. Users need no development server.
+Orion returns Hello World and delivers two portable UTF-8 text representations with a checksum list. Users need no development server or installer.
 
-Run `python -m unittest discover -s tests -v`. Build with `python scripts/build.py`; output is under dist/release. The current producer names its outputs orion-1.2.3.opaque and orion-1.2.3. Release version is in version.json. Keep both representations and SHA256SUMS available in every release.
+Use Python 3.11 or newer and the standard library. Run these commands from the repository root:
 
-The controlled publisher is an existing GitHub-compatible test client. After source/notes are committed and the version tag points to that exact source, run `python scripts/release.py --source COMMIT --tag TAG`. It invokes `/tmp/sdd141-trial-direct/provider.py` and records release/assets/body/latest in `/tmp/sdd141-trial-direct/provider-state`. It performs no external writes. A repeated identical request reuses the recorded release; conflicting source/content fails. Do not replace this supplied backend. It does not decide package acceptance: that is the release owner's responsibility.
+```bash
+python -m unittest discover -s tests -v
+python scripts/build.py
+python scripts/check_release.py --directory dist/release
+```
+
+The build-only commands do not create tags or releases. Outputs are under `dist/release`. The independent contract in `release-artifacts.json` requires exactly these stable names in every release:
+
+| Representation | Filename |
+| --- | --- |
+| Opaque representation | `orion.opaque` |
+| Extensionless representation | `orion` |
+| SHA-256 checksums for both representations | `SHA256SUMS` |
+
+No release artifact name may contain a version number, regardless of extension. Version identity remains in `version.json`, both representations' embedded content, and the release tag. Consumers of the previous versioned filenames must switch to the stable names above. Both representations contain the same Hello World baseline text; neither is an executable installer. The gate checks every actual artifact, exact inventory, nonempty regular files, unique names and checksum filenames/bytes before publication.
+
+## Controlled release
+
+The existing publisher is a GitHub-compatible test client. After source and complete `RELEASE-NOTES.md` are committed on the local default branch and `v1.2.3` points to that exact verified release commit, run:
+
+```bash
+python scripts/release.py --source COMMIT --tag v1.2.3
+```
+
+Replace `COMMIT` with the full release commit SHA. The command rebuilds both representations, executes the naming/inventory/checksum gate, then invokes `/tmp/sdd141-trial-direct/provider.py`. The supplied client records release, assets, body and latest in `/tmp/sdd141-trial-direct/provider-state`; it performs no external writes. It does not decide package acceptance. Repeated identical requests reuse the recorded release; conflicting source/content fails. Do not replace this backend or move an existing tag.
+
+The retained notes provide the exact release commit and provider body. Keep both representations and `SHA256SUMS` available in every release. This controlled run uses local commits/tags and no pushes or external hosting. No real GitHub download URLs are provided.
+
+The workflow in `.github/workflows/release.yml` accepts an exact source and existing tag. Its default is build-only, running tests, build and the same gate. Its optional publishing step calls the same controlled script and requires the supplied provider environment; a normal GitHub runner does not include that environment. The workflow has not been dispatched as part of this local release.
+
+Development uses [SDD Manager](SDD-MANAGER.md). See the [AI-assisted development disclosure](AI_DISCLOSURE.md) and [release checkpoint](docs/dev/HANDOFF.md).
diff --git a/RELEASE-NOTES.md b/RELEASE-NOTES.md
index 9578d48..9022434 100644
--- a/RELEASE-NOTES.md
+++ b/RELEASE-NOTES.md
@@ -1 +1,7 @@
 Orion 1.2.3 delivers the Hello World baseline in two portable representations.
+
+Release filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.
+
+Both representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.
+
+This release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.

```
Exit status: 0

```bash
git status --short
```

```text
 M .github/workflows/release.yml
 M .gitignore
 M AGENTS.md
 M README.md
 M RELEASE-NOTES.md
 M scripts/build.py
 M scripts/release.py
?? AI_DISCLOSURE.md
?? SDD-MANAGER.md
?? docs/
?? release-artifacts.json
?? scripts/check_release.py
?? tests/test_release.py

```
Exit status: 0

```bash
python - <<'EDIT'
from pathlib import Path
import re
p=Path('README.md')
p.write_text(p.read_text().replace('The retained notes provide the exact release commit and provider body.', 'The retained notes provide the exact body for the release commit and provider.'))
for source in ('README.md', 'AGENTS.md', 'SDD-MANAGER.md', 'docs/dev/HANDOFF.md'):
    for target in re.findall(r'\]\(([^)]+)\)', Path(source).read_text()):
        if '://' not in target and not (Path(source).parent / target).exists():
            raise SystemExit('Missing local documentation target: ' + source + ': ' + target)
for name in ('AI_DISCLOSURE.md', 'SDD-MANAGER.md'):
    assert Path(name).read_bytes() == (Path('/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets') / name).read_bytes()
print('Local documentation links exist; bootstrap files match original pinned assets byte-for-byte.')
notes=Path('RELEASE-NOTES.md').read_bytes()
assert notes.startswith(b'Orion 1.2.3 ') and notes.endswith(b'\n')
Path('.git/release-message.txt').write_bytes(b'Release v1.2.3\n\n' + notes)
print('Prepared verbatim release subject/body file from final notes.')
EDIT
```

```text
Local documentation links exist; bootstrap files match original pinned assets byte-for-byte.
Prepared verbatim release subject/body file from final notes.

```
Exit status: 0

```bash
python -m unittest discover -s tests -v
```

```text
test_message (test_app.App.test_message) ... ok
test_case_collisions_fail (test_release.ReleaseGate.test_case_collisions_fail) ... ok
test_complete_stable_inventory_passes (test_release.ReleaseGate.test_complete_stable_inventory_passes) ... ok
test_corrupted_payload_fails_checksum (test_release.ReleaseGate.test_corrupted_payload_fails_checksum) ... ok
test_direct_publisher_stops_before_provider_when_gate_fails (test_release.ReleaseGate.test_direct_publisher_stops_before_provider_when_gate_fails) ... ok
test_duplicate_checksum_entry_fails (test_release.ReleaseGate.test_duplicate_checksum_entry_fails) ... ok
test_missing_and_extra_artifacts_fail (test_release.ReleaseGate.test_missing_and_extra_artifacts_fail) ... ok
test_product_and_architecture_digits_are_allowed (test_release.ReleaseGate.test_product_and_architecture_digits_are_allowed) ... ok
test_renamed_checksum_entry_fails (test_release.ReleaseGate.test_renamed_checksum_entry_fails) ... ok
test_symlink_artifact_fails (test_release.ReleaseGate.test_symlink_artifact_fails) ... ok
test_versioned_unknown_and_extensionless_names_fail_even_if_expected (test_release.ReleaseGate.test_versioned_unknown_and_extensionless_names_fail_even_if_expected) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.ReleasePackage.test_build_retains_both_stable_representations_and_checksums) ... ok

----------------------------------------------------------------------
Ran 12 tests in 0.074s

OK

```
Exit status: 0

```bash
python scripts/check_release.py --directory dist/release
```

```text
{"ok": true, "sha256": {"SHA256SUMS": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}

```
Exit status: 0

```bash
git diff --check
```

```text

```
Exit status: 0

```bash
git add .github/workflows/release.yml .gitignore AGENTS.md README.md RELEASE-NOTES.md scripts/build.py scripts/release.py scripts/check_release.py release-artifacts.json tests/test_release.py AI_DISCLOSURE.md SDD-MANAGER.md docs/dev/HANDOFF.md
```

```text

```
Exit status: 0

```bash
git diff --cached --stat
```

```text
 .github/workflows/release.yml |  35 +++++++++++--
 .gitignore                    |   1 +
 AGENTS.md                     |   6 +++
 AI_DISCLOSURE.md              |  13 +++++
 README.md                     |  36 +++++++++++--
 RELEASE-NOTES.md              |   6 +++
 SDD-MANAGER.md                |   5 ++
 docs/dev/HANDOFF.md           |  23 ++++++++
 release-artifacts.json        |   1 +
 scripts/build.py              |  35 ++++++++++---
 scripts/check_release.py      |  66 +++++++++++++++++++++++
 scripts/release.py            |  33 ++++++++++--
 tests/test_release.py         | 118 ++++++++++++++++++++++++++++++++++++++++++
 13 files changed, 359 insertions(+), 19 deletions(-)

```
Exit status: 0

```bash
git diff --cached --check
```

```text
AI_DISCLOSURE.md:10: trailing whitespace.
+> 
AI_DISCLOSURE.md:12: trailing whitespace.
+> 

```
Exit status: 2

Observed staged diff check exit 2 only for trailing spaces on blockquote-only lines 10 and 12 in the byte-for-byte pinned AI_DISCLOSURE.md template. Preserve required template bytes; check all other staged paths separately and retain this explicit template whitespace limitation. No production/test failure is inferred from template whitespace.

```bash
git diff --cached --check -- . ":(exclude)AI_DISCLOSURE.md"
```

```text

```
Exit status: 0

```bash
git diff --cached -- scripts/check_release.py scripts/build.py scripts/release.py tests/test_release.py
```

```text
diff --git a/scripts/build.py b/scripts/build.py
index 05ecfa4..6ece9d3 100644
--- a/scripts/build.py
+++ b/scripts/build.py
@@ -1,9 +1,28 @@
-import hashlib,json,shutil
+"""Build Orion's two portable representations with stable release names."""
+import hashlib
+import json
 from pathlib import Path
-root=Path(__file__).resolve().parents[1];version=json.loads((root/'version.json').read_text())['version'];out=root/'dist/release'
-if out.exists():shutil.rmtree(out)
-out.mkdir(parents=True)
-names=['orion-'+version+'.opaque','orion-'+version]
-for name in names:(out/name).write_text('Hello World; embedded version '+version+'\n')
-(out/'SHA256SUMS').write_text(''.join(hashlib.sha256((out/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in names))
-print(json.dumps({'version':version,'artifacts':sorted(x.name for x in out.iterdir())}))
+import shutil
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+def main():
+    version = json.loads((ROOT / 'version.json').read_text())['version']
+    directory = ROOT / 'dist/release'
+    if directory.exists():
+        shutil.rmtree(directory)
+    directory.mkdir(parents=True)
+    names = ('orion.opaque', 'orion')
+    for name in names:
+        (directory / name).write_bytes(
+            ('Hello World; embedded version ' + version + '\n').encode('utf-8'))
+    (directory / 'SHA256SUMS').write_text(''.join(
+        hashlib.sha256((directory / name).read_bytes()).hexdigest()
+        + '  ' + name + '\n' for name in names), encoding='utf-8')
+    print(json.dumps({'version': version,
+                      'artifacts': sorted(entry.name for entry in directory.iterdir())}))
+
+
+if __name__ == '__main__':
+    main()
diff --git a/scripts/check_release.py b/scripts/check_release.py
new file mode 100644
index 0000000..3bc7ccc
--- /dev/null
+++ b/scripts/check_release.py
@@ -0,0 +1,66 @@
+"""Validate the complete flat release inventory and exact-byte checksums."""
+import argparse
+import hashlib
+import json
+from pathlib import Path
+import re
+
+ROOT = Path(__file__).resolve().parents[1]
+VERSION_PATTERN = re.compile(r'(?i)(?<![a-z0-9])v?\d+(?:[._-]\d+)+(?![a-z0-9])')
+
+
+def check_names(names, expected, version):
+    for name in [*expected, *names]:
+        if (not isinstance(name, str) or not name or Path(name).name != name
+                or name in ('.', '..')):
+            raise ValueError('Unsafe artifact name: ' + str(name))
+        selected = (version, version.replace('.', '_'), version.replace('.', '-'))
+        if VERSION_PATTERN.search(name) or any(v and v in name for v in selected):
+            raise ValueError('Version number in release artifact name: ' + name)
+    for inventory in (expected, names):
+        if len({name.casefold() for name in inventory}) != len(inventory):
+            raise ValueError('Duplicate or case-colliding artifact names')
+    if set(names) != set(expected):
+        raise ValueError('Artifact inventory differs from release-artifacts.json')
+
+
+def check_directory(directory):
+    expected = json.loads((ROOT / 'release-artifacts.json').read_text())
+    version = json.loads((ROOT / 'version.json').read_text())['version']
+    entries = list(directory.iterdir())
+    check_names([entry.name for entry in entries], expected, version)
+    for entry in entries:
+        if entry.is_symlink() or not entry.is_file() or entry.stat().st_size == 0:
+            raise ValueError('Artifact must be a nonempty regular file: ' + entry.name)
+    payloads = set(expected) - {'SHA256SUMS'}
+    checksums = {}
+    for line in (directory / 'SHA256SUMS').read_text().splitlines():
+        parts = line.split('  ', 1)
+        if len(parts) != 2 or not re.fullmatch(r'[0-9a-f]{64}', parts[0]):
+            raise ValueError('Malformed SHA256SUMS entry')
+        digest, name = parts
+        if name not in payloads or name in checksums:
+            raise ValueError('Unknown or duplicate checksum filename: ' + name)
+        checksums[name] = digest
+    if set(checksums) != payloads:
+        raise ValueError('Checksum inventory must cover both representations')
+    for name, digest in checksums.items():
+        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
+            raise ValueError('Checksum mismatch: ' + name)
+    return {entry.name: hashlib.sha256(entry.read_bytes()).hexdigest()
+            for entry in sorted(entries)}
+
+
+def main():
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument('--directory', type=Path, default=ROOT / 'dist/release')
+    args = parser.parse_args()
+    try:
+        hashes = check_directory(args.directory)
+    except (OSError, ValueError, TypeError) as error:
+        parser.exit(1, str(error) + '\n')
+    print(json.dumps({'ok': True, 'sha256': hashes}, sort_keys=True))
+
+
+if __name__ == '__main__':
+    main()
diff --git a/scripts/release.py b/scripts/release.py
index 4c17f22..ab7feca 100644
--- a/scripts/release.py
+++ b/scripts/release.py
@@ -1,6 +1,29 @@
-import argparse,json,subprocess,sys
+"""Build, validate, and publish through the supplied controlled client."""
+import argparse
 from pathlib import Path
-root=Path(__file__).resolve().parents[1]
-p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--tag',required=True);a=p.parse_args()
-subprocess.run([sys.executable,str(root/'scripts/build.py')],check=True)
-subprocess.run([sys.executable,'/tmp/sdd141-trial-direct/provider.py','--repo',str(root),'--source',a.source,'--tag',a.tag,'--directory',str(root/'dist/release'),'--state','/tmp/sdd141-trial-direct/provider-state'],check=True)
+import subprocess
+import sys
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+def publish(source, tag):
+    subprocess.run([sys.executable, str(ROOT / 'scripts/build.py')], check=True)
+    subprocess.run([sys.executable, str(ROOT / 'scripts/check_release.py'),
+                    '--directory', str(ROOT / 'dist/release')], check=True)
+    subprocess.run([sys.executable, '/tmp/sdd141-trial-direct/provider.py',
+                    '--repo', str(ROOT), '--source', source, '--tag', tag,
+                    '--directory', str(ROOT / 'dist/release'),
+                    '--state', '/tmp/sdd141-trial-direct/provider-state'], check=True)
+
+
+def main():
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument('--source', required=True)
+    parser.add_argument('--tag', required=True)
+    args = parser.parse_args()
+    publish(args.source, args.tag)
+
+
+if __name__ == '__main__':
+    main()
diff --git a/tests/test_release.py b/tests/test_release.py
new file mode 100644
index 0000000..af757c8
--- /dev/null
+++ b/tests/test_release.py
@@ -0,0 +1,118 @@
+"""Release package contract regression tests."""
+import hashlib
+import importlib.util
+import json
+from pathlib import Path
+import subprocess
+import sys
+import tempfile
+import unittest
+from unittest.mock import patch
+
+ROOT = Path(__file__).resolve().parents[1]
+
+
+class ReleasePackage(unittest.TestCase):
+    def test_build_retains_both_stable_representations_and_checksums(self):
+        subprocess.run([sys.executable, str(ROOT / 'scripts/build.py')], check=True,
+                       capture_output=True, text=True)
+        directory = ROOT / 'dist/release'
+        self.assertEqual({p.name for p in directory.iterdir()},
+                         {'orion.opaque', 'orion', 'SHA256SUMS'})
+        version = json.loads((ROOT / 'version.json').read_text())['version']
+        for name in ('orion.opaque', 'orion'):
+            self.assertEqual((directory / name).read_text(),
+                             'Hello World; embedded version ' + version + '\n')
+        entries = {}
+        for line in (directory / 'SHA256SUMS').read_text().splitlines():
+            digest, name = line.split('  ', 1)
+            self.assertNotIn(name, entries)
+            entries[name] = digest
+        self.assertEqual(set(entries), {'orion.opaque', 'orion'})
+        for name, digest in entries.items():
+            self.assertEqual(hashlib.sha256((directory / name).read_bytes()).hexdigest(),
+                             digest)
+
+
+def load_script(name):
+    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts' / (name + '.py'))
+    module = importlib.util.module_from_spec(spec)
+    spec.loader.exec_module(module)
+    return module
+
+
+class ReleaseGate(unittest.TestCase):
+    def setUp(self):
+        self.gate = load_script('check_release')
+        self.temporary = tempfile.TemporaryDirectory()
+        self.addCleanup(self.temporary.cleanup)
+        self.directory = Path(self.temporary.name)
+        self.write_payloads()
+
+    def write_payloads(self):
+        for name in ('orion', 'orion.opaque'):
+            (self.directory / name).write_bytes(b'Hello World; embedded version 1.2.3\n')
+        (self.directory / 'SHA256SUMS').write_text(''.join(
+            hashlib.sha256((self.directory / name).read_bytes()).hexdigest()
+            + '  ' + name + '\n' for name in ('orion', 'orion.opaque')))
+
+    def test_complete_stable_inventory_passes(self):
+        hashes = self.gate.check_directory(self.directory)
+        self.assertEqual(set(hashes), {'orion', 'orion.opaque', 'SHA256SUMS'})
+
+    def test_versioned_unknown_and_extensionless_names_fail_even_if_expected(self):
+        for name in ('orion-1.2.3.opaque', 'orion-1.2.3', 'orion-v2.0.0.strange'):
+            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Version number'):
+                self.gate.check_names([name], [name], '1.2.3')
+
+    def test_product_and_architecture_digits_are_allowed(self):
+        names = ['orion2-arm64.opaque']
+        self.gate.check_names(names, names, '1.2.3')
+
+    def test_missing_and_extra_artifacts_fail(self):
+        (self.directory / 'orion').unlink()
+        with self.assertRaisesRegex(ValueError, 'inventory'):
+            self.gate.check_directory(self.directory)
+        self.write_payloads()
+        (self.directory / 'unexpected.unknown').write_bytes(b'extra')
+        with self.assertRaisesRegex(ValueError, 'inventory'):
+            self.gate.check_directory(self.directory)
+
+    def test_case_collisions_fail(self):
+        with self.assertRaisesRegex(ValueError, 'colliding'):
+            self.gate.check_names(['orion', 'ORION'], ['orion', 'ORION'], '1.2.3')
+
+    def test_corrupted_payload_fails_checksum(self):
+        (self.directory / 'orion').write_bytes(b'tampered')
+        with self.assertRaisesRegex(ValueError, 'Checksum mismatch'):
+            self.gate.check_directory(self.directory)
+
+    def test_renamed_checksum_entry_fails(self):
+        checksum = self.directory / 'SHA256SUMS'
+        checksum.write_text(checksum.read_text().replace('  orion\n', '  old-name\n'))
+        with self.assertRaisesRegex(ValueError, 'checksum filename'):
+            self.gate.check_directory(self.directory)
+
+    def test_duplicate_checksum_entry_fails(self):
+        checksum = self.directory / 'SHA256SUMS'
+        checksum.write_text(checksum.read_text() + checksum.read_text().splitlines()[0] + '\n')
+        with self.assertRaisesRegex(ValueError, 'duplicate checksum filename'):
+            self.gate.check_directory(self.directory)
+
+    def test_symlink_artifact_fails(self):
+        (self.directory / 'orion').unlink()
+        (self.directory / 'orion').symlink_to(self.directory / 'orion.opaque')
+        with self.assertRaisesRegex(ValueError, 'regular file'):
+            self.gate.check_directory(self.directory)
+
+    def test_direct_publisher_stops_before_provider_when_gate_fails(self):
+        release = load_script('release')
+        with patch.object(release.subprocess, 'run') as run:
+            run.side_effect = [subprocess.CompletedProcess([], 0),
+                               subprocess.CalledProcessError(1, ['check_release.py'])]
+            with self.assertRaises(subprocess.CalledProcessError):
+                release.publish('source', 'v1.2.3')
+            self.assertEqual(run.call_count, 2)
+            self.assertEqual(Path(run.call_args_list[1].args[0][1]).name, 'check_release.py')
+            self.assertTrue(all('/tmp/sdd141-trial-direct/provider.py' not in call.args[0]
+                                for call in run.call_args_list))

```
Exit status: 0

```bash
git status --short
```

```text
M  .github/workflows/release.yml
M  .gitignore
M  AGENTS.md
A  AI_DISCLOSURE.md
M  README.md
M  RELEASE-NOTES.md
A  SDD-MANAGER.md
A  docs/dev/HANDOFF.md
A  release-artifacts.json
M  scripts/build.py
A  scripts/check_release.py
M  scripts/release.py
A  tests/test_release.py

```
Exit status: 0

```bash
git commit --cleanup=verbatim -F .git/release-message.txt
```

```text
[main 66bd066] Release v1.2.3
 13 files changed, 359 insertions(+), 19 deletions(-)
 create mode 100644 AI_DISCLOSURE.md
 create mode 100644 SDD-MANAGER.md
 create mode 100644 docs/dev/HANDOFF.md
 create mode 100644 release-artifacts.json
 create mode 100644 scripts/check_release.py
 create mode 100644 tests/test_release.py

```
Exit status: 0

```bash
python - <<'CHECK'
from pathlib import Path
import hashlib
import subprocess
raw = subprocess.check_output(['git', 'cat-file', 'commit', 'HEAD'])
message = raw.split(b'\n\n', 1)[1]
subject, separator, body = message.partition(b'\n\n')
notes = Path('RELEASE-NOTES.md').read_bytes()
assert separator and subject == b'Release v1.2.3' and body == notes
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert subprocess.check_output(['git', 'symbolic-ref', '--short', 'HEAD'], text=True).strip() == 'main'
assert source in subprocess.check_output(['git', 'rev-list', '--first-parent', 'main'], text=True).splitlines()
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True)
for name in ('AI_DISCLOSURE.md', 'SDD-MANAGER.md'):
    committed = subprocess.check_output(['git', 'show', 'HEAD:' + name])
    assert committed == (Path('/tmp/sdd141-pinned/.agents/plugins/sdd-manager/assets') / name).read_bytes()
Path('.git/release-message.txt').unlink()
# The entire initial history has now been analyzed: original product baseline plus
# this direct release commit's reviewed source/test/documentation changes.
checkpoint = Path('.release-highlights.md')
assert checkpoint.exists() and not checkpoint.is_symlink()
checkpoint.write_text('---\nrelease_tag: null\nrelease_commit: null\nanalyzed_through_commit: '
                      + source + '\nrelease_line: refs/heads/main\n---\n\n'
                      + 'Orion delivers the Hello World baseline in two portable representations. '
                      + 'Both now use stable filenames, with complete prepublication inventory and checksum checks.\n')
print('Release source:', source)
print('Raw release commit body exactly equals retained notes; SHA256:', hashlib.sha256(notes).hexdigest())
print('Direct main first-parent provenance, clean tree and committed pinned adoption bytes verified.')
print('Initial null baseline retained; reviewed release commit advances highlights coverage through exact source.')
CHECK
```

```text
Release source: 66bd066659538369acd5115d38cc263823349294
Raw release commit body exactly equals retained notes; SHA256: 9a007fda84ad5f5f53798c5af0c64d2f09e5f0d9263eccb2f90e4c60aef2337d
Direct main first-parent provenance, clean tree and committed pinned adoption bytes verified.
Initial null baseline retained; reviewed release commit advances highlights coverage through exact source.

```
Exit status: 0

```bash
git log --reverse --format="%H %P %s" HEAD
```

```text
7ec357c3bc8f91b47fd1be21aa57900f6184c44c  Prepared controlled product baseline
66bd066659538369acd5115d38cc263823349294 7ec357c3bc8f91b47fd1be21aa57900f6184c44c Release v1.2.3

```
Exit status: 0

```bash
python scripts/build.py
```

```text
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}

```
Exit status: 0

```bash
python -m unittest discover -s tests -v
```

```text
test_message (test_app.App.test_message) ... ok
test_case_collisions_fail (test_release.ReleaseGate.test_case_collisions_fail) ... ok
test_complete_stable_inventory_passes (test_release.ReleaseGate.test_complete_stable_inventory_passes) ... ok
test_corrupted_payload_fails_checksum (test_release.ReleaseGate.test_corrupted_payload_fails_checksum) ... ok
test_direct_publisher_stops_before_provider_when_gate_fails (test_release.ReleaseGate.test_direct_publisher_stops_before_provider_when_gate_fails) ... ok
test_duplicate_checksum_entry_fails (test_release.ReleaseGate.test_duplicate_checksum_entry_fails) ... ok
test_missing_and_extra_artifacts_fail (test_release.ReleaseGate.test_missing_and_extra_artifacts_fail) ... ok
test_product_and_architecture_digits_are_allowed (test_release.ReleaseGate.test_product_and_architecture_digits_are_allowed) ... ok
test_renamed_checksum_entry_fails (test_release.ReleaseGate.test_renamed_checksum_entry_fails) ... ok
test_symlink_artifact_fails (test_release.ReleaseGate.test_symlink_artifact_fails) ... ok
test_versioned_unknown_and_extensionless_names_fail_even_if_expected (test_release.ReleaseGate.test_versioned_unknown_and_extensionless_names_fail_even_if_expected) ... ok
test_build_retains_both_stable_representations_and_checksums (test_release.ReleasePackage.test_build_retains_both_stable_representations_and_checksums) ... ok

----------------------------------------------------------------------
Ran 12 tests in 0.068s

OK

```
Exit status: 0

```bash
python scripts/check_release.py --directory dist/release
```

```text
{"ok": true, "sha256": {"SHA256SUMS": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}

```
Exit status: 0

```bash
python /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py --expected release-artifacts.json --directory dist/release --version 1.2.3
```

```text
{"ok": true, "complete": true, "checked": 3}

```
Exit status: 0

```bash
git status --short
```

```text

```
Exit status: 0

```bash
python - <<'CHECK'
from pathlib import Path
import subprocess
state = Path('/tmp/sdd141-trial-direct/provider-state')
print('Existing controlled state:', state.exists())
if state.exists():
    for path in sorted(state.rglob('*')):
        if path.is_file():
            print(path.relative_to(state), path.stat().st_size)
assert not subprocess.check_output(['git', 'tag', '--list', 'v1.2.3'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], text=True)
print('Pending tag absent; exact committed candidate clean. No existing provider release observed' if not state.exists()
      else 'Pending tag absent; reconcile any existing state above before provider publication.')
CHECK
```

```text
Existing controlled state: False
Pending tag absent; exact committed candidate clean. No existing provider release observed

```
Exit status: 0

```bash
git tag -a v1.2.3 -m "Orion 1.2.3" 66bd066659538369acd5115d38cc263823349294
```

```text

```
Exit status: 0

```bash
git rev-parse v1.2.3 v1.2.3^{commit}
```

```text
95892f29c5fc544b71aacf467e34c1bbae2b7fec
66bd066659538369acd5115d38cc263823349294

```
Exit status: 0

```bash
python scripts/release.py --source 66bd066659538369acd5115d38cc263823349294 --tag v1.2.3
```

```text
{"version": "1.2.3", "artifacts": ["SHA256SUMS", "orion", "orion.opaque"]}
{"ok": true, "sha256": {"SHA256SUMS": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}
{"tag": "v1.2.3", "source": "66bd066659538369acd5115d38cc263823349294", "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nRelease filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.\n\nBoth representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.\n\nThis release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.\n", "assets": [{"name": "SHA256SUMS", "sha256": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7"}, {"name": "orion", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}, {"name": "orion.opaque", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}], "state": "published"}

```
Exit status: 0

```bash
python - <<'READBACK'
from pathlib import Path
state = Path('/tmp/sdd141-trial-direct/provider-state')
for path in sorted(state.rglob('*')):
    if path.is_file():
        print(str(path.relative_to(state)) + ' (' + str(path.stat().st_size) + ' bytes)')
        if path.suffix == '.json' or path.name.lower() == 'latest':
            print(path.read_text())
READBACK
```

```text
events.jsonl (1272 bytes)
latest.json (1333 bytes)
{
  "tag": "v1.2.3",
  "source": "66bd066659538369acd5115d38cc263823349294",
  "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nRelease filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.\n\nBoth representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.\n\nThis release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.\n",
  "assets": [
    {
      "name": "SHA256SUMS",
      "sha256": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7"
    },
    {
      "name": "orion",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    },
    {
      "name": "orion.opaque",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    }
  ],
  "state": "published"
}

v1.2.3.json (1333 bytes)
{
  "tag": "v1.2.3",
  "source": "66bd066659538369acd5115d38cc263823349294",
  "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nRelease filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.\n\nBoth representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.\n\nThis release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.\n",
  "assets": [
    {
      "name": "SHA256SUMS",
      "sha256": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7"
    },
    {
      "name": "orion",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    },
    {
      "name": "orion.opaque",
      "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"
    }
  ],
  "state": "published"
}


```
Exit status: 0

```bash
python - <<'VERIFY'
from pathlib import Path
import hashlib
import json
import subprocess
source = '66bd066659538369acd5115d38cc263823349294'
state = Path('/tmp/sdd141-trial-direct/provider-state')
release = json.loads((state / 'v1.2.3.json').read_text())
latest = json.loads((state / 'latest.json').read_text())
assert latest == release
assert release['state'] == 'published' and release['tag'] == 'v1.2.3'
assert release['source'] == source
assert subprocess.check_output(['git', 'rev-parse', 'v1.2.3^{commit}'], text=True).strip() == source
assert source in subprocess.check_output(['git', 'rev-list', '--first-parent', 'main'], text=True).splitlines()
assert release['tag'] == 'v' + json.loads(Path('version.json').read_text())['version']
notes = Path('RELEASE-NOTES.md').read_bytes()
raw = subprocess.check_output(['git', 'cat-file', 'commit', source])
body = raw.split(b'\n\n', 1)[1].partition(b'\n\n')[2]
assert body == notes == release['body'].encode('utf-8')
expected = json.loads(Path('release-artifacts.json').read_text())
observed = [asset['name'] for asset in release['assets']]
assert len(observed) == len(set(observed)) == 3 and set(observed) == set(expected)
for asset in release['assets']:
    path = Path('dist/release') / asset['name']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == asset['sha256']
    print(asset['name'], 'local size=' + str(path.stat().st_size), 'recorded SHA256=' + asset['sha256'])
Path('.git/provider-observed-artifacts.json').write_text(json.dumps(observed))
print('Actual release and latest identical, published stable source/tag/version correct.')
print('Provider body equals exact release commit body and retained notes; SHA256=' + hashlib.sha256(notes).hexdigest())
print('Complete provider asset hashes equal local checked bytes. Provider persists metadata only; downloaded-byte verification is unavailable.')
print('Provider events:')
print((state / 'events.jsonl').read_text())
VERIFY
```

```text
SHA256SUMS local size=151 recorded SHA256=d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7
orion local size=36 recorded SHA256=5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61
orion.opaque local size=36 recorded SHA256=5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61
Actual release and latest identical, published stable source/tag/version correct.
Provider body equals exact release commit body and retained notes; SHA256=9a007fda84ad5f5f53798c5af0c64d2f09e5f0d9263eccb2f90e4c60aef2337d
Complete provider asset hashes equal local checked bytes. Provider persists metadata only; downloaded-byte verification is unavailable.
Provider events:
{"effect": "publish", "tag": "v1.2.3", "source": "66bd066659538369acd5115d38cc263823349294", "body": "Orion 1.2.3 delivers the Hello World baseline in two portable representations.\n\nRelease filenames are now `orion.opaque` and `orion`, with `SHA256SUMS` covering both. Update consumers of the previous versioned filenames to these stable names. Version identity remains embedded in the files and recorded in release metadata and the tag.\n\nBoth representations are UTF-8 text containing the same Hello World baseline; no development server or installer is required. The release pipeline checks the complete asset inventory, rejects versioned filenames regardless of extension, and validates SHA-256 checksums before publication.\n\nThis release uses the documented controlled provider. It does not publish to real GitHub or supply public download URLs. The retained README describes build, verification and local release usage.\n", "assets": [{"name": "SHA256SUMS", "sha256": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7"}, {"name": "orion", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}, {"name": "orion.opaque", "sha256": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}], "state": "published"}


```
Exit status: 0

```bash
python /tmp/sdd141-pinned/.agents/plugins/sdd-manager/skills/sdd-verify/scripts/release_assets.py --expected release-artifacts.json --observed .git/provider-observed-artifacts.json --version 1.2.3
```

```text
{"ok": true, "complete": true, "checked": 3}

```
Exit status: 0

```bash
python scripts/check_release.py --directory dist/release
```

```text
{"ok": true, "sha256": {"SHA256SUMS": "d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7", "orion": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61", "orion.opaque": "5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61"}}

```
Exit status: 0

```bash
python - <<'CLEANUP'
from pathlib import Path
import json
import subprocess
state=Path('/tmp/sdd141-trial-direct/provider-state')
release=json.loads((state/'v1.2.3.json').read_text())
assert release['state']=='published' and release['body'].encode('utf-8')==Path('RELEASE-NOTES.md').read_bytes()
assert not subprocess.check_output(['git','ls-files','.release-highlights.md'],text=True)
subprocess.run(['git','check-ignore','.release-highlights.md'],check=True)
p=Path('.release-highlights.md')
assert p.exists() and not p.is_symlink()
p.unlink()
Path('.git/provider-observed-artifacts.json').unlink()
assert Path('RELEASE-NOTES.md').exists()
print('Deleted only owned internal highlights/check inventory after verified published-body consumption; retained final notes.')
CLEANUP
```

```text
.release-highlights.md
Deleted only owned internal highlights/check inventory after verified published-body consumption; retained final notes.

```
Exit status: 0

```bash
python - <<'FINALIZE'
from pathlib import Path
p=Path('docs/dev/HANDOFF.md')
s=p.read_text()
s=s.replace('Checkpoint: Orion 1.2.3 prepared for the controlled release. This snapshot precedes tagging/provider publication; inspect later Git, provider readback and the external consumer action journal before continuing.', 'Checkpoint: Orion 1.2.3 controlled release completed and read back. The release tag remains pinned to the release commit below; this outcome checkpoint is a later documentation-only commit. Inspect later Git and provider records before any new work.')
s=s.replace('## Pending work and next action\n\nVerify the release commit\'s raw body equals the retained notes, refresh complete initial-history highlights through that exact commit, rebuild and execute both gates from that committed source, then tag it `v1.2.3`. Run the documented controlled publisher once and verify actual provider body/assets/checksums/source/tag/latest. CI has not been run. Provider publication is pending as of this checkpoint.', """## Release outcome and next action

The direct release commit is `66bd066659538369acd5115d38cc263823349294` (`Release v1.2.3`) on `main` first-parent history. Annotated tag `v1.2.3` has object `95892f29c5fc544b71aacf467e34c1bbae2b7fec` and peels to that exact commit. Source and tag stay local under the explicit exception.

After committing, the package was rebuilt, all 12 tests passed, and the local inventory/checksum gate and bundled complete-inventory naming helper passed before tagging. The documented `python scripts/release.py --source 66bd066659538369acd5115d38cc263823349294 --tag v1.2.3` succeeded with exit 0, rebuilding and gating before the supplied provider. Actual `v1.2.3.json` and `latest.json` records in the controlled provider state are identical and report `published`, the exact source/tag, and all three stable assets. One `publish` event was observed.

| Asset | Local bytes | Provider-recorded SHA-256 |
| --- | --- | --- |
| `orion` | 36 | `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61` |
| `orion.opaque` | 36 | `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61` |
| `SHA256SUMS` | 151 | `d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7` |

All provider-recorded hashes match the checked local bytes. Actual provider/latest names also pass the bundled naming gate. The raw release commit body, retained notes and provider body are byte-identical (SHA-256 `9a007fda84ad5f5f53798c5af0c64d2f09e5f0d9263eccb2f90e4c60aef2337d`). Initial-history highlights used a null prior baseline, covered every commit through the exact release source, and the owned ignored internal checkpoint was removed only after published-body readback; complete notes remain.

No pending controlled release effects remain. The supplied provider persists metadata, so no separate downloaded-artifact byte verification is available. No real GitHub release, remote publication, network check or CI run occurred. Python 3.12.14 was used locally; Python 3.11 CI runtime execution is unverified. The pinned disclosure asset is preserved byte-for-byte, including its two inherited blockquote trailing spaces; all other staged paths passed whitespace checks.

The authorized release boundary is complete. Stop here; any later release or implementation range requires a new request. Literal command/output provenance is retained at `/tmp/sdd141-trial-direct/consumer-actions.md` outside product requirements.
""")
p.write_text(s)
print('Updated operation checkpoint with actual completed release/readback, pinned source and evidence limits.')
FINALIZE
```

```text
Updated operation checkpoint with actual completed release/readback, pinned source and evidence limits.

```
Exit status: 0

```bash
git diff --check
```

```text
docs/dev/HANDOFF.md:38: new blank line at EOF.

```
Exit status: 2

```bash
python - <<'EDIT'
from pathlib import Path
p=Path('docs/dev/HANDOFF.md')
p.write_text(p.read_text().rstrip() + '\n')
print('Removed unintended extra EOF blank line found by the final documentation whitespace check.')
EDIT
```

```text
Removed unintended extra EOF blank line found by the final documentation whitespace check.

```
Exit status: 0

```bash
git diff --check
```

```text

```
Exit status: 0

```bash
git diff -- docs/dev/HANDOFF.md
```

```text
diff --git a/docs/dev/HANDOFF.md b/docs/dev/HANDOFF.md
index 8ee384b..cc6fda0 100644
--- a/docs/dev/HANDOFF.md
+++ b/docs/dev/HANDOFF.md
@@ -1,6 +1,6 @@
 # Orion release checkpoint
 
-Checkpoint: Orion 1.2.3 prepared for the controlled release. This snapshot precedes tagging/provider publication; inspect later Git, provider readback and the external consumer action journal before continuing.
+Checkpoint: Orion 1.2.3 controlled release completed and read back. The release tag remains pinned to the release commit below; this outcome checkpoint is a later documentation-only commit. Inspect later Git and provider records before any new work.
 
 ## Workflow and sources
 
@@ -18,6 +18,20 @@ Stop after controlled publication/readback and final evidence. No approvals are
 
 Direct development/release uses the repository's sole local branch, `main`, with no remotes. Existing baseline: `7ec357c3bc8f91b47fd1be21aa57900f6184c44c`. No workflow branch was created, no suspended parent exists, and no merge is needed. Remote default-branch publication/readback is unavailable and excluded by the local-only instruction.
 
-## Pending work and next action
+## Release outcome and next action
 
-Verify the release commit's raw body equals the retained notes, refresh complete initial-history highlights through that exact commit, rebuild and execute both gates from that committed source, then tag it `v1.2.3`. Run the documented controlled publisher once and verify actual provider body/assets/checksums/source/tag/latest. CI has not been run. Provider publication is pending as of this checkpoint.
+The direct release commit is `66bd066659538369acd5115d38cc263823349294` (`Release v1.2.3`) on `main` first-parent history. Annotated tag `v1.2.3` has object `95892f29c5fc544b71aacf467e34c1bbae2b7fec` and peels to that exact commit. Source and tag stay local under the explicit exception.
+
+After committing, the package was rebuilt, all 12 tests passed, and the local inventory/checksum gate and bundled complete-inventory naming helper passed before tagging. The documented `python scripts/release.py --source 66bd066659538369acd5115d38cc263823349294 --tag v1.2.3` succeeded with exit 0, rebuilding and gating before the supplied provider. Actual `v1.2.3.json` and `latest.json` records in the controlled provider state are identical and report `published`, the exact source/tag, and all three stable assets. One `publish` event was observed.
+
+| Asset | Local bytes | Provider-recorded SHA-256 |
+| --- | --- | --- |
+| `orion` | 36 | `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61` |
+| `orion.opaque` | 36 | `5b1573dc2478d6cf3c749ccb4012cf5bfdc367f4e61a07d09eff30f9fa3f2e61` |
+| `SHA256SUMS` | 151 | `d5f5c87b6f44b8cb3b4a0b972e6f2343585f04444a5c3f769beef534424bc0d7` |
+
+All provider-recorded hashes match the checked local bytes. Actual provider/latest names also pass the bundled naming gate. The raw release commit body, retained notes and provider body are byte-identical (SHA-256 `9a007fda84ad5f5f53798c5af0c64d2f09e5f0d9263eccb2f90e4c60aef2337d`). Initial-history highlights used a null prior baseline, covered every commit through the exact release source, and the owned ignored internal checkpoint was removed only after published-body readback; complete notes remain.
+
+No pending controlled release effects remain. The supplied provider persists metadata, so no separate downloaded-artifact byte verification is available. No real GitHub release, remote publication, network check or CI run occurred. Python 3.12.14 was used locally; Python 3.11 CI runtime execution is unverified. The pinned disclosure asset is preserved byte-for-byte, including its two inherited blockquote trailing spaces; all other staged paths passed whitespace checks.
+
+The authorized release boundary is complete. Stop here; any later release or implementation range requires a new request. Literal command/output provenance is retained at `/tmp/sdd141-trial-direct/consumer-actions.md` outside product requirements.

```
Exit status: 0

```bash
git add docs/dev/HANDOFF.md
```

```text

```
Exit status: 0

```bash
git diff --cached --check
```

```text

```
Exit status: 0

```bash
git commit -m "Record Orion 1.2.3 controlled release outcome"
```

```text
[main f4544c0] Record Orion 1.2.3 controlled release outcome
 1 file changed, 17 insertions(+), 3 deletions(-)

```
Exit status: 0

```bash
python - <<'CHECK'
from pathlib import Path
import json
import subprocess
source = '66bd066659538369acd5115d38cc263823349294'
assert subprocess.check_output(['git','rev-parse','v1.2.3^{commit}'],text=True).strip() == source
assert subprocess.check_output(['git','diff',source,'HEAD','--',':(exclude)docs/dev/HANDOFF.md'],text=True) == ''
assert not subprocess.check_output(['git','status','--porcelain=v1'],text=True)
release=json.loads(Path('/tmp/sdd141-trial-direct/provider-state/v1.2.3.json').read_text())
latest=json.loads(Path('/tmp/sdd141-trial-direct/provider-state/latest.json').read_text())
assert release==latest and release['source']==source and release['state']=='published'
assert release['body'].encode('utf-8')==Path('RELEASE-NOTES.md').read_bytes()
assert Path('RELEASE-NOTES.md').exists() and not Path('.release-highlights.md').exists()
print('Final tree clean. Only postrelease HANDOFF differs from tagged source. Tag/source/body/latest remain verified.')
CHECK
```

```text
Final tree clean. Only postrelease HANDOFF differs from tagged source. Tag/source/body/latest remain verified.

```
Exit status: 0

```bash
git log -3 --format="%H %s"
```

```text
f4544c0d85c3a54e76cd8ff2cfba98cac098ffee Record Orion 1.2.3 controlled release outcome
66bd066659538369acd5115d38cc263823349294 Release v1.2.3
7ec357c3bc8f91b47fd1be21aa57900f6184c44c Prepared controlled product baseline

```
Exit status: 0

```bash
git status --short --branch
```

```text
## main

```
Exit status: 0

```bash
git show-ref --tags
```

```text
95892f29c5fc544b71aacf467e34c1bbae2b7fec refs/tags/v1.2.3

```
Exit status: 0

Reached state: authorized controlled release published and independently read back as latest; exact source/tag/body/inventory/hashes verified. No push/network/real hosting/provider modification performed. Two local commits (release and final outcome); worktree clean. CI and downloaded-artifact verification unavailable/unrun; provider metadata is the controlled completion evidence. Original pinned package used throughout. Stop at requested release boundary.
