# Counter formatting feature tasks

Active feature execution owner.

- [ ] F1: define formatting acceptance.
