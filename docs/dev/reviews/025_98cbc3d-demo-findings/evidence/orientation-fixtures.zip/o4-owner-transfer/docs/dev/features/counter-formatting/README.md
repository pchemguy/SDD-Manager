# Counter formatting archive

Selected source [FEATURE-TASKS.md](FEATURE-TASKS.md) is historical evidence only. Ownership transferred to [main TASKS](../../TASKS.md). Historical checkboxes are not executable owners.
