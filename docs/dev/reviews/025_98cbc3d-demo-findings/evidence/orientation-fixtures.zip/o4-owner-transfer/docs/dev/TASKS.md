# Main tasks

Sole current executable owner after accepted counter-formatting transfer.

- [ ] F1: define formatting acceptance.

[Transfer record](features/counter-formatting/README.md).
