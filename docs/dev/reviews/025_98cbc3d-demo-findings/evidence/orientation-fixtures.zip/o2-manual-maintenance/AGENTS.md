# Human instructions

Never change data fixtures without explicit permission.

<!-- SDD maintained orientation: start -->
## Project orientation

[README.md](README.md) establishes this counter CLI's purpose. Source: [src/main.py](src/main.py). Tests: [checks/test_main.py](checks/test_main.py).

Active execution owner: [docs/dev/FEATURE-TASKS.md](docs/dev/FEATURE-TASKS.md).

[SDD-MANAGER.md](SDD-MANAGER.md) and [AI_DISCLOSURE.md](AI_DISCLOSURE.md) are project usage/disclosure records.

## Checks and working rules

From repository root using Python 3, run:

```text
python src/main.py 2 3
python -m unittest discover -s checks
```

These commands were exercised in this fixture: the CLI printed 5 and both unit tests passed. No installation or broader platform compatibility was verified.

Read applicable nested AGENTS.md before working on their paths. If the host does not discover root AGENTS.md, explicitly load this file. Preserve controlling manual instructions and unrelated changes. Keep edits within the authorized scope and stop at the requested boundary; commit/publication authority comes from the user and governing workflow. This disposable exercise stops at verified local files, with no publication.
<!-- SDD maintained orientation: end -->
