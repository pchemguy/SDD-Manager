# Counter formatting feature

This is the active feature owner.

- [ ] F1: define formatting acceptance.
