# Test instructions

Run tests from repository root
