# Usage notice

SDD Manager is used to maintain project orientation.
