# Counter CLI

Counts integer arguments and prints their sum.

Source: [src/main.py](src/main.py). Tests: [tests/test_main.py](tests/test_main.py).

Run from repository root with Python 3:

```text
python src/main.py 2 3
python -m unittest discover -s tests
```

[Usage notice](SDD-MANAGER.md) and [AI disclosure](AI_DISCLOSURE.md).
