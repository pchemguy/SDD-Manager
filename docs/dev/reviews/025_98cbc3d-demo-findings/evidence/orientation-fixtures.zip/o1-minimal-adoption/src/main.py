"""Sum integer CLI arguments."""
import sys

def count(values):
    return sum(map(int, values))

if __name__ == "__main__":
    print(count(sys.argv[1:]))
