"""Counter CLI contract checks."""
import unittest
from src.main import count

class CounterTest(unittest.TestCase):
    def test_sum(self):
        self.assertEqual(count(["2", "3"]), 5)
    def test_empty(self):
        self.assertEqual(count([]), 0)
